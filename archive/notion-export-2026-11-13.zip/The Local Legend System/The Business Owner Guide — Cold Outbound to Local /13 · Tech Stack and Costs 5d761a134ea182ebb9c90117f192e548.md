# 13 · Tech Stack and Costs

<aside>
🧰

**What this section does.** What to buy, in what order, and nothing you do not need. Plus an honest comparison of the five kinds of data provider, because that decision has more effect on your results than any other purchase here.

</aside>

**Applies to:** Both motions.

## Chapters

1. **13.1 What to buy, in what order** — the full stack, sequenced, with the partner codes
2. **13.2 The data layer compared** — corporate databases, cheap scrapers, an assembled workflow, a purpose-built API, and building it yourself

---

[13.1 What to Buy, in What Order](13%20%C2%B7%20Tech%20Stack%20and%20Costs/13%201%20What%20to%20Buy,%20in%20What%20Order%2086661a134ea182beb435017a761ff073.md)

[13.2 The Data Layer Compared](13%20%C2%B7%20Tech%20Stack%20and%20Costs/13%202%20The%20Data%20Layer%20Compared%20bda61a134ea182b2b64681a3692c31f5.md)

---

<aside>
➡️

**Next section:** [14 · Case Studies](14%20%C2%B7%20Case%20Studies%20db361a134ea183bfbb7381ee6553df1a.md)

One program, end to end, with the numbers at every stage.

</aside>