# 2.1 Local → Local

<aside>
🏠

**This is the default reader for the whole guide.**

You are a local business, your customers are local businesses, and somebody from your team has to physically show up to do the work.

If that is you, every unmarked rule in this guide is written for you.

</aside>

## 🏠 What Counts as Local to Local

Four things have to be true:

- 🚚 **You deliver in person.** Somebody drives, parks, and does the job
- 🗺️ **Your customers are businesses in your area.** Not consumers, not companies three states away
- 📍 **Your service radius has a real edge.** There is a distance past which a job stops being worth taking
- 🔁 **Winning more work means more capacity**, not just more software licences

Examples:

- 🧹 **Commercial cleaning** going after restaurants, dental practices and medical offices in one metro
- 🌿 **Landscaping and grounds maintenance** going after property managers and commercial sites within an hour's drive
- 🔧 **HVAC and mechanical contracting** going after office buildings, clinics and light industrial in the county
- 🔒 **Security and fire systems** going after retail strips, warehouses and schools in the city
- 🍽️ **Food distribution and linen services** going after restaurants and hotels on a delivery route

## 🎁 What You Get That Nobody Else Does

Three real advantages, and most local operators use none of them.

**Proximity is free proof.** "We already look after three restaurants on Pearl Street" does more work than any statistic, any case study, and any guarantee. It is on your record at no cost, it cannot be copied by a national competitor, and it gets stronger every time you win a job.

**You can show up.** A quote dropped in person, a business card left at reception, a van parked outside for an hour. None of that is available to somebody selling from three states away, and it converts.

**Your market is knowable.** A metro has a finite number of dental practices. You can build a list that is genuinely complete, know exactly who has heard from you, and work the same market for years without guessing what you missed.

## ⛓️ What Constrains You

The same things, seen from the other side.

**Your market has a floor and you will hit it.** A decomposed metro vertical yields a few thousand contactable records. At two to four thousand sends a month, that is six to eight months of program before you have spoken to everybody. That is not a failure, it is arithmetic, and it is why 3.3 exists.

**A scattered list produces work you cannot profitably do.** Win a contract ninety minutes outside your radius and the travel eats the margin. Geography is a qualification criterion here, not just a targeting filter.

**Density beats reach.** Five clients in one business park is a better book than twenty spread across a county. Route economics decide profitability, and your list should reflect that before your sales process has to.

**Your reputation is local and small.** Annoy the wrong facilities manager and it reaches the next one. Cold outbound in a tight market is not anonymous, which is a reason to be careful rather than a reason not to do it.

## 🔧 What This Changes in Practice

| Where | What it means for you |
| --- | --- |
| **Sourcing** (6.3) | Decompose one metro to ZIP level. Depth in a small area, not breadth across many |
| **Sizing** (3.3) | Run the ceiling check before you commit. If the market cannot support the goal, better to know in week one |
| **Offer** (07) | Trust and proximity do the work. Local references beat a bigger promise |
| **Copy** (9.4) | Location is your strongest personalization input, and it is free on every record |
| **Testing** (8.3) | Not enough volume for parallel tests. One variable at a time, slower learning |
| **Channels** (12) | Direct mail and drop-bys work here in a way they do not for remote sellers |
| **Expansion** (3.3) | Contact buckets first, then adjacent categories, then geography, then loosening qualification |

## ⚠️ Where Local to Local Operators Get It Wrong

- 🔎 **Querying the metro once and calling it the market.** One search returns a small and arbitrary slice. Pagination, query stacking and ZIP splitting compound, and the difference between doing all three and doing none is several times the list size. Section 6.3
- 🗑️ **Deleting the generic inboxes.** At this size the info@ address is read by the owner or their spouse. Deleting it removes a third to a half of your reachable market. Section 6.5
- 📏 **Ignoring the radius when building the list.** Filter on geography at build time, not when a reply arrives and you realise you cannot service it
- 🐌 **Treating a reply as a booked meeting.** The conversion happens on the phone, usually within the hour. Section 11.1
- 🔁 **Running the market twice in six months.** Local markets remember. Your suppression list is not optional here, and 6.7 covers what belongs in it

## 🌐 If This Does Not Sound Like You

If you could serve a customer five hundred miles away without changing anything about how you operate, you are running the other motion. Read **2.2 Business → Local** instead.

The data layer is identical either way. Almost everything downstream is not.

---

<aside>
➡️

**Next:** [2.2 Business → Local](2%202%20Business%20%E2%86%92%20Local%2014461a134ea182388338012a182aa586.md)

The other motion, and what changes when geography stops constraining you.

</aside>