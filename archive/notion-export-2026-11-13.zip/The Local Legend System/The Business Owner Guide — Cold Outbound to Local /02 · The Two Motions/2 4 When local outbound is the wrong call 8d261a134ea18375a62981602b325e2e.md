# 2.4 When local outbound is the wrong call

<aside>
🛑

**This page exists to save you money.**

Cold outbound works for most businesses selling to local businesses. It does not work for all of them, and the ones it fails usually could have known in twenty minutes.

Read this before you buy a single domain.

</aside>

## 🛑 Hard Stops

If any of these are true, do not start. Not "start carefully", do not start.

**Your market is too small to hold a program.**

Do the arithmetic before the optimism. A decomposed category in one metro might return 4,000 businesses. Hygiene, coverage and verification each take a cut, and roughly 30% of the business count survives as sendable contacts, so about 1,200. At the contact rates in 3.2, that is about a month of volume before you have spoken to everyone once.

If the market gives you less than about four months of volume, outbound is a campaign rather than a channel. It can still be worth running once, but do not build a program on it or promise yourself monthly meetings from it. Section 3.3 does this properly.

**Nobody can call back within the hour, and that will not change.**

On local, a positive reply is a cue to dial. The window closes fast. If replies are going to sit in an inbox until Thursday, you will manufacture expensive intent and then waste it, and you will conclude the leads were bad when the leads were fine.

This one is worth being honest with yourself about, because everybody says they will call back quickly and most people do not.

**Your offer has never closed.**

Outbound is an amplifier. It finds more of what already works. It does not discover what works. If nobody has ever paid you for this, go and sell it by hand first. Five conversations teaches you more than five thousand emails.

**You are selling to consumers.**

Different problem, different rules, different laws. Nothing in this guide transfers.

**You need revenue this month.**

Two weeks of warm-up, then a soft launch, then a ramp. First meetings land at six to eight weeks. Start it anyway if you can afford to, but do not start it *instead of* whatever is going to pay the bills in November.

**The deal is too small to carry the cost.**

A one-off job worth a couple of hundred with no repeat business rarely survives the maths once you add infrastructure, data, and the time spent working replies. Run the numbers in 3.4 before you assume it works. Recurring or high-ticket is where this channel earns its keep.

## 🔧 Fix These First, Then Come Back

Not disqualifiers. Just things that need to exist before the rest works.

- 📣 **No proof at all.** No case studies, no references, no logos. Fixable, and B1.4 covers how
- 🎯 **A vague offer.** If you cannot describe what you sell and to whom in one sentence, copy will not save it. Section 07
- ⏰ **No time.** Fifteen minutes a day once live, more in the first month. If that genuinely does not exist, either buy the time back or do not start. Section B2.1
- 💰 **No budget held for ninety days.** A program killed in month two costs you everything it cost and returns nothing. Section B1.3
- 🏭 **Your ICP is large commercial or industrial.** Then you do not have a local data problem at all. Those companies are in the standard databases. Use the ordinary playbook. Section 0.3

## 🏠 Extra Disqualifiers for Local to Local

- 🗺️ **Your radius is genuinely too small.** A rural service area with 300 businesses in it is not a market, it is a contact list. Outbound is the wrong tool. Referrals and local relationships will do more
- 🚚 **The geography produces work you cannot route.** If winning a job forty miles out loses money, filter it out at list-build time rather than discovering it at quote stage
- 🔥 **You already burned this market.** A bad campaign into the same metro six months ago is still in people's inboxes. Wait, change the sender identity, and change the offer before you go again

## 🌐 Extra Disqualifiers for Business to Local

- 🏗️ **Fulfilment cannot absorb the growth.** Your market is effectively unbounded, which means the constraint is you. Booking thirty meetings a month you cannot service is a worse problem than booking none
- 💸 **Your price does not match the tier.** Software priced for a fifty-person company sold to one-van operators will get replies and no deals. Either move up a tier or change the packaging

## ⏱️ The Twenty Minute Check

Before you spend anything:

1. 🔢 **Count the market.** Pick your categories and your geography, and get a rough business count
2. ✂️ **Multiply by 30%.** That is roughly what survives hygiene, coverage and verification as sendable contacts. Section 3.3 does it properly, stage by stage
3. 📅 **Divide by your monthly contact target.** That is how many months of volume you actually have
4. ⚖️ **Under four months?** Think hard. Under two? Do not build a program on it
5. 📞 **Ask who calls back, and how fast.** Name the person. If you cannot name them, that is your answer
6. ✅ **Ask whether the offer has closed before.** If not, go and sell it by hand first

Six questions. Twenty minutes. It is the cheapest work in this whole guide.

---

<aside>
📅

### The Market Is Fine but You Cannot Staff It?

That is the most common failure on this page, and it is a solvable one.

Book a call with Harvey and the Legacy GTM team will:

- 🎯 **Build you a free campaign**, not a pitch deck
- 📈 Show you how to get **15 to 30 qualified booked meetings a month** with local businesses
- 🛠️ Run the whole system so you never touch the software

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

## 🔄 If the Answer Is No, Do This Instead

A no on outbound is not a no on growth.

- 🤝 **Referral loops.** In local trades these convert better than anything outbound can reach. A cleaner and a landscaper share customers and do not compete. Section 12.4
- 🔍 **Local search and listings.** Inbound takes the demand that is already searching. Outbound takes the contracts nobody searches for. If your market is small, inbound is the better first investment
- 📞 **The phone, on its own.** A list of 300 businesses does not justify a domain estate. It absolutely justifies a phone and a fortnight
- ⬆️ **Go up a tier.** If tier one is too small or too cheap in your area, franchises and multi-location groups are fewer, richer and reachable with the same data
- 🔁 **Come back when something changes.** A new offer, a bigger radius, a second market, or somebody hired to work replies. Most nos here are temporary

---

<aside>
➡️

**Next:** [03 · Scale](../03%20%C2%B7%20Scale%20a7861a134ea182e6940d015247395b45.md)

The money model, and how to tell whether the market can actually support the number you have in mind.

</aside>