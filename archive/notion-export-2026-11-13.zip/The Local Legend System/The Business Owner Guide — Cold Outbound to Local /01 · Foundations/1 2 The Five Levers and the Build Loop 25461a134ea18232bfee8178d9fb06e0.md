# 1.2 The Five Levers and the Build Loop

<aside>
🎛️

**Five things decide whether outbound works. Everything else is detail.**

Learn them top down so you can see the money. Build them bottom up, because each one sits on the one below it.

</aside>

## 🪜 The Five Levers

| Lever | The question it answers | Where it lives |
| --- | --- | --- |
| 📈 **Scale** | How much do I need to send to hit my number? | Section 03 |
| ✍️ **Copy** | What do I actually say? | Section 09 |
| 🎁 **Offer** | What am I putting in front of them? | Section 07 |
| 🎯 **Prospect** | Who am I emailing, and where does that list come from? | Sections 05 and 06 |
| 📬 **Email deliverability** | Does it arrive at all? | Section 04 |

## 🔄 Taught Top Down, Built Bottom Up

**You learn Scale first** because it tells you whether any of this is worth doing. Working backward from a revenue number to a send volume takes an afternoon, and it can save you a quarter.

**You build from the bottom** because that is the order of dependency:

- 📬 A perfect email to a perfect prospect is worth nothing in a spam folder
- 🎯 Perfect deliverability into the wrong list produces nothing
- 🎁 The right list with a weak offer produces polite noes
- ✍️ A strong offer described badly gets ignored
- 📈 And scaling any of that before it works just produces more of what was not working

**So the build order is: deliverability, prospect, offer, copy, then scale.** That is exactly the order the sections run in, and it is why section 04 comes before section 09.

## 🔁 The Build Loop

Inside that order, the four middle levers feed each other in a loop. Get this wrong and you do expensive work twice.

1. 🎯 **Who you are emailing decides what you can pitch.** A one-van operator and a twelve-site group need different offers
2. 🎁 **What you pitch decides your campaigns.** One offer, one angle, one segment per campaign
3. 🗂️ **Your campaigns decide your copy.** The angle sets the opener
4. ✍️ **Your copy decides what data you need.** This is the step people miss
5. 📋 **Then you build the list**, enriched for exactly the fields the copy uses

**The list comes last on purpose.** Write the email you want to send, then go and find the data it needs. Do it the other way round and your copy is capped by whatever happened to be easy to collect.

## ⏱️ Except for One Thing

Infrastructure is bought on day one, before any of the above.

It takes two weeks to warm and that clock runs whether or not you have decided anything else. So you order domains and inboxes first, then do all the thinking while they warm.

Reading order and doing order are not the same. Section 0.5 has the full schedule.

## 🩺 The Same Five Levers Diagnose It

This is why the method is worth learning rather than just following.

When something stops working, you check the levers bottom up. Is it arriving, is it the right people, is it the right pitch, is it written well, are you sending enough.

The break is almost always lower than instinct suggests. Most people start at copy, which is the top, and on local it is the list about three times out of four. Section 10.4.

## ✅ What You Should Take From This Page

- Five levers: Scale, Copy, Offer, Prospect, Email deliverability
- Learn top down, build bottom up
- The loop runs ICP → offer → campaigns → copy → data
- Infrastructure is the exception and gets bought first
- The same five levers are how you diagnose a problem later

---

<aside>
➡️

**Next:** [1.3 What Local Changes, Lever by Lever](1%203%20What%20Local%20Changes,%20Lever%20by%20Lever%2074961a134ea1839cb7d98181a61675b9.md)

The most useful page to read before anything tactical.

</aside>