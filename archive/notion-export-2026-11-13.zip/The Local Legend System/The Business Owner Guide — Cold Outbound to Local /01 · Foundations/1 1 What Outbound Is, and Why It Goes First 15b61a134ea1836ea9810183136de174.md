# 1.1 What Outbound Is, and Why It Goes First

<aside>
🧱

**Outbound is going to them, rather than waiting for them to come to you.**

If you have never run it before, this page is the shape of the thing. If you have, skip to 1.3, which is where local starts diverging.

</aside>

## 🛒 Three Ways to Get Customers

Every business uses some mix of these. They are not equal and they are not interchangeable.

| Channel | What it is | Speed | Control |
| --- | --- | --- | --- |
| 🔍 **Inbound** | They find you. Search, reviews, referrals, word of mouth | Slow to build, compounds | Low. You cannot choose who arrives |
| 💰 **Paid** | You buy attention. Ads, directories, sponsorships | Fast | Medium. Stops when you stop paying |
| 📤 **Outbound** | You choose exactly who to contact and contact them | Weeks to first meetings | **High. You pick the customers** |

## 🎯 What Makes Outbound Different

Three properties, and the third is the one that matters most for a local business.

- 🎛️ **You control the dial.** Want more meetings next month? Send more. No other channel works like that
- 🎯 **You choose the customer.** Inbound brings you whoever turns up. Outbound lets you go after the twenty businesses you actually want
- 📈 **It is the only channel that reaches people who are not looking.** Most of your market is not searching for you today. They have a supplier, or they have not thought about it. Outbound is how you reach them anyway

That last point is the whole argument. A local business that relies on inbound is limited to the fraction of its market that happens to be shopping this month.

## 🪜 Why It Goes First

If you are building more than one channel, start here.

- ⚡ **It produces feedback fastest.** Two hundred emails tells you more about your offer in a week than three months of ads
- 🔬 **It tells you what to say elsewhere.** The angle that works in cold email is the angle that works on your website and in your ads
- 💸 **It is cheap to test and cheap to stop.** Paid spend disappears. Outbound infrastructure is a few dozen pounds a month
- 🧭 **It teaches you your own market.** Fifty replies, positive and negative, is genuinely better research than anything you can buy

Then inbound compounds underneath it, and paid amplifies whatever is already working.

## 🤖 Where AI Actually Fits

Worth being precise, because the claims around this are wild.

**What it genuinely changed:** research and enrichment at scale. Reading a thousand websites and answering a question about each one used to be impossible and is now routine. That is the part of this guide that would not have worked three years ago.

**What it has not changed:** whether your offer is any good, whether the person reading wants it, and whether somebody picks up the phone when they reply.

**What it has made worse:** volume. Everybody can now send more, badly. Which is exactly why data nobody else has, and a message that sounds like a person, matter more than they used to rather than less.

## 🚫 What Outbound Is Not

- ❌ **Not spam.** Spam is untargeted and unwanted at scale. This is a small number of relevant businesses contacted with something specific
- ❌ **Not a replacement for being good.** It amplifies. If the offer does not work, it amplifies that
- ❌ **Not instant.** Six to eight weeks to first meetings from a standing start
- ❌ **Not a numbers game.** Or rather, it is, but the numbers that matter are how many of the right people you reached, not how many emails you sent

## ✅ What You Should Take From This Page

- Outbound is the channel where you choose the customer
- It goes first because it produces feedback fastest and teaches you the most
- AI changed the research, not the fundamentals
- It works because it reaches the part of the market that is not looking for you

---

<aside>
➡️

**Next:** [1.2 The Five Levers and the Build Loop](1%202%20The%20Five%20Levers%20and%20the%20Build%20Loop%2025461a134ea18232bfee8178d9fb06e0.md)

The method the rest of the guide is organised around.

</aside>