# 12.1 Direct Mail to Local Businesses

<aside>
📮

**Almost nobody sends physical mail to local businesses, which is most of the reason it works.**

An owner who deletes forty emails a week without reading them will pick up and look at a card that arrived in the post.

</aside>

## 🎯 When Direct Mail Beats Email

Four situations where it is the better channel rather than a supplement.

- 🕳️ **The records email cannot reach.** Around 40% of any scrape returns no usable email address. You almost always have the postal address, which means a chunk of your market is reachable only this way
- 🪣 **Bucket three, where the ceiling is low.** A generic inbox with no name has the weakest email copy available. A physical item addressed to the business sidesteps that entirely
- 🏆 **Your A tier.** A manual channel deserves your best records. Section 5.3
- ⏳ **While the inboxes warm.** It needs no warm-up, so it can be live in week two. Section 10.1

## ✉️ What to Send

The rule is that it should not look like marketing.

- 📇 **A handwritten-style card** beats a printed flyer by a distance. It gets opened, it gets kept, and it sits on a desk rather than in a bin
- 📄 **One page maximum.** Same discipline as email. Nobody reads a brochure
- 🚫 **No glossy print.** The moment it looks professionally produced it becomes advertising
- 🖊️ **A real signature** and a real name
- 📌 **One ask**, and it should be easier than replying to an email

What you are buying is the thirty seconds between picking it up and deciding what it is. Everything about the format should extend that.

## 📱 The QR Code Changes Everything

The historic problem with direct mail is that it is invisible. You send a thousand cards and you learn nothing.

A QR code fixes it. A scan is an intent signal you can act on the same day.

**The routing looks like this:**

1. 📮 Card goes out with a QR code unique to that business
2. 📲 They scan it, which lands them on a page built for them
3. ⚡ The scan fires into a workflow, enriched with who they are
4. 🔔 It lands in a channel where somebody sees it in real time
5. 📞 Somebody calls them **that day**, while the card is still on the desk

That last step is the whole point. A scan is a warmer signal than an email reply, because they physically picked something up and chose to act on it.

**Everything in section 11 applies.** A scan is a cue to dial, and the window is just as short.

## 💷 Cost and Volume

Direct mail is expensive per touch and cheap per outcome, which is the opposite shape to email.

- 📧 A cold email costs a fraction of a penny
- 📮 A card costs somewhere between one and three pounds delivered, depending on volume and format

So the maths only works when you are selective:

- 🎯 **Send to hundreds, not thousands.** This is an A tier channel
- 💰 **Check it against your deal value.** At a £1,500 a month contract, a few hundred pounds of mail for one customer is comfortable. At a £200 one-off job it is not. Section 3.4
- 🔁 **Layer it, do not replace with it.** Mail into a segment you are already emailing, timed against the sequence

## ⏱️ Sequencing It Against Email

The strongest pattern is mail as the interruption in the middle of an email sequence.

| When | What happens |
| --- | --- |
| **Day 1** | Email one |
| **Day 3** | Email two |
| **Day 5** | Card posted |
| **Day 8 to 10** | Card lands. Email three references it: "sent you something in the post" |
| **On scan** | Call the same day |

The third email referencing the card is the move that makes the whole thing work. It connects two channels in the reader's head and turns you from an email address into something physical.

## 🛠️ The Stack

- 📮 **A print and post service** that takes an API or a CSV, so you are not going to the post office. [Thanks.io](http://Thanks.io) is the one we use
- 🔗 **A unique QR or short link per record**, generated at send time
- ⚙️ **A workflow tool** to catch the scan and enrich it
- 🔔 **A channel for the alert** where somebody actually looks
- 📊 **A table to log** sends, scans and outcomes, so you can measure it

## 📊 What to Measure

Direct mail gets judged on the wrong things. Track these:

- 📲 **Scan rate.** The equivalent of an open, and the only leading indicator you have
- 📞 **Scan to conversation.** Entirely about how fast you call
- 💰 **Cost per held meeting**, compared against email. This is the number that decides whether to continue
- 📈 **Lift on the email sequence** into the same segment, against a control that received no mail

That last one matters most and is almost never measured. Mail often works by making the emails land better rather than by producing direct responses, and a control group is the only way to see it.

## ⚠️ What Goes Wrong

- 🏢 **Sending to the business when you want the owner.** Address it to a named person wherever you have one
- 🖨️ **Making it look like a mailer.** Then it is treated like one
- 🐌 **Not calling on a scan.** The highest-intent signal in the whole program, wasted
- 📉 **Sending too few to learn anything.** A hundred cards tells you nothing. Two to three hundred minimum
- 🧾 **Not tracking cost per meeting**, so it gets cut on price rather than on performance

## ✅ Before You Move On

- Direct mail reserved for the A tier and the unreachable records
- A physical format that does not look like advertising
- A unique QR per record, routed to somebody who calls the same day
- Mail sequenced into the middle of an email sequence, and referenced in email three
- A control group so you can see the lift on email

---

<aside>
📅

### Want Someone to Do All of This for You?

Print, post, QR routing, real-time alerts and the call, all sequenced against the email campaign.

Book a call with Harvey and the Legacy GTM team will build you a free campaign and show you how to get **15 to 30 qualified booked meetings a month** with local businesses.

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [12.2 The Phone, LinkedIn and DMs](12%202%20The%20Phone,%20LinkedIn%20and%20DMs%202fb61a134ea18241a60281a4ac20baed.md)

Which channels work at which tier.

</aside>