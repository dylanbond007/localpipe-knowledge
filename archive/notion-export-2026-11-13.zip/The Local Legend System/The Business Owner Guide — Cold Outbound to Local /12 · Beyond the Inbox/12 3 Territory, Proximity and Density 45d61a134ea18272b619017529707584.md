# 12.3 Territory, Proximity and Density

<aside>
🗺️

**A won deal has to be serviced by somebody who drives there.**

Which means geography is a qualification criterion, not just a targeting filter. A scattered list produces contracts that lose money.

</aside>

**Applies to:** 🏠 **L→L only.** 🌐 **B→L**, skip to the section at the bottom.

## 🚚 Route Economics Decide Profitability

The thing that separates a good local book from a bad one is not the contract value. It is how far apart the jobs are.

- ⏱️ **Travel is unbillable time**, and it scales with distance while revenue does not
- 🔁 **Repeat and recurring work compounds the problem.** A weekly visit forty minutes away is forty minutes a week, forever
- 👥 **Crew utilisation falls.** Two jobs in a business park is a productive morning. Two jobs forty miles apart is a day
- ⛽ **Fuel and vehicle wear** are the visible cost and the smallest part of it

So a contract ninety minutes outside your radius can be worth less than no contract, and you will not find that out until you are servicing it.

## 🎯 Density Beats Reach

Five clients in one business park is a better book than twenty spread across a county.

- 🗓️ **Scheduling gets easier.** You can batch a day rather than building a route
- 💰 **Margin improves** without raising a single price
- 🤝 **Referrals compound.** Neighbouring businesses talk, and your visible presence becomes proof. Section 12.4
- 📈 **You can serve more customers with the same crew**, which is growth without hiring

**This should shape the list, not just the sales conversation.** Build outward from where you already work rather than evenly across a metro.

## 📏 Setting the Radius

Three numbers to decide before you build the list.

- 🥇 **Core radius.** Where you actively want work. Usually 20 to 30 minutes
- 🥈 **Extended radius.** Where you will take work if the value justifies it. Usually out to 45 minutes
- 🚫 **Hard limit.** Beyond this you do not sell, regardless of the contract

Then apply it at build time. Filter on drive time rather than straight-line distance where you can, because a river, a motorway or a city centre changes a fifteen-mile trip into an hour.

## 🧭 Decomposing Inside the Radius

Once the boundary is set, work inside it deliberately. Section 6.3.

- 🏙️ **ZIP or postcode level** in the dense core
- 🏘️ **City or town level** in the suburbs
- 🌾 **County level** at the edges, where there is less to find

**Then prioritise by cluster rather than by score alone.** A B-tier business on a street where you already have two customers may be worth more than an A-tier one forty minutes away, because the first one costs almost nothing to service and strengthens your proof.

## 🏘️ Proximity as Proof

Density is not just an economic argument. It is the strongest copy you have.

> "We already look after three businesses on Pearl Street."
> 

That line is available to you and structurally unavailable to a national competitor. It gets stronger every time you win a job, which means working a tight area compounds twice: once in margin and once in conversion.

Every new customer makes the businesses around them easier to win. Build the list to exploit that.

## 🌐 If You Sell to Local Businesses From Anywhere

None of the above binds you. The inverse page is short.

- ♾️ **No radius, no route economics.** Your constraint is fulfilment capacity, not drive time
- 📍 **Build rings around your existing customers anyway.** Not for servicing reasons, for proof. Fifteen to twenty miles around every account you already have gives you the same proximity line a local operator uses. Section 6.3
- 🗺️ **Work outward from your densest regions**, because that is where your proof is strongest and your copy writes itself
- 🕐 **Watch time zones** rather than travel time. Your send windows and your call windows both have to move

## ✅ Before You Move On

- A core radius, an extended radius and a hard limit, written down
- Geography applied as a filter at list build time, not at quote stage
- Drive time rather than straight-line distance where possible
- Prioritisation by cluster, not by score alone
- Proximity used deliberately in the copy

---

<aside>
➡️

**Next:** [12.4 Referral Loops and Recommendation Threads](12%204%20Referral%20Loops%20and%20Recommendation%20Threads%20c5461a134ea18383b14f01c3b4fbb0b3.md)

The highest-converting channel local has.

</aside>