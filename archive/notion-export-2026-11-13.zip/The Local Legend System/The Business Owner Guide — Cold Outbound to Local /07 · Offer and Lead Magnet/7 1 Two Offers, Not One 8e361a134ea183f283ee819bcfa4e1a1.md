# 7.1 Two Offers, Not One

<aside>
🎁

**You need two offers, and most people only build one.**

The core offer is what you sell. The lead magnet is what makes a stranger give you thirty minutes. Different jobs, different construction, and building only the first is why good campaigns produce replies that go nowhere.

</aside>

## 🧩 The Two

<aside>
💼

**The core offer**

What they actually buy. The contract, the retainer, the product, the programme.

Built for somebody who has already decided they have a problem and is choosing a supplier.

</aside>

<aside>
🎣

**The lead magnet**

What you ask for in the cold email. A free thing valuable enough to be worth thirty minutes of an owner's day.

Built for somebody who was not thinking about you thirty seconds ago.

</aside>

## 🪜 What You Pitch Cold Is the Next Step, Not the Sale

Nobody reads a cold email and signs a contract. The email is not trying to close anything. It is trying to earn one conversation.

So the thing you put in the email is the **smallest credible next step**, and the core offer stays in your pocket until you are on the call.

This is where most local campaigns break. The email pitches the retainer, the reader does the maths on a commitment they never asked for, and they delete it. The same reader would happily take a fifteen-minute call about a specific problem you noticed.

## 🏗️ Build in This Order

1. 🥇 **The core offer.** You cannot build a magnet for something that does not exist yet
2. 🎣 **The lead magnet.** Designed backwards from the core offer, so the conversation lands where you need it
3. 🔁 **Retention.** What keeps them, once they buy. Cheaper than acquisition and almost always ignored
4. 🪙 **A low-ticket entry product.** Last, if ever

## ⚠️ The Low-Ticket Mistake

There is a strong pull toward starting with something cheap, on the logic that a low price is easier to say yes to and volume will make up the difference.

On local it usually backfires:

- 💸 A small ticket cannot carry the cost of acquisition. Section 3.4 does that maths
- 🤝 The sales effort is nearly identical. A £400 job and a £4,000 contract take the same call
- 🚪 A cheap yes attracts the customers your anti-ICP was built to exclude
- 🔒 It anchors you. Going up in price with the same buyer is much harder than starting there

Start with the real offer. Use the magnet, not the price, to lower the barrier.

## 🎯 Why This Matters More on Local

Two reasons specific to this market.

**Your buyer has been burned.** Most local owners have paid somebody for marketing, leads or software and got nothing back. The commitment is not the obstacle, the risk is. A free, concrete first step does more work here than a discount ever will.

**Your market is finite.** Section 3.3. You cannot afford to burn the whole metro with an offer that produces replies you cannot convert. Getting the two-offer structure right before you scale matters more when there is no adjacent market to move to.

## 🌐 If You Sell to Local Businesses From Anywhere

One adjustment. Your buyer often does not know your category exists, so the magnet has to do a job the core offer normally would.

It has to establish that **the problem is solvable at all** before it can establish that you are the one to solve it. That usually means showing them the gap rather than explaining the solution, which is exactly what 7.4 is about.

## ✅ Before You Move On

- A core offer you can state in one sentence
- A separate free thing you could deliver on a fifteen-minute call
- Confidence that the email asks for the conversation, not the contract
- No low-ticket product built yet

---

<aside>
➡️

**Next:** [7.2 The Core Offer Gate and the Value Equation](7%202%20The%20Core%20Offer%20Gate%20and%20the%20Value%20Equation%2020761a134ea1822eb317017944e7b43b.md)

Three pass or fail tests, then the four dials that make an offer hard to refuse.

</aside>