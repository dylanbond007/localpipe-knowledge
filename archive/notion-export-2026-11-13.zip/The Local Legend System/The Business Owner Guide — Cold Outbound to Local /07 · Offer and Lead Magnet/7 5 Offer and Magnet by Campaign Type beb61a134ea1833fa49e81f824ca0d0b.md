# 7.5 Offer and Magnet by Campaign Type

<aside>
🗂️

**The same offer does not work in every campaign.**

What you pitch depends on two things: how crowded the category is, and whether the campaign is running on a trigger or running all the time.

</aside>

## 🧭 The Two Campaign Types

Every ICP produces two, and you run both.

<aside>
🐄

**Evergreen**

The broad list. Everybody in your category and geography who passes qualification.

Always on, pays the bills, and sets your volume floor.

</aside>

<aside>
📡

**Signal-based**

A smaller list, built on a trigger from 5.4. Hiring, a bad review, ads running, a second location.

Converts far better, runs as a trickle, and dries up if the signal does.

</aside>

## 📊 The Matrix

|  | 🔵 Blue ocean | 🔴 Red ocean |
| --- | --- | --- |
| **Evergreen** | Often no magnet at all. The offer is the news. Three sentences, plain value prop, direct ask | One repeatable, hard-to-copy magnet, run at scale. This is where the audit earns its keep |
| **Signal-based** | Keep the magnet light. The trigger is already most of the relevance | Fuse the magnet to the trigger. The audit is *about* the thing that just happened |

## 🔵 Blue Ocean, Evergreen: Do Less

The mistake here is building something clever.

If nobody is pitching this problem, you are the first person to raise it, and the reader has no comparison to make. Complexity actively hurts. A plain "we do X for Y without Z" and a direct ask converts better than anything you would build for a crowded market.

Save the magnet until reply rates tell you that being first is no longer enough.

## 🔴 Red Ocean, Evergreen: The Magnet Carries It

Everybody is claiming the outcome, so the outcome cannot be your differentiator.

What separates you is the free thing. One magnet, built properly, run on every prospect at scale. Hard to copy, specific to their business, and delivered live.

This is the case 7.4 was written for.

## 📡 Signal Campaigns: Lighter Is Better

When the trigger is strong, the email almost writes itself, and a heavy magnet gets in the way.

Somebody who posted a job for an office administrator yesterday does not need an audit. They need one sentence about the thing they are currently living with, and an offer of fifteen minutes.

**In a red ocean, fuse the two.** The magnet becomes about the trigger itself. They just opened a second location, so the audit is a coverage map of the new area. That is very hard for a competitor running a generic sequence to match.

## ⚖️ One Offer, Different Packaging

An important clarification, because people overbuild here.

You are not building four offers. You are building **one core offer** and changing how it arrives:

- Same outcome, same price, same delivery
- Different opening reason
- Different free thing in front of it, or none at all
- Different length of first email

If you find yourself building genuinely different offers per campaign, you probably have two ICPs rather than two campaigns, and 5.2 is the page to reread.

## 🧱 Build in This Order

1. 🥇 **Evergreen first.** It is the volume floor and it teaches you what lands
2. 📡 **One signal campaign second**, on the cheapest signal you have. Hiring or reviews
3. 🎣 **A magnet third**, once you know whether the plain version is working
4. 🔀 **More signals after that**, only if the first one lifted the numbers

Most people do this backwards, building an elaborate magnet before they have proof that anybody in the category replies at all.

## ✅ Before You Move On

- Which square of the matrix you are in
- An evergreen campaign defined, with or without a magnet
- One signal campaign planned on a cheap trigger
- Confidence that you have one offer in different packaging, not four offers

---

<aside>
➡️

**Next:** [08 · Campaign Architecture](../08%20%C2%B7%20Campaign%20Architecture%2080961a134ea182f8bb3781d978dee5fe.md)

What a campaign actually is, and how to test when the market is small.

</aside>