# 7.3 Reversing the Risk

<aside>
🛡️

**The objection they never say out loud is that it will not work for them.**

Not that it is too expensive. Not that they are too busy. They believe it might work in general, and they do not believe it will work in their business, in their town, with their crew.

A guarantee answers that before they have to raise it.

</aside>

## 🪜 The Guarantee Ladder

Four rungs, in order of how much risk you take on.

| Rung | What it sounds like | When to use it |
| --- | --- | --- |
| 1️⃣ **Implied** | "We have done this for four practices within a mile of you" | When you have local proof. The weakest formal promise and often the strongest in practice |
| 2️⃣ **Conditional** | "If you do X and it does not work, we do Y" | When delivery depends on them doing something. Names the condition honestly |
| 3️⃣ **Unconditional** | "Not happy in 30 days, full refund, no questions" | When your churn data says almost nobody will take it |
| 4️⃣ **Performance** | "X results or you do not pay" | Strongest, most dangerous. Only when you control enough of the outcome to predict it |

## ⚠️ Never Promise What You Cannot Survive

The obvious rule, routinely broken by people who have not run the numbers at scale.

A performance guarantee that gets claimed by 5% of customers is a cost of doing business. One claimed by 30% is insolvency. Before you offer any rung above the first:

- 📊 **Model the claim rate** at ten times your current volume, not at today's
- 🚪 **Write down the conditions** in plain words. If you cannot state them simply, they will be argued about later
- ⏳ **Put a window on it.** "30 days" is a guarantee. "Any time" is a liability
- 🎯 **Check you control the outcome.** Guaranteeing meetings is reasonable if you run the campaigns. Guaranteeing closed deals when somebody else takes the calls is not

## 🏪 What a Local Owner Actually Believes

This is where the ladder stops being theory.

**Specificity beats size.** "We will book you twelve meetings" is more believable than "we will transform your pipeline", because the first one can be checked and the second one sounds like the last person who took their money.

**A named local reference beats a bigger promise.** Every time. Being able to say "call Dave at the practice on Mill Road, he will tell you" is worth more than any refund policy, because it transfers the risk to somebody they can actually ring.

**They have been burned, and they assume you know it.** Acknowledging that directly, once, in plain words, does more than another line of reassurance. Something like: you have probably paid somebody for this before and got nothing. Here is what is different, and here is what happens if I am wrong.

**Small, real and honoured beats big and hedged.** A modest guarantee with no asterisks is stronger than a dramatic one with three conditions, because the conditions are what they are scanning for.

## 🌊 The More Crowded the Category, the Harder It Has to Work

In a market where nobody is pitching this, an implied guarantee and a local reference is usually enough. You are the first person to raise the problem, and the risk they are weighing is small.

In a market where they get four pitches a week, everybody is claiming the outcome. Your guarantee is one of the few things that can be structurally different rather than just better written, so it has to carry more of the load.

Section 5.5 tells you which one you are in.

## 🧯 Where to Put It

- 📧 **Not in the first cold email.** A guarantee in email one raises the objection before they were thinking about it, and reads as defensive
- 📞 **On the call, at the point they go quiet.** That silence is the objection. The guarantee is the answer to it
- 📄 **In the proposal, in writing.** Where they can show it to whoever else has a say
- 🎣 **The one exception:** if the magnet itself carries risk for them, cover that in the email. "It takes fifteen minutes and you keep the audit either way"

## ✅ Before You Move On

- The rung you are on, chosen deliberately
- Conditions written in plain words, with a window on them
- A claim rate modelled at ten times current volume
- At least one named local reference you have permission to use
- A plan for where the guarantee appears, which is not email one

---

<aside>
➡️

**Next:** [7.4 Lead Magnets for Owner-Operators](7%204%20Lead%20Magnets%20for%20Owner-Operators%204e361a134ea1832a8727013c57f2c1e2.md)

The free thing that earns the meeting, and why one type wins on local.

</aside>