# 00 · Start Here

<aside>
🧭

**What this section does.** Gets you pointed in the right direction in ten minutes. Which motion you are running, which tier of local business you sell to, and what good looks like before you send anything.

</aside>

**Applies to:** Both motions. This is the section that tells you which one you are.

## Chapters

1. **0.1 Who This Is For, and How to Read It.** The local-first premise, the two motions, the markers
2. **0.2 Pick Your Motion.** The two-minute decision, with worked examples
3. **0.3 The Three Tiers of Local Business.** Solo and small SMB, franchise and multi-location, enterprise-local
4. **0.4 The Numbers, and Where They Come From.** The benchmark table with its sourcing and confidence
5. **0.5 Launch in 15 Days.** The build schedule day by day, then the first 90 days

---

[0.1 Who This Is For, and How to Read It](00%20%C2%B7%20Start%20Here/0%201%20Who%20This%20Is%20For,%20and%20How%20to%20Read%20It%2054161a134ea1837b8b0e014859b9489d.md)

[0.2 Pick Your Motion](00%20%C2%B7%20Start%20Here/0%202%20Pick%20Your%20Motion%208f661a134ea1838192840113fad7c17e.md)

[0.3 The three tiers of local business](00%20%C2%B7%20Start%20Here/0%203%20The%20three%20tiers%20of%20local%20business%206d661a134ea183c09c30015e0d0f3a0b.md)

[0.4 The Numbers, and Where They Come From](00%20%C2%B7%20Start%20Here/0%204%20The%20Numbers,%20and%20Where%20They%20Come%20From%206f761a134ea183d3930181c7e048f6ba.md)

[0.5 Launch in 15 Days](00%20%C2%B7%20Start%20Here/0%205%20Launch%20in%2015%20Days%201b061a134ea183108c698102f24e3421.md)

---

<aside>
➡️

**Next section:** [B1 · Before You Start](B1%20%C2%B7%20Before%20You%20Start%2075b61a134ea183f5a11f01227052ba23.md)

In-house or hire it out, what it really costs, and building proof from nothing.

</aside>