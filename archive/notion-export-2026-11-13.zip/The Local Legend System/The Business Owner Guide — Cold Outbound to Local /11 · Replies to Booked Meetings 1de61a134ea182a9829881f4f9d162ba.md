# 11 · Replies to Booked Meetings

<aside>
📞

**What this section does.** A reply is the most expensive thing your system produces. This section turns it into a held meeting. The local-specific part is the biggest single point in the guide: on local, email is a signal channel and the conversion happens on the phone, usually within the hour.

</aside>

**Applies to:** Both motions for the playbook. **L→L only** for 11.4 and 11.5 — if you have a real sales team, the handoff problem is not yours.

## Chapters

1. **11.1 The reply is a cue to dial** — the intent window, and why a positive reply is not a booked meeting
2. **11.2 The seven reply types** — one right move each, including why referrals are gold
3. **11.3 Getting them to show** — the five-step show-up engine, and no-show recovery
4. **11.4 Who works the replies** — one named person, a written response window, and what to do when the honest answer is no
5. **11.5 The setter** — workflow, script and the numbers to hold them to, for the person who makes the first call

---

[11.1 The Reply Is a Cue to Dial](11%20%C2%B7%20Replies%20to%20Booked%20Meetings/11%201%20The%20Reply%20Is%20a%20Cue%20to%20Dial%20e4561a134ea1836a90440116199cf1b2.md)

[11.2 The Seven Reply Types](11%20%C2%B7%20Replies%20to%20Booked%20Meetings/11%202%20The%20Seven%20Reply%20Types%20fae61a134ea1826f9e77811ce8115276.md)

[11.3 Getting Them to Show](11%20%C2%B7%20Replies%20to%20Booked%20Meetings/11%203%20Getting%20Them%20to%20Show%20e8d61a134ea1839384c0819ceb238794.md)

[11.4 Who Works the Replies](11%20%C2%B7%20Replies%20to%20Booked%20Meetings/11%204%20Who%20Works%20the%20Replies%204a861a134ea18354aef381cedbe12518.md)

[11.5 The Setter](11%20%C2%B7%20Replies%20to%20Booked%20Meetings/11%205%20The%20Setter%20e2861a134ea18294aa5d0156c4ccc1fe.md)

---

<aside>
➡️

**Next section:** [B2 · Running It In-House](B2%20%C2%B7%20Running%20It%20In-House%203a961a134ea182929fa70177c581c8e4.md)

The time it takes, your first hire, and when to stop doing it yourself.

</aside>