# B1.2 What This Actually Costs

<aside>
💷

**The monthly bill is small. The time is not, and the wait is longer than people expect.**

Here is all three before you commit to any of it.

</aside>

## 📆 Month One: Setup

**Money**

- 🌐 Domains. A handful, renewed yearly
- 📬 Inboxes. Priced per mailbox per month, and this scales with volume
- 📤 Sequencer. A flat monthly fee at these volumes
- 🗺️ Data. Usually per successful find, so it scales with list size
- ⚙️ Enrichment, only if your offer needs the judgment layer

At the volumes in this guide, a few hundred a month is the normal range. Section 3.4 shows how to size yours properly.

**Time**

Roughly a working week, spread across fifteen days. Section 0.5 has the day-by-day.

The heaviest days are two and four: the thinking work, and the list build. Neither is difficult. Both take longer the first time than you expect.

**What you get by the end of month one:** infrastructure warmed, a list built, copy written, and a campaign that has just started sending. Possibly your first replies. Almost certainly no revenue.

## 📆 Month Two: Live

**Money.** The same monthly run rate. Data is the only line that moves, and only if you expand the list.

**Time.** Fifteen minutes a day, plus replies. The replies are the real number and they arrive whether or not you have time for them.

**What you get:** first meetings, usually somewhere in weeks five and six. First closed business depends entirely on your sales cycle. For a tier one local business that can be the same week.

## 📆 Month Three Onwards: Steady State

**Money.** Flat, unless you scale volume.

**Time.** Fifteen minutes a day, an hour a week, half a day a month, plus reply handling.

**What changes:** your cost per meeting starts falling. The infrastructure is bought, the list is built, the copy is written. You are now improving a working system rather than constructing one.

## ⏰ The Cost Nobody Puts in the Spreadsheet

Your hours.

Price them at what an hour of your time is actually worth and add it to the monthly total. For most owner-operators that number is larger than every tool combined.

It does not appear on a card statement, which is exactly why programs get judged on the software bill and cancelled for the wrong reason.

## 🕐 The Timeline, Honestly

| When | What exists |
| --- | --- |
| **Day 1** | Infrastructure ordered, warm-up running |
| **Day 7** | Everything built. Still cannot send |
| **Day 15** | First sends, at low volume |
| **Weeks 3 to 4** | First replies |
| **Weeks 5 to 6** | First meetings held |
| **Weeks 7 to 12** | Enough volume for the numbers to mean anything |
| **Month 3** | A judgement you can actually trust |

**Do not judge this at week four.** You will be looking at a sample, not a result. Section 8.3.

## 💰 What to Budget

Commit for **ninety days**, not month to month.

A program cancelled in month two costs you everything it cost and returns nothing, because the assets never got used. That is the most expensive way to run this, and it is more common than failure.

If you cannot hold the budget for ninety days, do not start yet. Section 2.4.

## 🧮 Two Things Worth Doing Before You Spend

1. 🎯 **Run the money model.** Revenue goal to contacts needed to monthly cost. An afternoon. Section 3.2
2. 🗺️ **Run the market check.** Does your market actually contain that many contacts? An hour. Section 3.3

If the second one comes back short, you have saved yourself three months and a few hundred pounds by spending an hour.

## ✅ Before You Move On

- A monthly cost figure for your volume, not a guess
- Your own hours priced in
- A ninety-day budget you can actually hold
- The money model and the market check both run
- No expectation of revenue before week six

---

<aside>
➡️

**Next:** [B1.3 Getting the Budget and the Buy-In](B1%203%20Getting%20the%20Budget%20and%20the%20Buy-In%2005961a134ea1824fa7aa018835720f6f.md)

The internal case, if you need to make one.

</aside>