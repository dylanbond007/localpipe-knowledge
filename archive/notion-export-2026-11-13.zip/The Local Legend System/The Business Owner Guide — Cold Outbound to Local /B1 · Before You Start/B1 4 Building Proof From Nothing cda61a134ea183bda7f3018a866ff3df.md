# B1.4 Building Proof From Nothing

<aside>
🌱

**No case studies, no logos, no references, and a reader who has been burned before.**

This is a real problem and it is solvable. What it is not is a reason to wait until you have proof before you start, because you get the proof by starting.

</aside>

## 🔄 Replace Proof With Specificity

When you cannot say "we did this for them", say something so specific that it could only come from somebody who understands the problem.

- ❌ **Weak:** "We help local businesses get more customers"
- ✅ **Strong:** "Most plumbing firms we speak to are losing two or three jobs a week to missed calls between 4 and 6pm"

The second one contains no proof at all. It works because only somebody who knows the trade would say it, and that is a form of credibility.

**Specificity is the substitute for evidence**, and it is available to you on day one.

## 🏘️ Use Proximity Before You Have Results

The strongest asset available to a local business with no track record.

> "We're based in the same industrial estate."
> 

> "We already do two jobs a week on your street."
> 

> "I drive past your yard every morning."
> 

None of that is a result. All of it is true, checkable, and impossible for a national competitor to say. Section 12.3.

## 🔍 Show Them Something Real Instead

If you cannot show them what you did for somebody else, show them something about **them**.

The audit from 7.4 does exactly this job. A free, specific, checkable finding about their business proves competence in a way a testimonial cannot, because they can verify it themselves in thirty seconds.

**This is why the audit is the right magnet for a business with no proof.** It substitutes demonstration for reputation.

## 🧱 Borrow Credibility Honestly

Four things that are legitimately available before you have customers.

- 🛠️ **Your own experience.** Years in the trade, jobs done, what you did before this. That is real and it is yours
- 📜 **Certifications, insurance, accreditations.** Dull, and they answer a real worry
- 🔧 **Your process, described concretely.** Somebody who can explain exactly what happens in week one sounds like somebody who has done it
- 👤 **Your own name and face.** A real person with a real phone number outperforms a faceless brand at this size

**What you never do is imply results you have not had.** Local markets are small and it gets found out.

## 🎯 Manufacture the First Three Deliberately

Your first three customers are not just revenue. They are the proof that unlocks the next thirty. Pick them accordingly.

- 🏅 **Choose recognisable over profitable.** A known local name is worth more than a slightly bigger contract from an anonymous one
- 🤝 **Agree the case study up front**, as part of the deal. Far easier than asking six months later
- 📏 **Measure something from day one.** You cannot write a case study about a job you did not instrument
- 💷 **Discount for the story, not for the work.** If you need an incentive, trade price for a reference and a testimonial, and say so plainly

## 📣 What a First Case Study Needs

Short. Four things:

- **Who they are**, by category and area. Named if they allow it
- **What was happening before**, in their words
- **What you did**, in one or two sentences
- **What changed**, with one number

One paragraph and one number beats a designed PDF. Local buyers want to know it is real, not that it is polished.

## 🕐 What Changes at Three, Ten and Thirty

- 3️⃣ **Three customers.** You can say "businesses like yours" and mean it. Proximity claims become available in specific areas
- 🔟 **Ten.** Patterns appear. You can say what usually happens, and that is a different kind of authority
- 3️⃣0️⃣ **Thirty.** You can segment. "The four dental practices we work with" is a much sharper claim than "our clients"

Each stage changes what your copy can say. Rewrite the proof section of your emails at each one rather than letting it go stale.

## ✅ Before You Move On

- One specific observation about your trade that proves you know it
- A proximity claim you can make honestly today
- An audit you can deliver free, in fifteen minutes
- A plan for your first three customers, chosen for their story as well as their money
- Case study permission agreed up front rather than asked for later

---

<aside>
➡️

**Next:** [01 · Foundations](../01%20%C2%B7%20Foundations%20e4f61a134ea1820d873e01c86b3d38e3.md)

What outbound is, the five levers, and what local actually changes.

</aside>