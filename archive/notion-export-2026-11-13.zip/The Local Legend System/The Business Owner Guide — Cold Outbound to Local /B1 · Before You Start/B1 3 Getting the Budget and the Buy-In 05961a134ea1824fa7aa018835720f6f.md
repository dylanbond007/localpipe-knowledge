# B1.3 Getting the Budget and the Buy-In

<aside>
💼

**If you sign your own cheques, skip this page.**

If somebody else has to approve the spend, this is how to ask so that it survives month two.

</aside>

## 🧮 Let the Maths Do the Arguing

The weakest version of this pitch is enthusiasm. The strongest is arithmetic somebody else can check.

Walk it backwards, out loud:

> We want **X** new customers. We close roughly **one in three** qualified conversations, so that is **3X** conversations. Half our meetings qualify, so **6X** meetings. Three quarters show up, so **8X** bookings. Half of positive replies book, so **16X** positive replies. One positive reply per seventy-five contacts, so **1,200X** contacts.
> 

Then the cost, then the cost per customer, then that number next to what a customer is worth.

Nobody argues with that structure. They argue with the conversion rates, which is a much better conversation to be having, because it means you are discussing the model rather than the idea.

## ⚖️ Frame It Against What You Already Spend

The comparison that lands is not "this is cheap". It is "this is cheaper than the thing we already do".

- 💰 What does a customer cost you through paid advertising right now?
- 🤝 What does a trade show cost, including two days of somebody's time?
- 🔍 What have you spent on search or directories in the last year, and what came of it?

Most local businesses are already spending on acquisition and have never worked out the cost per customer of any of it. Doing that calculation for one existing channel makes your case for you.

## 🎯 Promise the Right Thing

This is where these programs get killed, and it is usually self-inflicted.

<aside>
❌

**Do not promise**

A number of meetings in month one.

Revenue by a specific date.

A conversion rate you have not measured yourself.

</aside>

<aside>
✅

**Do promise**

A working system live by day fifteen.

A measurable cost per meeting by day ninety.

A clear go or no-go decision at day forty-five.

</aside>

Promise the **process and the decision point**, not the outcome. You do not control the outcome in month one and pretending you do is how a program that was working fine gets cancelled for missing an invented target.

## 📅 Ask for Ninety Days, Reviewed at Forty-Five

The structure that survives.

- 💷 **Ninety days of budget**, committed. A program cancelled at day sixty costs everything and returns nothing, because the assets never got used
- 🔍 **A review at day forty-five**, on leading indicators rather than revenue. Deliverability, reply rate, contacts per positive reply
- 🚦 **An agreed kill criterion**, set in advance. "If we are not at one positive reply per hundred contacts by day forty-five, we stop"

Naming the kill criterion yourself is the single most persuasive thing in this whole conversation. It says you are running an experiment with a stopping rule rather than asking for faith.

## 📊 What to Report, and When

Agree this up front so nobody is surprised.

- 📆 **Weekly, one line.** Sends, replies, meetings booked. Nothing else
- 📈 **Day forty-five.** The leading indicators against benchmark, and the go or no-go
- 🧾 **Day ninety.** Cost per meeting, cost per customer, and your own conversion rates replacing the assumptions

**Report opportunities, not activity.** Emails sent is a number that makes people nervous. Meetings held is a number that makes people comfortable.

## 💸 If the Answer Is a Smaller Budget

Common, and workable. Reduce volume rather than quality.

- 📉 Run one campaign instead of three
- 🎯 Work your A tier only
- 🗺️ One category and one geography rather than a full market
- ⏳ Accept that ninety days becomes a hundred and twenty

**What you do not do is cut the infrastructure or the data.** A cheap list on cheap domains produces a bad result that proves nothing, and then the answer next time is no.

## ✅ Before You Move On

- The backward maths written out, with your own assumptions visible
- A cost per customer comparison against one channel you already run
- A promise about process and decision points, not outcomes
- Ninety days asked for, forty-five days as the review
- A kill criterion you proposed yourself

---

<aside>
➡️

**Next:** [B1.4 Building Proof From Nothing](B1%204%20Building%20Proof%20From%20Nothing%20cda61a134ea183bda7f3018a866ff3df.md)

What to say when you have no case studies.

</aside>