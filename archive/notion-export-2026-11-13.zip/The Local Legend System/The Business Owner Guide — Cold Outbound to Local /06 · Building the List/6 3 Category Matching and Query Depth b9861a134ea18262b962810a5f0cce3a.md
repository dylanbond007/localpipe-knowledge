# 6.3 Category Matching and Query Depth

<aside>
🎯

**One query per city returns a small and arbitrary slice of what exists there.**

The techniques on this page routinely take a vertical from 200 businesses to 900. Nothing about them is clever. They are mechanical, and most people skip all three.

</aside>

## 🏷️ Match Categories, Do Not Search Keywords

Maps runs a defined taxonomy of roughly **4,000 categories**, and almost every real offer spans several of them.

<aside>
🔤

**Free text search**

Returns whatever the ranking algorithm believes fits a phrase.

Search "restaurants" and you get a lot of things that are not restaurants, and you miss plenty that are.

</aside>

<aside>
🏷️

**Category matching**

Only accepts businesses that carry the category itself.

That is a membership question, and it has a determinate answer.

</aside>

## 🧩 Three Category Problems to Plan For

- 🔀 **Multiple categories.** A business carries one primary category and several secondary ones. Query the primary alone and you miss businesses that classify themselves differently from how their customers describe them
- ❌ **Wrong categories.** Owners pick their own, sometimes badly, sometimes years ago when the business did something else
- 🌱 **Drifted categories.** A company listed as a handyman service that now does full kitchen renovations still shows up under the old classification

**Build the category set deliberately wider than feels necessary, then filter on the record afterwards.** Filtering is cheap and reversible. A business you never sourced is invisible, and you will never know it was there.

## 📈 Three Techniques That Multiply Your Market

### 1️⃣ Pagination depth: about +84%

Going past the first page of results.

The highest-return change available and the one most commonly skipped, because page one looks like an answer. It is not an answer, it is the first twenty.

### 2️⃣ Query stacking: about +23%

Several query phrasings under the same geographic tile.

Ranking is phrase-sensitive even when the underlying category is identical. "Commercial cleaning", "office cleaning", "janitorial services" and "cleaning company" return overlapping but different sets.

### 3️⃣ Geographic splitting: roughly 2x

Dropping to ZIP level in dense verticals.

Each smaller query centre gets its own bounded result set, so splitting one city into fifteen ZIPs gives you fifteen result sets rather than one.

## ✖️ They Compound

This is the part worth reading slowly. The three do not overlap, because each one beats a different limit.

A vertical returning **200 businesses** on a single first-page city query returns:

- 📄 Roughly **370** with full pagination
- 🔤 Roughly **450** with query stacking added
- 🗺️ Roughly **900** with ZIP-level splitting on top

Same category, same city, same day. Four and a half times the market, from three mechanical changes.

If your market sizing in 3.3 came back short, this is the first place to look, before you touch geography or loosen your qualification criteria.

## 📏 Grain Follows Density

Do not split everything to ZIP level. Match the grain to how many businesses are actually there.

| Area | Query at |
| --- | --- |
| Dense urban core | ZIP or postcode level |
| Suburbs and small towns | City level |
| Rural | County or region level |

Splitting a rural county into ZIPs just returns the same fifteen businesses fifteen times and costs you fifteen queries.

## 🌐 If You Sell to Local Businesses From Anywhere

Your decomposition axis is different, and this is the one page in section 06 where that matters.

- 🗺️ **Go wide before you go deep.** Category depth across many metros beats ZIP-level depth in one. You are not constrained to a drive time, so use that
- 📍 **Build rings around your existing customers.** Take every customer you already have and source in a fifteen to twenty mile radius around each one, or across the same state. That gives you the one thing a remote seller usually cannot get: a genuine proximity claim. "We look after a plumbing company fifteen minutes from you"
- 🔁 **Then work outward from your densest regions**, because those are where your proof is strongest

Pagination and query stacking still apply exactly as written. Only the geographic splitting changes shape.

## ⚠️ Watch For

- 🔁 **Duplicates across overlapping queries.** Stacking and splitting both generate them by design. Deduplicate on the stable listing identifier
- 💸 **Query costs at volume.** Splitting multiplies your query count. Sourcing is cheap, at roughly a dollar per thousand businesses, but it is not free
- 🚫 **Category drift in your own set.** Review the category list once a quarter. Taxonomies change and so do businesses

## ✅ Before You Move On

- A category set built wider than felt comfortable
- Pagination running past page one
- Several query phrasings per geographic tile
- Geographic grain matched to density, not applied uniformly
- Deduplication on a stable identifier, not on business name

---

<aside>
🔑

### Or Have the Depth Built In

Pagination, stacked phrasings and exact category matching against the full 4,000-category taxonomy are exactly the things that get skipped when you are doing this by hand.

LocalPipe is the local business database this guide runs on:

- 🏷️ **Exact category matching** across the full Maps taxonomy, not keyword guessing
- 📄 Deep pagination and multi-location batching handled for you
- 👤 **75%** owner name find rate
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- ✅ **Triple verified**, with **sub 1% bounce** on raw exports

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

<aside>
📅

### Want Someone to Do All of This for You?

Book a call with Harvey and the Legacy GTM team will build you a free campaign and show you how to get **15 to 30 qualified booked meetings a month** with local businesses.

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [6.4 The Four Contact Buckets](6%204%20The%20Four%20Contact%20Buckets%204ab61a134ea18394b78c818b6be4500a.md)

The most underrated model in local, and the cheapest volume you will ever add.

</aside>