# 6.4 The Four Contact Buckets

<aside>
📬

**One business does not mean one contact.**

This is the single most transferable idea in the guide, and the cheapest volume you will ever add. Most operators work one address per business and leave half their market on the table.

</aside>

## 🪣 The Four Buckets

Every local record, once enriched, lands in one of four.

| Bucket | Looks like | What it is |
| --- | --- | --- |
| **1. Owner direct** | [dan@brightcleaning.com](mailto:dan@brightcleaning.com) | A personal address tied to the owner, on the business domain. Highest intent of the business-domain buckets, lowest volume, and the one most operators assume is the only one worth having |
| **2. Generic inbox, owner known** | [info@brightcleaning.com](mailto:info@brightcleaning.com), and you know Dan runs it | A role address where enrichment also resolved the owner's name. The most underrated of the four, because the name makes copy possible that the address alone does not support |
| **3. Generic inbox, no name** | [contact@brightcleaning.com](mailto:contact@brightcleaning.com) and nothing else | A role address with no resolved owner behind it. Lowest personalization ceiling, still worth sending to, and usually the largest bucket by volume |
| **4. Personal provider** | [brightcleaningdan@gmail.com](mailto:brightcleaningdan@gmail.com) | A free provider address on a local record. **Nine times out of ten the owner is reading this personally.** The most direct line you will get, and the only bucket that needs its own sending infrastructure |

## 🔑 Why the Fourth Bucket Is Not an Afterthought

On a corporate record, a gmail address means somebody mistyped something or the data is old. On a local record it means the opposite.

A business started by one person with a truck set up a free address, the business grew, and nobody ever saw a reason to migrate. That address never got handed to an office manager, never became a shared inbox, and never got a filter put in front of it. **It is still the owner's phone buzzing.**

So by directness this is the strongest bucket you have. It is numbered fourth because it is the most operationally demanding, not because it is worth the least.

<aside>
⚠️

**It does not share infrastructure with the other three.** Bucket four sends from its own domains, on its own ramp, with its own budget. Bounce runs about a third higher and it burns infrastructure faster than business-domain sending. Section 4.6 is the whole build.

</aside>

## 🔄 The Reframe

In corporate outbound, the **account** is the unit. You find the right person, you contact them, and every other address at that company is noise to be filtered out.

Local works the other way around. A single business often yields an owner-direct address *and* a generic inbox, and **both of them reach the same person**. The owner reads info@ because there is nobody else to read it.

> **Stop asking which address is correct for this business.**
> 

> **Start asking which campaign each address belongs in.**
> 

## 💰 Why This Is the Cheapest Volume You Have

Run the numbers on a market of 2,000 businesses at a 42% owner-email find rate.

- 📧 **Working one address per business:** roughly 840 sends
- 📬 **Working every usable bucket on the same records:** materially more, from the same sourcing spend

You have already paid to find these businesses. You have already paid to enrich them. Bucket expansion costs nothing extra and it is the first lever to reach for when sizing comes back short in 3.3, before adjacent categories and long before geography.

Local markets are finite. A corporate operator who exhausts a segment moves to an adjacent one. A local operator who exhausts a metro has to expand geography, expand categories, or stop. **Bucket expansion adds volume without doing any of those.**

## ⚖️ The Rule This Seems to Break

There is a well-known rule in outbound: cap yourself at around five contacts per company, because going past it is the fastest way to get marked as spam and lose the whole account.

That rule is correct, and it is about something different.

<aside>
👥

**Multiple people at one account**

Emailing the CEO, the CFO, two VPs and a director at the same company about the same thing.

Five inboxes, five humans, one of whom will notice and report you.

</aside>

<aside>
🎯

**Multiple routes to one person**

Emailing dan@ and info@ at an eleven-person business.

Two addresses, one human, who is expecting mail at both.

</aside>

**The local rule: two to three routes per business, one persona.**

Worth saying plainly that this is the most contested position in this whole guide. It works, it is what we run, and there is no controlled study behind it. Sequence the buckets rather than sending them the same day, and watch complaints rather than assuming.

## 📊 What Each Bucket Is Worth

|  | 1. Owner direct | 2. Generic, owner known | 3. Generic, no name | 4. Personal provider |
| --- | --- | --- | --- | --- |
| **Volume** | Low | Medium | Highest | Varies by trade, often substantial |
| **Who reads it** | The owner | The owner or someone close to them | Whoever is on the desk | The owner, personally, about 9 times out of 10 |
| **Reply quality** | High | Close to owner direct in several verticals | Moderate, with more routing replies | Highest, and the most direct |
| **Personalization available** | Name, location, category | Owner name in third person, location, category | Location, category, visible signals only | Name, location, category. Write it like a message to a person |
| **Infrastructure** | Primary domains | Primary domains | Primary domains, monitored separately | **Its own estate.** Section 4.6 |
| **Expected bounce** | Low | Low | Low to moderate | About a third higher |

Bucket three is usually the largest by volume, so a lower ceiling on a much bigger base still produces a meaningful share of total opportunities. Do not judge it against bucket one. Judge it against not sending at all.

Bucket four is the opposite shape. Smaller, harder to run, and the closest thing to a direct line you will ever have.

## 🏷️ Assigning the Bucket

This happens after enrichment, as the last step before segmentation.

1. 📮 **Is the address on a free provider?** → bucket four, regardless of anything else. Infrastructure decides this one first
2. 👤 **Owner email resolved, personal format, business domain** → bucket one
3. 🏢 **Only a role address resolved, but an owner name did** → bucket two
4. 📭 **Only a role address, no name** → bucket three
5. 🔍 **Low-confidence owner names go to bucket three**, not bucket two. A wrong name is worse than no name

No record appears in more than one bucket. That is one of the pre-send checks in 6.7.

## ✅ Before You Move On

- Every enriched record assigned to exactly one of the four buckets
- Bucket four separated first, because it decides which estate the record sends from
- Four campaigns planned, not one
- Low-confidence names demoted rather than used

---

<aside>
📅

### Want Someone to Do All of This for You?

Book a call with Harvey and the Legacy GTM team will build you a free campaign and show you how to get **15 to 30 qualified booked meetings a month** with local businesses.

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [6.5 Generic and Free-Provider Inboxes in Practice](6%205%20Generic%20and%20Free-Provider%20Inboxes%20in%20Practice%2088e61a134ea182a68540815d7e370d17.md)

Two things every experienced operator has to unlearn.

</aside>