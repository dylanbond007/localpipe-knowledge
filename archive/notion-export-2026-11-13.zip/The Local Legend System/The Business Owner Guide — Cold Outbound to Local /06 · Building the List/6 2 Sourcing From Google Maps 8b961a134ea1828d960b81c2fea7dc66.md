# 6.2 Sourcing From Google Maps

<aside>
🗺️

**Google Maps is a consumer directory being used as a sales database.**

Most sourcing mistakes come from forgetting the first half of that sentence. It was built so somebody could find a plumber at 9pm, not so you could run a campaign.

</aside>

## 📋 What a Raw Record Actually Holds

| Field | Present | What it is good for |
| --- | --- | --- |
| **Business name** | Almost always | Matching, deduplication, personalization |
| **Category** | Almost always | Your primary targeting axis |
| **Address** | Usually, hidden for service-area businesses | Geographic targeting and proximity claims |
| **Phone number** | Usually | The follow-up call after a positive reply. Usually the business line, but on smaller owner-run businesses it is very often a personal mobile, which is the number you actually want |
| **Website** | Roughly 70 to 80% | The entry point for enrichment, and a quality signal in itself |
| **Review count** | Usually | A reasonable size proxy. The star rating on its own tells you very little, so score the count and ignore the stars |
| **Opening hours** | Usually | Whether they are trading, and send timing |
| **Email address** | ❌ Never | Not a field Maps carries |
| **Owner name** | ❌ Never | Also not a field Maps carries |

**The last two rows are the whole problem.** Maps tells you a business exists. It tells you nothing about who runs it, so every contact you eventually send to is the product of a separate resolution step that you have to build or buy. That is 6.6.

## 🏠 The Service-Area Business Catch

Plenty of local businesses hide their address, because they work out of a van and do not want customers turning up at their house.

Maps shows them as serving an area rather than sitting at a point. Two consequences:

- 📍 Your geographic filtering has to handle both, or you silently drop a chunk of exactly the owner-operators you want
- 🏘️ A hidden address is itself a mild signal. It usually means small, mobile and owner-run

## 🔄 The Five-Stage Loop

Every list gets built the same way. The order is not a suggestion.

1. 🔍 **Search.** Category-matched queries across a geography you have deliberately broken up
2. 📥 **Export.** Raw business records, deduplicated across overlapping queries
3. 🧹 **Hygiene.** Remove closed, duplicated, franchised, out-of-scope records
4. 💰 **Enrich.** Resolve owner names and addresses. **This is where the money goes**
5. 📬 **Segment.** Sort into contact buckets and route each to its own campaign

Stage four is the one that costs. Everything before it is cheap, and everything before it decides how much you spend on stage four. Get the order wrong and you pay to enrich records you are about to throw away.

## 🧭 Four Rules That Save Real Money

**Pull accounts first, contacts later.** Your first pass is businesses only. No enrichment, no email finding. You are building a picture of the market, not a send list.

**Deduplicate on a stable listing identifier, never on business name.** Overlapping queries will return the same business repeatedly, and business names are inconsistent enough that name matching either misses duplicates or merges two different companies. Domain-level deduplication comes later, after enrichment.

**Sample before you run at volume.** Pull five to ten records by hand, look at them properly, and estimate the cost of the full run. Ten minutes here regularly saves a few hundred pounds and a wasted afternoon.

**Check what "closed" means.** Maps distinguishes permanently closed from temporarily closed, and both appear in exports. Permanently closed comes out at hygiene. Temporarily closed is worth a look, because in some trades it means seasonal rather than dead.

## ⚠️ What Goes Wrong Here

- 🔎 **One query per city.** The single most common and most expensive mistake. 6.3 is entirely about fixing it
- 🏷️ **Searching keywords instead of matching categories.** You get whatever the ranking algorithm thinks fits a phrase. Also 6.3
- 💸 **Enriching everything.** Enrich after filtering, never before. Section 6.7
- 📛 **Deduplicating on name.** Two businesses called Smith Plumbing in the same metro are two businesses
- 🗑️ **Discarding records without a website.** Around 20 to 30% have none, and they are often the smallest and most owner-run. Harder to enrich, not worthless

## ✅ Before You Move On

- A clear idea of what you get free on every record, and what you have to resolve yourself
- Geographic filtering that handles service-area businesses
- Deduplication on a stable identifier
- A five-to-ten record sample, and a cost estimate, before any full run

---

<aside>
➡️

**Next:** [6.3 Category Matching and Query Depth](6%203%20Category%20Matching%20and%20Query%20Depth%20b9861a134ea18262b962810a5f0cce3a.md)

The three techniques that multiply the size of your market.

</aside>