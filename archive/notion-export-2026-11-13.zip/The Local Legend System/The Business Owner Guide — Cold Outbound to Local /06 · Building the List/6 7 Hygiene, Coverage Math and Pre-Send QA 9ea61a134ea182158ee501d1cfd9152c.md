# 6.7 Hygiene, Coverage Math and Pre-Send QA

<aside>
🧹

**Scraping is cheap. Enrichment is the expensive line.**

Every record you pay to resolve and then throw away is pure waste, and most people generate a lot of it by doing these steps in the wrong order.

</aside>

## 🔀 Filter Before You Enrich

<aside>
❌

**The common order**

Scrape 10,000

**Enrich 10,000** ← you pay here

Filter to 6,400

2,700 usable contacts

</aside>

<aside>
✅

**The correct order**

Scrape 10,000

Filter to 6,400

**Enrich 6,400** ← you pay here

2,700 usable contacts

</aside>

Identical output. **Roughly 36% less enrichment spend.**

Only two filters have to run *after* enrichment: domain-level deduplication, and contact bucket assignment. Everything else can and should happen before you spend a penny.

## 🗑️ What Hygiene Actually Removes

Run these on the raw export, before enrichment:

- 🚪 **Permanently closed.** Maps flags it, and local churn means there is always a meaningful share
- 🔁 **Duplicates across overlapping queries.** On the stable listing identifier, never on business name
- 🏷️ **Out of category.** The cost of building your category set deliberately wide, and it is a cost worth paying
- 🏢 **Chains and franchises you cannot sell to.** Either because head office decides, or because they already have a national supplier
- 📍 **Outside your serviceable geography.** Filter at build time, not when a reply arrives you cannot fulfil
- 🎚️ **Below your scoring threshold.** The D tier from 5.3. Cut it here rather than emailing it later

## 📉 Then Size What Is Left

Sizing happens in stages, and the number that matters is verified sendable contacts rather than business count.

The full method, with the four cuts and the worked example, is in **3.3**. Two things to carry into this page:

- 📬 **Bucket expansion pushes the number back up.** Many businesses give you two usable addresses
- ✅ **Verification takes roughly half of it back down.** Plan on keeping about half of what enrichment returns

If the final figure does not support your plan, the expansion order in 3.3 is what to do about it. Do not solve a sizing problem by lowering your hygiene standards.

## 🚫 Suppression

The list nobody builds until they have been burned once.

Load all of these before the first send:

- 🤝 **Existing customers.** Obvious, routinely forgotten, and deeply embarrassing
- 💬 **Open conversations and live quotes.** Somebody mid-negotiation should not receive a cold email
- ✋ **Anyone who has unsubscribed or asked you to stop**, ever, across any campaign
- 🔁 **Anyone you contacted in the last six months.** Local markets remember, and re-running the same market with the same angle is how complaints happen
- 🏘️ **The same market across different campaigns.** If two of your campaigns overlap on a category and a geography, dedupe across them before either sends

Suppression is a single list, loaded into every sending domain. Not a note in a spreadsheet.

## 📤 Export Discipline

Boring, and it prevents a specific set of launch-day disasters.

- 🔑 **Deduplicate on the email address column** as the final step, after everything else
- 🧾 **Export only the fields you need**, plus the campaign variables. Hide working columns
- 📁 **One consistent naming convention** per market and per campaign. `category-metro-bucket-date`
- 🗂️ **One file per bucket.** Four buckets means four files means four campaigns. Do not combine and filter later

## 🧪 Pre-Send QA

Most of these take minutes. Run every one before the first message of a campaign leaves.

- 👀 **Sample twenty to thirty owner names manually** against the live source, and record the error rate
- 💥 **Bounce test a holdout slice** of two to three hundred records before committing the list
- 🔍 **Check every merge field** for null, empty and malformed values
- 📝 **Confirm fallback copy renders** correctly wherever a merge field is missing
- 🪣 **Confirm no record appears in more than one bucket**
- 🌐 **Confirm domain-level deduplication has run** after enrichment
- 🚫 **Check against suppression**, all of it
- 📮 **Confirm bucket four is routed to its own infrastructure**, not the main estate
- 🚪 **Confirm closed and relocated businesses have been removed**

The first two catch the most by a wide margin. If you only do two things on this list, do those.

## ⏰ One Last Thing on Timing

Pull the final verified file **two or three days before launch**, not weeks. Local email data decays fast, businesses close, and people leave.

If a list has been sitting unsent for sixty days, re-verify it before it goes out. It is cheap and it is the difference between a 1.5% bounce and a 4% one.

## ✅ Before You Move On

- Filtering done before enrichment, with only dedupe and bucket assignment after
- Hygiene run on the raw export
- A verified sendable figure you believe, checked against your plan
- Suppression loaded across every sending domain
- One file per bucket, named consistently
- The QA checklist run, with the name sample and the bounce test done properly

---

<aside>
📅

### Want Someone to Do All of This for You?

Sourcing, hygiene, enrichment, verification, bucketing, suppression and pre-send QA, run properly every month.

Book a call with Harvey and the Legacy GTM team will build you a free campaign and show you how to get **15 to 30 qualified booked meetings a month** with local businesses.

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [6.8 Building It](6%208%20Building%20It%204aa61a134ea183f297f58111c52b869e.md)

The three ways to actually run everything in this section, including the two that do not involve paying anybody.

</aside>