# 6.6 Owner Identification and Enrichment

<aside>
🔎

**There is no single source for who owns a local business.**

This is the hardest part of local outbound and the part that decides how much of your scrape survives. It is a cross-referencing problem, not a lookup.

</aside>

## 📚 Where Owner Names Actually Come From

| Source | What it gives you | Reliability |
| --- | --- | --- |
| 🌐 **Business website** | About pages, team pages, founder stories, contact pages | High when present, and the most productive single source |
| 🏛️ **Secretary of State filings** | Registered agent, officers, incorporation records | High for legal ownership, but it lags operational reality |
| 📘 **Facebook business page** | Page owner, posts written in first person, signed review replies | Moderate, and useful where there is no website at all |
| 🏅 **Better Business Bureau** | Principal contact and business profile | Moderate, skewed toward businesses that sought accreditation |
| 📸 **Instagram** | Bio, tagged personal accounts, content signed by the owner | Moderate, strongest in consumer-facing trades |
| ⭐ **Review replies** | Owners sign replies to reviews far more often than people expect | Underrated, and independent of every other source here |

Every source has systematic gaps, which is why one source lands far below the 75% find rate and several together reach it.

## ⚖️ When Sources Disagree

They will, and the tiebreak is consistent:

> **Prefer recency and operational proximity over legal formality.**
> 

A name in a recent review reply beats a name on a registry filing, because it proves current involvement. A registry filing naming somebody who appears nowhere else is usually a lawyer or an accountant who set the company up years ago and has never been near it since.

Rank your sources before you run, so the resolution is a rule rather than a judgment call on every record.

## 🪜 The Waterfall: Name to Address

A resolved name is not a contact yet. This is the order that gets the most out of each record.

1. 📧 **Owner name and domain into an email finder.** Yields about **75%** of records an owner name and **42%** an owner direct email
2. 🔁 **A second finder as fallback.** Providers disagree on the same name and domain, so one pass finds meaningfully fewer addresses than two
3. 🌐 **The site itself for a published address.** Usually a generic inbox, and **you keep the owner name attached to it**
4. 📞 **Owner direct phone last.** About **20%**, the lowest find rate of the four and the highest value per record

**Combined contactable coverage lands around 60%.**

## 🎯 The Detail That Matters Most

Step three is the one people miss.

**A failed owner email does not end the record.** You fall back to the generic inbox and keep the name attached, and that record becomes bucket two, which performs close to owner-direct in several verticals.

The gap between 42% owner-direct and 60% combined coverage is exactly that bucket. Treat a failed owner-email lookup as a dead record and you throw away roughly a third of your reachable market. Section 6.4.

## 🚨 Where Cheap Tools Break

Several tools advertise enrichment and actually just crawl the website and hand you every string that looks like an email address.

Three failure modes, all of them expensive:

- 🎨 **You get the web designer.** Plus the photographer, a supplier, and sometimes an address left behind in a stock template
- ✅ **Bounces survive verification.** A real mailbox can still be the wrong mailbox, so a verifier passes it and the send fails anyway
- 👤 **No owner name.** So you write to a business rather than to a person, and bucket two is closed to you entirely

Scraping every address off a website is not enrichment. It is a different, cheaper activity wearing the same word.

## 🧠 Running It Without Overspending

Enrichment is the expensive line, so the discipline matters as much as the sources.

**Use what came back free first.** Category, review count, location count, website presence and opening hours are already on the record. Do not pay to infer something you were given.

**Look for a rule before you reach for AI.** If a value can be derived with a formula, derive it. A formula is free and deterministic. An inference costs money and can be wrong.

**Gather context once, use it twice.** Read the website once and have it answer both the qualification question and the personalization question in the same pass. One enrichment, two jobs.

**Run a hallucination check column.** Flag any row where the value is blank, says N/A, or contains an apology. Filter for the flag and spot-check those against the source. AI enrichment fails quietly, and a confident wrong owner name is the most damaging output in this whole section.

**Checkpoint the cost at ten rows and fifty rows.** Before any full run. Ten minutes of checking has saved a lot of people several hundred pounds.

## ✅ Verification and Freshness

- 🔬 **Verify anything you resolved yourself**, before it enters a campaign. A crawled address, a guessed pattern or a name from a filing all need a validation pass. If your data source returns verified addresses, do not pay to verify them again
- 🕳️ **Drop catch-all-only addresses** unless you have confirmed them another way. A catch-all domain accepts everything at the server and bounces it later, which is how a self-built list still bounces
- 📅 **Pull email addresses last, two or three days before launch.** Local data decays fast. A list built and sat on for two months is not the list you built
- 🔁 **Anything unsent for sixty days needs re-verifying** before it goes out

## ⚠️ A Wrong Name Is Worse Than No Name

"Hi Dave" to somebody called Mark is worse than no greeting at all. It proves you are mass-mailing and it kills the record permanently.

Two rules:

- 👀 **Sample twenty to thirty records by hand before every launch**, checking the resolved name against the live source. Record the error rate
- ⬇️ **Route low-confidence names into bucket three** rather than using them. Bucket three copy works without a name, so a demoted record is still a usable record

## 🏷️ Title Waterfalling

If your offer does not sell to the owner, search titles in priority order and take the first match. Practice manager before owner for a dental supply offer. Operations lead before founder for a multi-site group.

Reported lift on hard roles runs from roughly 50% to 75% against searching for a single title.

## ✅ Before You Move On

- Several sources cross-referenced, not one
- A stated tiebreak rule for when they disagree
- A waterfall that treats a failed owner email as a fallback rather than a failure
- A hallucination check column, and cost checkpoints before full runs
- Addresses verified, catch-alls dropped, and pulled fresh days before launch
- A manual name sample with a recorded error rate

---

<aside>
🔑

### Or Skip the Whole Resolution Layer

Six sources, a tiebreak rule, a two-provider waterfall, a hallucination check and a verification pass. It works, and it is the most expensive and most fragile thing you will build.

LocalPipe is the local business database this guide runs on:

- 👤 **75%** owner name find rate, resolved by cross-referencing rather than scraping
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- 📞 Owner direct email, general business email and owner phone returned separately, so the buckets are there from the start
- ✅ **Triple verified**, with **sub 1% bounce** on raw exports
- 💸 Pay on find, so records that come back empty cost you nothing

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

<aside>
📅

### Want Someone to Do All of This for You?

Book a call with Harvey and the Legacy GTM team will build you a free campaign and show you how to get **15 to 30 qualified booked meetings a month** with local businesses.

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [6.7 Hygiene, Coverage Math and Pre-Send QA](6%207%20Hygiene,%20Coverage%20Math%20and%20Pre-Send%20QA%209ea61a134ea182158ee501d1cfd9152c.md)

Filtering in the right order, and the checks that have each cost somebody a campaign.

</aside>