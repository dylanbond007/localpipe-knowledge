# 5.2 Build Your ICP in 30 Minutes

<aside>
⏱️

**Thirty minutes, and you do it from what you already know.**

Not market research. Not a persona workshop. You are looking at the customers you already have and writing down what the good ones have in common.

</aside>

## 1️⃣ Pull Your Best Customers (10 minutes)

List your best ten to twenty. If you have fewer than ten, list what you have.

"Best" means three things at once, and you need all three:

- 💰 **Highest value.** They spend the most, or they spend it repeatedly
- ⚡ **Fastest to close.** From first conversation to signed, they were easy
- 😌 **Lowest hassle.** They pay on time, they do not call at weekends, you are not dreading their name on the screen

A customer who is big and awful is not a best customer. Neither is one who is lovely and barely profitable. The ones you want more of are good on all three.

Now look for **three things they share**. Not twenty. Three.

Useful things to check:

- What category are they in?
- How big are they, in employees or vans or chairs or sites?
- How far away are they?
- How long have they been trading?
- How did they buy? Fast decision, one person, no committee?
- What did they buy first?

## 2️⃣ Pull Your Worst Five (5 minutes)

The ones who haggled, churned, complained, paid late, or took four months to say no.

Find **two things they share**. That is your **anti-ICP**, and it is worth as much as the first list.

Anti-ICP is not a soft preference. It is a filter you apply to the list before you spend money enriching it. Every record you knowingly exclude is money you do not spend and a conversation you do not have to escape from later.

Common local anti-ICP patterns:

- Too small to afford you, which usually shows up as one person with no website
- Too big, so there is a procurement process you cannot survive
- Price shoppers, visible in how they talk about competitors in their own reviews
- A category where your thing solves a problem they do not have and will not admit to

## 3️⃣ Write It as One Paragraph (10 minutes)

Not a slide. One paragraph, in plain words, that somebody else could read and then go and build the list.

> **The shape:** We work best with [category] businesses of [size] within [geography], trading more than [tenure], that [distinguishing thing]. They usually [how they buy]. We avoid [anti-ICP].
> 

A worked example:

> We work best with commercial cleaning contracts at dental practices and medical offices with 8 to 30 staff, within 45 minutes of the yard, trading more than three years, that have a website and answer their Google reviews. The practice manager usually decides and can sign without a committee. We avoid single-room clinics and anything with more than four sites, because procurement kills it.
> 

If you cannot write that paragraph, you are not ready to build a list. That is the point of the exercise.

## 🆕 If You Have No Customer History

Common, and not a blocker. You are building the same paragraph from different evidence.

- 🧠 **Start from what you can prove you do well.** Not who you would like to serve. Which jobs have gone well, which you have the equipment and the people for, which you can price confidently
- 🔍 **Look at who your competitors serve.** Their case studies, their review profile, the logos on their van photos. Somebody has already done the research
- 📞 **Have five real conversations.** Five owners in the category you think you want, asking about the problem rather than pitching. It takes an afternoon and it beats a month of guessing
- 🎯 **Pick narrower than feels comfortable.** With no history you have no proof, and a narrow claim is believable where a broad one is not. One category, one geography, one problem
- 🔁 **Plan to revise it.** Your first ICP is a hypothesis. After thirty conversations you will know things you cannot know now

## ⚠️ When the Cluster Is Not Filterable

This happens and it stops people.

You look at your best customers and what they share is something you cannot put into a list filter. They are all "really organised." They all "care about their staff." They all "had a bad experience with the last supplier."

Three ways through it:

- 🔗 **Find the visible proxy.** Organised businesses tend to have booking systems, answered reviews and a current website. Owners who care about staff write different careers pages. There is almost always something observable that correlates
- 🚦 **Move it from filter to score.** If you cannot filter on it, use it to rank. Build the list on what you can filter, then push the ones that show the proxy to the top
- ✍️ **Move it into the copy.** Something you cannot target on, you can still speak to. If your best customers all got burned by a previous supplier, that becomes the opening line rather than a list filter

## ✅ What You Should Have Now

- A list of your best customers and the three things they share
- Two things your worst customers share
- One paragraph anybody could build a list from
- A note of anything you could not filter on, and whether it becomes a score or a line of copy

Thirty minutes. This is the cheapest, highest-leverage half hour in the entire build.

---

<aside>
➡️

**Next:** [5.3 Score and Tier Your Market](5%203%20Score%20and%20Tier%20Your%20Market%20c7661a134ea182a2bceb81a59dc2bb62.md)

Turning the paragraph into a ranking, so the good records get the expensive treatment.

</aside>