# 5.1 The Four Layers of a Local ICP

<aside>
🎯

**Who you email is the highest-leverage decision in the whole system.**

Same offer, different ICP, and you have a different business. Get this wrong and every hour you spend on copy is spent making a better pitch to the wrong person.

</aside>

## 🔍 ICP Is Not Buyer Persona

Two different things, and mixing them up produces campaigns that talk to nobody.

<aside>
🏢

**ICP — the company**

The kind of business worth selling to. Category, size, geography, how long they have been trading, whether they have a website.

Answers: *which businesses do we go after?*

</aside>

<aside>
👤

**Buyer persona — the human**

The person inside it who reads your email and can say yes.

Answers: *who do we write to, and what do they care about?*

</aside>

**One persona per campaign.** On local that is usually easy, because there is only one person: the owner. At tier two it splits, because a location manager and a head-office operations lead are different people with different problems. Section 0.3.

## 🧱 The Four Layers

Every good ICP has four layers stacked, and each one narrows the layer above it.

### 1️⃣ Firmographics: the company basics

The objective facts, measurable from outside. Look at your best ten to twenty customers, the highest value, fastest closing, least hassle ones, and find what they cluster around.

| Criteria | Local example |
| --- | --- |
| Category | Plumbing, dental practices, commercial cleaning, auto repair |
| Size | 5 to 25 employees, or one to three vans |
| Geography | Inside a 45 minute drive, or a named set of ZIP codes |
| Tenure | Trading more than three years. Past the survival phase, established enough to have budget |
| Locations | Single site, or a small multi-site group |
| Web presence | Has a website at all, which is itself a quality signal |
| Review profile | Rating and review count, as a proxy for size and how seriously they take their reputation |

Almost all of this comes free on a Maps record. It is the cheapest filtering you will ever do, and it happens before you spend a penny on enrichment. Section 6.7.

### 2️⃣ Technographics: the tools they run

What software a business already uses reveals budget, sophistication and intent.

This layer is thin on local, and it is worth knowing that rather than hunting for data that is not there. A twelve-person landscaping company does not have a tech stack anyone is publishing.

What does exist, and is worth looking for:

- 📅 **A booking or scheduling system** on the website. Says they care about being easy to deal with
- 🔧 **A field-service platform.** ServiceTitan, Jobber, Housecall Pro. Visible in job listings or page source, and it signals real operational maturity
- 💳 **A payments or POS provider**, for retail and hospitality
- 🌐 **Website platform and age.** A site built on a modern platform says one thing. A site that has clearly not been touched since 2014 says something more useful
- 📣 **Whether ads are currently running.** They have budget and they are already buying growth

### 3️⃣ Buying signals: what is happening right now

The behavioural layer, and the one most people under-build. A trigger is a specific event that makes a prospect more buyable today than they were yesterday.

This is where a local ICP diverges hardest from a corporate one. The standard trigger set is built on funding rounds, headcount velocity, new-in-role moves and tech-stack changes, and almost none of that exists for a business with eleven employees and no filings.

**The whole of 5.4 is the replacement.** It is the most important page in this section.

### 4️⃣ Psychographics: what they value

The softest layer. Hardest to pull from a database, most powerful when you get it right.

On a local business, this is unusually readable, because owner-operated businesses wear their values in public:

- 🗣️ **How they answer reviews.** Defensive, gracious, or not at all. Tells you more about the owner than any database field
- 👨‍👩‍👧 **Family business framing** on the About page. Second generation, since 1987, the founder's name on the van
- 🏆 **What they brag about.** Speed, price, craftsmanship, certifications, being local. Whatever is on the homepage is what they think wins them work
- 🧑‍🔧 **Hiring language.** A careers page that talks about training and progression is a different business from one that just lists roles
- 📸 **Who appears in the photos.** The owner on a job, or a stock image

You can have AI read and summarise this across a whole list at scale. Section 6.6.

## 🏗️ Building It Top Down

Each layer narrows the one above. Firmographics gives you a few thousand businesses, technographics and signals cut it to a few hundred worth prioritising, and psychographics tells you what to actually say to them.

Do not try to build all four at once. Layers one and three do the filtering. Layers two and four do the writing.

## ⚠️ The Mistake That Costs Most

**Reading an empty database result as an empty market.**

If a major B2B database returns 200 plumbers in your metro, that means the database holds 200. There are probably several thousand. Every firmographic filter you set is being applied to a sample that was never representative in the first place.

Build the ICP against what actually exists, then go and source it properly. Section 06.

## ✅ Before You Move On

- Your best ten to twenty customers listed, with what they have in common
- Firmographic filters you can actually apply to a Maps record
- An honest note on which technographic signals exist in your category and which do not
- Something written down about what your best customers value, in their words rather than yours

---

<aside>
➡️

**Next:** [5.2 Build Your ICP in 30 Minutes](5%202%20Build%20Your%20ICP%20in%2030%20Minutes%2062961a134ea182bb88f0817a1ebc6083.md)

The exercise, including the version for when you have no customer history yet.

</aside>