# 9.7 Annotated Examples and Failure Modes

<aside>
📄

**Four worked emails, one deliberately bad one, and what separates them.**

Use these as structure, not as templates. Copy them word for word and they stop working, because the thing that makes them land is that they are specific.

</aside>

## 1️⃣ Bucket One, Signal-Based

**Commercial cleaning to a dental practice. The signal is a job posting.**

> **Subject:** quick question
> 

> Hi Dan,
> 

> Saw you're hiring a second front desk person. Usually means the practice is growing faster than the back office, and cleaning is the first thing that slips.
> 

> We look after two practices on Whiteladies Road, both on evening schedules so nobody's waiting around.
> 

> Worth ten minutes to see if we'd fit?
> 

> Harvey
> 

**Why it works:**

- 🎯 **Opener answers why me.** A job posting is public, recent, and connected to the pitch
- 🔗 **The link is drawn for them.** Hiring at the front desk to cleaning slipping. One sentence, and it is plausible
- 🏘️ **Proof is checkable and local.** A named road, two practices. They can verify it in thirty seconds
- 🪶 **Small ask.** Ten minutes, and "see if we'd fit" gives them permission to say no
- 📏 **62 words**

## 2️⃣ Bucket Two, Forward Prompt

**HVAC maintenance to a small manufacturer. Generic inbox, owner name resolved.**

> **Subject:** Mill Road unit
> 

> Hi,
> 

> Hoping to reach Tom, or whoever handles the building.
> 

> We service the two units either side of yours on Mill Road. Both moved to a quarterly schedule after a breakdown in the middle of a heatwave, which is the expensive way to learn.
> 

> If Tom's the right person, could you pass this on? If not, who should I be asking for?
> 

> Harvey
> 

**Why it works:**

- 👤 **Names the owner without pretending to know him.** Third person, with an out built in
- 🏘️ **Proximity proof doing real work.** Two units either side is close to unarguable
- 😬 **The problem is a story, not a claim.** A breakdown in a heatwave is vivid and true to the trade
- 📬 **Gives the reader a job they can do.** Forwarding is easier than replying, and asking who else is a second route
- 📏 **74 words**

## 3️⃣ Bucket Three, Evergreen, No Name

**Linen supply to restaurants. No owner name resolved.**

> **Subject:** Tuesday
> 

> Hi,
> 

> We deliver linen to four restaurants in the Old Town, all on Tuesday and Friday runs.
> 

> Adding one more on the same route means we can do it cheaper than you're likely paying now, and you get the same driver each week.
> 

> Is that something worth a look?
> 

> Harvey
> 

**Why it works:**

- 🚫 **No fake personalization.** No "hi there", no pretending to know anything about them
- 🗺️ **Location carries the whole opener.** Four restaurants, a named area, a specific schedule
- 💰 **The offer is genuinely better because of proximity.** Route density is a real reason, not a marketing claim
- 🪶 **Lowest friction ask on the list.** "Worth a look" costs nothing to answer
- 📏 **58 words**

## 4️⃣ Bucket Four, Personal Provider

**Same linen supplier, but the address is a personal one.**

> **Subject:** linen
> 

> Hi Sam,
> 

> We run linen deliveries to four places in the Old Town, Tuesdays and Fridays.
> 

> Is that something you sort yourself, or does someone else handle it?
> 

> Harvey
> 

**Why it works:**

- 📱 **Reads like a message, not an email.** No preamble, no sign-off block
- ❓ **The ask is a question, not a meeting.** Far easier to answer, and any answer starts a conversation
- 🤝 **It does not pitch.** At this proximity, pitching feels like an intrusion. Asking does not
- 📏 **38 words**

## 💀 The Deliberately Bad One

Everything above, done wrong.

> **Subject:** Boost Your Restaurant's Efficiency by 40%! 🚀
> 

> Hi there,
> 

> I hope this email finds you well!
> 

> I came across your business and was really impressed by what you're doing in the restaurant space. With 247 five-star reviews and 12 years in business, you've clearly built something special.
> 

> At LinenCo, we're a leading provider of innovative linen solutions that leverage cutting-edge logistics to deliver seamless, best-in-class service to hospitality businesses nationwide. Our clients typically see a 40% improvement in operational efficiency.
> 

> Would you be open to a 30-minute discovery call next week to explore how we can help you unlock your full potential? I'd love to learn more about your business!
> 

> Best regards,
> 

> Harvey Le
> 

> Senior Account Executive | LinenCo
> 

> [logo] [phone] [linkedin] [calendar link]
> 

**The diagnosis:**

| Problem | What it does |
| --- | --- |
| **Subject promises a number** | Reads as marketing before it is opened. The emoji finishes the job |
| **"Hi there"** | Announces that you do not know who they are |
| **"I hope this email finds you well"** | Nobody has ever written this to somebody they know |
| **247 reviews, 12 years** | Public, accurate, and creepy. Proves surveillance rather than relevance |
| **Mechanism-first paragraph** | Innovative, leverage, cutting-edge, seamless, best-in-class. Five hype words, no meaning |
| **"40% improvement in operational efficiency"** | Unverifiable, and it is not a number they measure |
| **30-minute discovery call** | Large ask, framed in your language rather than theirs |
| **Signature block** | Job title, logo, links. It is a company writing, not a person |
| **168 words** | Roughly three times too long for a phone screen |

Most of this email is not badly written. It is competently written for the wrong reader.

## ⚠️ The Five Failure Modes

Everything that goes wrong falls into one of these.

- 🕵️ **Surveillance personalization.** Reciting public facts to prove effort. Section 9.4
- 🔩 **Mechanism first.** Explaining how before they want the what. Section 9.1
- 👔 **Corporate register.** Written for an office, read on a job site
- 💥 **A merge field that blew up.** "Hi {{FirstName}}," or an empty space where a place name should be. Section 10.2
- 🪣 **Copy in the wrong bucket.** A first name in a bucket three email, or a forward prompt sent to the owner directly

## ✅ How to Use These

- Write your own version of each of the four, for your business and your market
- Run each through the could-be-anyone test from 9.4
- Read each one aloud
- Keep them in one place so the whole set stays consistent when you revise the offer

---

<aside>
📅

### Want Someone to Do All of This for You?

Four buckets, three emails each, tested and rewritten against real reply data every month.

Book a call with Harvey and the Legacy GTM team will build you a free campaign and show you how to get **15 to 30 qualified booked meetings a month** with local businesses.

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [10 · Launch, Operate, Diagnose](../10%20%C2%B7%20Launch,%20Operate,%20Diagnose%20e2061a134ea183848b2801116fbba8b0.md)

Going live without burning what you built.

</aside>