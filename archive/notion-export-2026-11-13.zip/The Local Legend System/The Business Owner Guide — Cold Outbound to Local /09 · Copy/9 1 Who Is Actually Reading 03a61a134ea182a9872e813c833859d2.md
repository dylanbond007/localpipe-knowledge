# 9.1 Who Is Actually Reading

<aside>
👤

**Picture the person.**

They own the business. They do some of the work themselves. They read their own inbox, on a phone, standing in a van or between jobs. Nobody screens their email. They have been pitched by three marketing agencies this month and one of them took their money.

Write for that person and most copy advice sorts itself out.

</aside>

## 📱 What That Changes Immediately

- ⏱️ **You have about four seconds**, not thirty. They are deciding whether to delete on the subject line and the first sentence
- 📵 **It is a phone screen.** Short paragraphs, no formatting, nothing that needs pinching to read
- 🧰 **No corporate vocabulary.** Nobody has ever said "solution", "leverage" or "reach out" out loud on a job site
- 🕐 **They are busy in a physical way.** Not in meetings. Actually holding something
- 🛡️ **They are sceptical for good reason.** Somebody in your category has already disappointed them

## 🎚️ Awareness Level

This is the single biggest decision in your copy, and it comes before any framework.

| Where they are | What the email has to do |
| --- | --- |
| 😐 **Unaware.** They do not think they have this problem | Show them the problem first. The audit exists for this. Do not sell anything yet |
| 🤔 **Problem aware.** They know it is a problem, not that it is solvable | Establish that a solution exists. This is where most **B→L** readers sit |
| 🔍 **Solution aware.** They know solutions exist and are choosing | Differentiate. Why you rather than the three others who emailed them. Most **L→L** sits here |
| 🎯 **Product aware.** They know who you are | Give them a reason to act now. Rare in cold outbound |

Writing one level too advanced is the most common copy failure in local. Pitching your mechanism to somebody who does not yet believe they have the problem reads as noise.

## 🗣️ The Outcome Rule

> **Lead with the outcome. Never with the mechanism.**
> 
- ❌ "We use AI-powered signal monitoring across Maps and review data to identify high-intent local prospects"
- ✅ "We fill your quiet weeks with commercial contracts inside your service area"

The mechanism is interesting to you. The outcome is interesting to them. The mechanism becomes relevant on the call, once they want the outcome badly enough to ask how.

**Where the rule inverts:** in a red ocean where everybody is claiming the same outcome, the mechanism becomes the differentiator, because the outcome no longer separates you. Even then, outcome first, mechanism second. Never mechanism alone.

## 🎭 Register

How it should sound, in four rules.

**Write like a person who noticed something**, not a company running a campaign. The closer it reads to an email a neighbour would send, the better it performs.

**Short sentences.** If you would not say it out loud, cut it. Read every draft aloud once, which catches more than any checklist.

**No enthusiasm they have not earned.** Exclamation marks, "excited to", "I'd love to". It reads as someone who wants something.

**Say the awkward thing plainly.** If you are cold emailing, they know. A line like "you do not know me, so here is why I am writing" outperforms any clever workaround, because it is what a real person would say.

## 🌐 If You Sell to Local Businesses From Anywhere

Two adjustments, both in your reader's head rather than your writing.

**Lower awareness.** Your buyer often does not know the category exists, so part of email one has to establish that the problem is solvable at all. That costs you words in an email that is already short, which is why the audit magnet does so much work in this motion.

**Different proof.** You cannot say you are down the road. You can say you look after somebody who is, if you built your list as rings around existing customers. Section 6.3.

## ✅ Before You Move On

- A clear picture of the specific person reading this
- Their awareness level decided, and the copy written for that level
- Outcome first in every version, mechanism held back
- Every draft read aloud once before it ships

---

<aside>
➡️

**Next:** [9.2 The Dream Email, Then Dial Back](9%202%20The%20Dream%20Email,%20Then%20Dial%20Back%207ee61a134ea182839dfe81ac5126660d.md)

Write the ceiling first, then cut to what you can afford to find out.

</aside>