# 9.2 The Dream Email, Then Dial Back

<aside>
✨

**Write the best email you could possibly send to one specific person.**

Everything you wish you knew about them, all of it, with no thought for what is findable at scale. That is your ceiling. Then cut back to what you can actually afford to find out.

Doing it in that order is what makes the whole thing work.

</aside>

## 🎯 Why This Order

Most people write the email they can build with the data they happen to have. That caps the copy at whatever was easy to look up.

Writing the dream version first does something different. It tells you **exactly what to go and enrich for**, and that list is usually much shorter than you expect. Three or four fields, not thirty.

So the sequence is:

1. ✍️ **Write the ceiling.** Perfect information, one real person, no constraints
2. ✂️ **Mark what you cannot get** at list scale, honestly
3. 🔍 **Look at what is left.** Usually two or three things carry almost all the weight
4. 💰 **Decide what those cost** to find. Section 6.6
5. 📝 **Rewrite at that level**, and keep the ceiling version as the target

## 🧪 Try It Now

Pick one real business from your list. Open their website, their reviews, their social. Spend ten minutes learning about them properly.

Now write the email you would send **that person**. Name the thing you noticed. Reference the specific problem. Say why you, why them, why today.

That email will be good. It will also take ten minutes per prospect, which does not scale.

**Now go through it and underline every fact you used.** For each one ask: could I get this for two thousand businesses, and what would it cost?

Some will be free on the record. Some cost pennies through enrichment. Some are genuinely only available by hand.

**What survives is your real copy.** And what you underlined that was free is where most of your performance comes from.

## 📊 The Six Reasons Anybody Replies

Run every draft through this. An email needs at least two, and the strongest ones have three.

| Reason | What it looks like |
| --- | --- |
| 🎯 **It is obviously about them** | Specific enough that it could not have gone to anybody else |
| 🔥 **The problem is live right now** | A trigger, a season, something that just happened |
| 💰 **The outcome is worth real money** | Named, sized, and connected to their business |
| 🤝 **There is a reason to believe it** | Proof they can check. A local name beats a statistic |
| 🪶 **The ask is small** | Fifteen minutes, not a commitment |
| 😌 **It reads like a person** | Not a campaign. Not a template with holes filled in |

If a draft scores one out of six, no amount of rewriting the sentences will save it. Go back to the offer or the list.

## 🪜 Copy Is the Last Lever, Not the First

Worth saying plainly before the next five pages.

If your reply rate is bad, copy is almost never the cause. The order of likelihood is: deliverability, then the list, then the offer, then the copy. On local it is the list about three times out of four.

Copy is what turns a good list and a good offer into replies. It cannot turn a bad one into anything.

So: write it properly, then stop rewriting it and go and look at the four pillars in 10.4.

## ✅ Before You Move On

- One dream email written to a real, specific business
- Every fact in it underlined and costed
- Two or three findable inputs identified as the ones that carry the weight
- A draft that scores at least two on the six reasons

---

<aside>
➡️

**Next:** [9.3 The Four Questions and the Email-1 Skeleton](9%203%20The%20Four%20Questions%20and%20the%20Email-1%20Skeleton%202a861a134ea18230ad1b817dde614051.md)

Line by line, with what each line is doing.

</aside>