# 9.6 The Sequence, Subject Lines and the Cut List

<aside>
📬

**Three emails, two to three days apart. That is the cap, not the starting point.**

Email one does about 80% of the work. If three are not landing, the problem is not that you need a fourth.

</aside>

## 📊 The Three

| Email | Job | What it says |
| --- | --- | --- |
| **1** | Earn the reply | The full argument. Why them, why care, why believe, what now |
| **2** | A new angle, not a repeat | The same offer approached from a different problem, or different proof |
| **3** | Name the silence, or change entirely | "Guessing this is not a priority right now, happy to leave it" or a completely different angle |

**Email one carries the campaign**, which is why you test three or four versions of it and leave the other two alone.

## 🚫 There Is No Email Four

If three emails to the right person with the right offer produce nothing, a fourth does not fix it. Something upstream is wrong: the list, the offer, the targeting, or the inbox placement.

Adding follow-ups to a broken campaign does two things. It generates complaints, and it burns a finite market you cannot re-contact for six months.

**The exception:** a genuine new reason to write. A new signal fired, the season changed, something happened in their business. That is not follow-up four, it is a new campaign, and it goes in the calendar for later rather than on the end of this sequence.

## ⏰ Spacing and Timing

- 📅 **Two to three days between emails.** Faster feels aggressive, slower loses the thread
- 🌅 **Early morning or early evening.** Owner-operators read email before jobs start and after they finish, not at 2pm
- 🗓️ **Tuesday to Thursday** for the first send. Monday is chaos, Friday is gone
- 🕐 **Watch the time zone** if you send across regions, which matters on **B→L** far more than **L→L**

## 🧵 Threading

Replying in the same thread for emails two and three usually performs better, because it carries context and looks like a person following up rather than a new campaign starting.

Worth testing both on your list. It is one of the few copy-level tests cheap enough to justify on a small market, because it costs no extra contacts.

## 📏 Length, Format, Ask

- 📐 **Forty to eighty words** on email one. Shorter on bucket four. Can be flexible if you have the right content
- 📱 **Plain text.** No images, no logo, no HTML signature, no tracking pixel
- 🎯 **One ask.** Two asks is zero asks
- 📵 **No attachments**, ever, on a cold email
- 📖 **Short paragraphs.** One to two lines each, because it is being read on a phone

## 🏷️ Subject Lines

The subject is not a headline. It is not selling anything. Its only job is to earn the open without making a promise the email cannot keep.

**What works:**

- 🔤 **One to three words.** "quick question", "your Mill Road job", "Tuesdays"
- 📥 **Internal-note feel.** It should look like something a colleague sent
- 🔡 **Lowercase is fine** and often better. Title case reads like marketing

**What does not:**

- ❌ Anything with a number or a percentage in it
- ❌ Questions that promise value. "Want more customers?"
- ❌ Personalization tokens in the subject. "{{First Name}}, quick question" is a tell
- ❌ RE: or FW: on a first email. It is a trick, and they know it

## ✂️ The Cut List

Strip these from every draft before it ships.

**Hype words.** Revolutionary, game-changing, cutting-edge, unlock, supercharge, seamless, robust.

**AI tells.** "I hope this email finds you well", "I wanted to reach out", "in today's fast-paced world", "delve", "leverage", "solutions", "streamline".

**Jargon nobody says out loud.** Synergy, bandwidth, circle back, touch base, value-add, best-in-class.

**Hedges.** "Just", "quick", "sorry to bother", "I know you're busy". They apologise for existing and weaken the ask.

**Your own admiration.** "I love what you're doing" is a compliment from a stranger, which is worth nothing and costs credibility.

## 🧪 The Read-Aloud Test

The last thing before it ships.

Read the email out loud. Every sentence you stumble on, or would never actually say to somebody's face, gets cut or rewritten.

This single habit catches more than any checklist on this page.

## ✅ Before You Move On

- Three emails, no fourth
- Email one tested in three or four versions, two and three left alone
- Forty to eighty words, plain text, one ask
- Subject lines of one to three words with no promise in them
- The cut list applied
- Every email read aloud once

---

<aside>
📅

### Want Someone to Do All of This for You?

Book a call with Harvey and the Legacy GTM team will build you a free campaign and show you how to get **15 to 30 qualified booked meetings a month** with local businesses.

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [9.7 Annotated Examples and Failure Modes](9%207%20Annotated%20Examples%20and%20Failure%20Modes%200d661a134ea183ae98328168e25dd58c.md)

Worked emails across buckets and verticals, plus a deliberately bad one.

</aside>