# 9.5 Copy Per Contact Bucket

<aside>
🪣

**Same offer. Four sets of copy.**

The buckets from 6.4 are not a data exercise. They are four different reading situations, and copy written for one of them underperforms in the other three.

</aside>

## 📋 The Routing Table

|  | 1. Owner direct | 2. Generic, owner known | 3. Generic, no name | 4. Personal provider |
| --- | --- | --- | --- | --- |
| **Opening line** | First name, addressed directly | Owner named in third person, or a forward prompt | Business name and location, no personal reference | First name, and write it like a text message |
| **Personalization** | Name, location, category, signal | Owner name, location, category | Location, category, visible signals only | Name, location, category. Most informal of the four |
| **Ask** | Direct. Most friction tolerated | Direct ask plus a routing question | Direct ask, least friction | Smallest ask of all. A question, not a meeting request |
| **Sequence length** | Three emails | Three emails | Two, the ceiling is lower | Two or three, ramped slowly |
| **Expected reply quality** | High | Close to bucket one in several verticals | Moderate, with more routing replies | Highest and most direct |

## 1️⃣ Owner Direct

The straightforward one. You know who they are and you are writing to them at their own address.

- Use the first name in the greeting
- Reference the signal or the location in the opener
- Full sequence, standard length
- Tolerates the most specificity, because everything you say is about them

## 2️⃣ Generic Inbox, Owner Known

The underrated one, and the only bucket that needs a genuinely different structure.

You are writing to **info@** but you know **Dan** runs the place. Two ways to use that, and both work:

**Third person.** *"Hoping to reach Dan. We look after two other practices on the same road and I noticed something on your booking page worth ten minutes of his time."*

**Forward prompt.** *"If Dan handles this, could you pass it on? If he does not, who should I be speaking to?"*

The forward prompt is the more interesting one, because it gives the reader a job they can actually do. An office manager who cannot buy anything can absolutely forward an email, and that is a much lower bar than replying.

**Write it so forwarding is effortless.** Short, no attachments, nothing that needs explaining. Assume it gets passed on with no message attached.

## 3️⃣ Generic Inbox, No Name

The biggest bucket by volume and the lowest ceiling. Write accordingly.

- Open with the business name and the location
- No personal reference at all. Do not write "hi there" as a substitute for a name, it draws attention to the gap
- Least friction in the ask. This is the bucket where "worth a look?" beats "do you have fifteen minutes Thursday?"
- Shorter sequence. Two emails
- Expect more routing replies than yes or no replies, and treat a routing reply as a win. Section 11.2

## 4️⃣ Personal Provider

The most direct line you have, and the one people write most badly, because they write it like business email.

They are reading this on their phone, on a personal account, probably in the evening. Write like a person messaging a person.

- Shortest of the four. Thirty to fifty words
- First name, no formality, no signature block
- The ask should be a **question**, not a meeting request. "Is that something you deal with yourself?" outperforms "do you have fifteen minutes"
- Ramp slowly and keep it on its own infrastructure. Section 4.6

## ⏱️ Sequence the Buckets, Do Not Blast Them

If a business appears in two buckets, those two emails should not arrive the same day.

- 📅 Work bucket one first, then bucket two a week later to the records that did not reply
- 🔇 Suppress across buckets on reply. Somebody who answered at info@ should not get the owner-direct sequence too
- 👀 Watch complaints when you first run two buckets on the same records, rather than assuming it is fine

## 🧪 One Campaign, Four Versions, One Test

Keep the offer, the angle and the ask identical across the four. Only the framing changes.

That way, differences in performance tell you about the **bucket**, which is genuinely useful information, rather than about four different messages, which tells you nothing.

## ✅ Before You Move On

- Four versions written, not one with the greeting swapped
- A forward prompt written for bucket two
- Bucket three copy that works with no name at all
- Bucket four written like a message, not an email
- Buckets sequenced rather than sent together

---

<aside>
➡️

**Next:** [9.6 The Sequence, Subject Lines and the Cut List](9%206%20The%20Sequence,%20Subject%20Lines%20and%20the%20Cut%20List%20e8461a134ea18337b54c8173f8803d60.md)

Three emails, a hard cap, and what to strip from every draft.

</aside>