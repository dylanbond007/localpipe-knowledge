# 11.2 The Seven Reply Types

<aside>
🗂️

**Every reply is one of seven kinds, and each has one right move.**

Classify first, then respond. Reacting to the emotion of a reply rather than its type is how good leads get mishandled and bad ones get chased.

</aside>

## 1️⃣ Interested

*"Sounds good, tell me more."* / *"What does it cost?"* / *"How does it work?"*

**The move:** call within the hour. Reply by email at the same time with two concrete times or a link.

**Never ask about availability.** "When are you free?" hands them work and invites a delay. "Thursday 10am or Friday 2pm, or here is my calendar" gives them a decision instead of a task.

## 2️⃣ Objection or Question

*"We already have someone."* / *"How is this different from X?"* / *"Not sure we're big enough."*

**The move:** answer it in one line, then ask for the meeting anyway. An objection is engagement, not rejection. They read it and thought about it.

Common local ones and the reframe:

- 🤝 **"We have a guy"** → "Makes sense. Most of the people we work with did too. Worth ten minutes to have a comparison?"
- 💸 **"Too expensive"** → they have not seen a price. This is a value objection, so restate the outcome in money
- 📄 **"Send me info"** → the softest no in business. Offer the fifteen minutes instead, and send nothing
- ⏰ **"Too busy right now"** → agree, and ask when to come back. Then actually come back

## 3️⃣ Referral or Wrong Person

*"Not me, talk to Dave."* / *"Try the practice manager."*

**Gold, and routinely misfiled as a negative.**

On local this is worth more than it is elsewhere. Local trades sit in dense referral networks with no corporate equivalent, and a warm handoff inside a business, or to another business entirely, converts far better than anything cold.

**The move:** thank them, ask for an introduction rather than just a name, and treat the new contact as warm. Log both.

## 4️⃣ Clean No

*"Not interested."*

**The move:** one short, gracious line. No pitch, no "just in case", no attempt to rescue it.

Then log the reason if they gave one. Fifty of these tells you more about your market than any research.

And leave the door open without saying so. People change jobs, situations change, and a gracious no today is a warm contact in eighteen months.

## 5️⃣ Not Now

*"Revisit in the spring."* / *"Ask me after the summer."*

**The move:** agree a specific date, put it in the calendar, and actually do it.

This is the most commonly wasted reply type. Somebody told you exactly when to come back and most people never return. When you do, open with the fact that they asked you to.

On local this pairs naturally with seasonality. A roofer saying "not now" in December is saying "ask me in March", whether or not they used those words.

## 6️⃣ Unsubscribe or Angry

*"Take me off this list."* / anything hostile.

**The move:** remove immediately, everywhere, across every domain and every campaign. Confirm in one line if they asked a question, otherwise say nothing at all.

Do not defend yourself. Do not explain how you found them. Both make it worse and neither changes the outcome.

**Then check why.** A cluster of these means you contacted a market too recently, or your suppression is not loaded properly. Section 6.7.

## 7️⃣ Auto-Reply

Out of office, ticket confirmations, delivery notices.

**The move:** mostly ignore, but harvest them.

- 📅 An out of office with a return date is a scheduling instruction
- 👤 An out of office naming a colleague is a free referral
- 🎫 A ticketing auto-reply means you hit a role inbox at a business bigger than you thought. Re-check the tier

## 🧾 Log the Type on Every Reply

Not the text. The type.

After a hundred replies you can see whether your problem is that nobody is interested, or that everybody is interested and nobody is booking. Those are completely different problems with completely different fixes, and without classification they look identical on a dashboard.

| What the mix tells you | Where to look |
| --- | --- |
| Mostly clean no | The offer. Section 7.2 |
| Mostly wrong person | Targeting or bucket assignment. Sections 5.1 and 6.4 |
| Mostly not now | Timing or seasonality. There may be a better month |
| Plenty interested, few booked | Response speed. Section 11.1 |
| Rising unsubscribes | Suppression, or you have worked this market too recently |

## ✅ Before You Move On

- All seven types recognised, with a written response for each
- Referrals treated as wins, not losses
- Never asking about availability
- Not-now replies diarised with a real date
- Reply type logged on every single one

---

<aside>
➡️

**Next:** [11.3 Getting Them to Show](11%203%20Getting%20Them%20to%20Show%20e8d61a134ea1839384c0819ceb238794.md)

The booking is not the win.

</aside>