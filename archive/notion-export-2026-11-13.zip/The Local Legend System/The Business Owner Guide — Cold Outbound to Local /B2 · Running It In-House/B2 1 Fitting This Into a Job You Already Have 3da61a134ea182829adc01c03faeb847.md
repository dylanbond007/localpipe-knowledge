# B2.1 Fitting This Into a Job You Already Have

<aside>
⏰

**Fifteen minutes a day, an hour a week, half a day a month.**

That is the real running cost once it is live. The setup is heavier, and the replies are the part nobody budgets for.

</aside>

## 📅 The Actual Time Commitment

| When | How long | What you are doing |
| --- | --- | --- |
| **Setup** | Most of a working week, spread over 15 days | Infrastructure, list, offer, copy, QA |
| **Daily** | 15 minutes | Bounce, reply rate, and answering replies |
| **Weekly** | 1 hour | Placement test, batch rotation, lagging numbers |
| **Monthly** | Half a day | Review, scale or kill decisions, next month's list |

**The replies are extra**, and they are the part that actually varies. Seventeen positive replies a month, each needing a call inside the hour, is not fifteen minutes a day. It is closer to three or four hours a month of genuinely interruptive time.

## 🎯 What the Fifteen Minutes Is For

Not admin. Two numbers and one action.

- 💥 **Bounce rate** against the 2% bar
- 📬 **Reply rate** against your own baseline
- 📞 **Working whatever came in**

That is it. Everything else waits for the weekly slot. The daily check exists to catch a problem in its first day rather than its second week, not to give you something to fiddle with.

## 🚫 What Happens When You Skip a Week

Not dramatic, which is why it happens.

- 📉 Bounce drifts up and nobody notices until it is at 4%
- ❄️ Replies sit for three days and go cold. Section 11.1
- 🔥 A domain starts slipping and keeps sending while it does
- 🗑️ The list ages, and you send to data that was fresh a month ago

**Recovery costs more than maintenance would have.** A fortnight of neglect is usually a month of rebuilding, and on a finite market some of what you burned is not coming back for six months.

## 📦 Batch It

The single best adaptation for somebody with a day job.

Rather than running a continuous drip that demands attention every day, launch in **weekly batches**. Load Monday, run through the week, review Friday.

- 🗓️ You know when the replies will arrive, so you can plan around them
- 📊 A bad week is visible instead of averaged away
- 🧠 It matches how a busy person actually works, in blocks rather than continuously

## 🤖 What Automates and What Never Will

<aside>
✅

**Automates cleanly**

Sourcing and enrichment.

Sending and sequencing.

Warm-up and rotation.

Reminders and confirmations.

Reporting.

</aside>

<aside>
❌

**Never will**

The call after a reply.

Deciding what the numbers mean.

The offer.

Judgment about which prospects are worth more effort.

</aside>

The thing that cannot be automated is also the thing that decides whether any of it produces revenue. Plan your time around the reply, not around the build.

## ⚠️ The Failure Mode

Setting it up brilliantly, then not looking at it for a month.

It is extremely common, and it is not laziness. The setup is interesting and the maintenance is boring, so attention drifts the moment the novelty goes.

Two defences:

- 📌 **Put the fifteen minutes in the calendar at a fixed time**, attached to something you already do
- 🔔 **Make replies interrupt you.** Push notification to your phone, not an email you check later

If the daily check is not in a calendar, it will not happen in week six.

## ✅ Before You Move On

- Fifteen minutes booked at a fixed time each day
- Replies arriving as a phone notification
- Weekly batches rather than a continuous drip
- An honest estimate of reply-handling time on top of the maintenance

---

<aside>
➡️

**Next:** [B2.2 Your First Setter or SDR](B2%202%20Your%20First%20Setter%20or%20SDR%20a9f61a134ea1837d8cbd0194c74b6e6e.md)

When to hire, what to pay, and what to test for.

</aside>