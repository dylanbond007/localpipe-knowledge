# B2.4 When to Stop Doing This Yourself

<aside>
🚪

**This page is a diagnosis, not a pitch.**

Running this in-house is the right answer for plenty of businesses, permanently. These are the markers that say it has outgrown you, and the counter-case for staying put.

</aside>

## 🚩 The Five Markers

Any two of these together and it is worth a serious look. Three and the decision has already been made for you.

### 1️⃣ You are consistently missing the reply window, and hiring has not fixed it

You tried. You set the alerts, you named the person, maybe you brought somebody in. The replies still sit.

At that point it is structural rather than a discipline problem, and more effort applied to the same structure produces the same result. Section 11.4.

### 2️⃣ The market needs more volume than your infrastructure knowledge supports

You are at the edge of what you can run. Adding a second estate, a rotation schedule and a free-provider lane is a real technical undertaking, and doing it badly costs more than not doing it.

If the growth you need is on the other side of infrastructure you do not want to learn, that is a clean signal.

### 3️⃣ You are spending more than a day a week on it and the meetings have plateaued

The tell is the combination. A day a week while it is growing is an investment. A day a week while it is flat is a job you accidentally gave yourself.

Price your own time honestly. What is a day a week worth if you spent it on the work you actually sell?

### 4️⃣ You have exhausted the obvious market and do not know what to expand into

You have worked the category and the geography. The expansion order in 3.3 has run out of easy moves, and the next step involves judgment about adjacent categories, new segments or a different offer.

That is a strategy problem rather than an execution problem, and it is the point at which experience across many markets is worth more than effort in one.

### 5️⃣ The maths says a specialist costs less per meeting than your own time

Run it properly. Your monthly hard cost, plus your hours at what your hours are actually worth, divided by meetings held. Compare that to what it would cost to have it run for you.

For a lot of local businesses this crosses over earlier than they expect, because the hours are the expensive part and they never appear on an invoice.

## 🏡 The Counter-Case for Staying In-House

Three reasons to keep it, and they are good ones.

- 🧠 **The learning compounds.** Every month you run this you understand your market better, and that knowledge shows up in your pricing, your service and your sales conversations, not just your emails
- 💰 **Cost per meeting falls over time.** Your infrastructure is bought, your list is built, your copy is written. The marginal cost of month twelve is far lower than month one
- 🎛️ **You control it.** You can change the offer on Tuesday because something happened on Monday

If it is working, you are not missing replies, and it is not eating your week, keep it. There is no prize for outsourcing something that functions.

## 🤝 The Middle Option

It is not binary, and most people miss this.

- 🏗️ **Have somebody build it, then run it yourself.** The setup is the hard, technical, one-off part. The running is fifteen minutes a day
- 📞 **Keep the campaigns, outsource the calling.** If the only broken part is the reply window, fix only that
- 🔑 **Buy the data, build the rest.** Section 6.8

Hand over the specific thing that is broken rather than the whole function.

## 🧭 How to Decide

Three questions, answered honestly:

1. **Is it working?** If no, fix that before deciding who runs it. Nobody can scale something that does not work
2. **Is it costing you more than it returns**, counting your time properly?
3. **Is the next step something you want to learn?** Not can. Want

If it works, the cost is fine, and you are interested in the next step, keep it. Otherwise this is a reasonable moment to hand some or all of it over.

---

<aside>
🔑

### If You Are Carrying On In-House

LocalPipe is the local business database this guide runs on, and the part of the stack that is hardest to replicate yourself.

- 👤 **75%** owner name find rate
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- ✅ **Triple verified**, with **sub 1% bounce** on raw exports

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

<aside>
📅

### If You Recognised Yourself Above

Book a call with Harvey and the Legacy GTM team will build you a free campaign and show you how to get **15 to 30 qualified booked meetings a month** with local businesses.

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [12 · Beyond the Inbox](../12%20%C2%B7%20Beyond%20the%20Inbox%20ecc61a134ea1829dabdb015177ef0806.md)

Direct mail, the phone, territory and referral loops.

</aside>