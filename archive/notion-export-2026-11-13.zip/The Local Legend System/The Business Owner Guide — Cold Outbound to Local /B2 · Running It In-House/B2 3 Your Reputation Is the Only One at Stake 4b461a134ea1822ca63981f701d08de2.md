# B2.3 Your Reputation Is the Only One at Stake

<aside>
🛡️

**An agency spreads risk across many domains and many clients. You have one brand and one market.**

Everything in this guide applies to you the same way. The margin for error is just thinner, so a few rules stop being best practice and become non-negotiable.

</aside>

## 🎯 The 2% Bar Is a Hard Line, Not a Target

Somebody running ten programs can absorb one that bounces at 3% for a fortnight. It is a bad month on one account.

You cannot. Every domain you burn is a domain your business is using, and every complaint is attached to the only brand you have.

So the bands in 4.5 apply with less tolerance:

- ✅ **Under 2%** and carry on
- 👀 **2 to 3%** and stop sending that campaign today, not at the end of the week
- ⏸️ **5%** and pause everything while you find out why

There is no upside to riding it out. You are not hitting a quarterly target, you are protecting an asset you will still need in two years.

## 🏠 Never Send From Your Main Domain

Stated in 4.2 and worth repeating here, because the consequence lands differently on you.

An agency that burns a sending domain throws it away. If **your** company domain gets damaged, your invoices stop arriving, your quotes go to spam, and your existing customers cannot reach you.

That is not a marketing problem, it is an operations problem, and it can take months to unwind.

Lookalike domains, always, no exceptions, even for a small test.

## 🔥 Your Free-Provider Lane Needs More Care

Section 4.6 sets it out properly. The reason it matters more here:

An agency running that lane at scale can average it across several clients. You are running it on one estate, for one brand, into one market. When it goes wrong, all of the damage is yours.

- 🅿️ Park the domains properly. Do not shorten it because you are impatient
- 🐌 Ramp slower than the guide suggests, not faster
- 🔍 Verify harder here than anywhere

## 🚫 Suppression Is Not Optional

Three things belong on your suppression list before send one, and all three are more embarrassing for you than for an agency.

- 🤝 **Existing customers.** Cold emailing somebody who already pays you is a real relationship risk
- 💬 **Open quotes and live conversations.** Somebody mid-negotiation receiving a cold pitch reads as chaos
- 📇 **Everyone you know.** Suppliers, partners, the people you see at trade events. Your market is small and they talk

**Your market is a village.** That cuts both ways. Referrals travel fast, and so does a badly targeted email that landed with somebody you will see in person next month.

## 🕐 Six Months, Not Six Weeks

The re-contact rule from 3.3 is a discipline for an agency. For you it is a constraint you live inside.

You cannot move to an adjacent market if you burn this one. So the same market, the same angle, twice in a quarter is a mistake you cannot undo by switching accounts.

Keep a record of who you contacted and when, and treat it as permanent infrastructure rather than a campaign artefact.

## 🧑‍🔧 The Upside You Have

Not all of this cuts against you. Two real advantages an agency does not have.

**You know the market personally.** You have met these people. You know what they complain about, what they pay for, and what the last supplier did wrong. That is research nobody can buy and it should be all over your copy.

**Your proof is local and checkable.** "Call Dave at the practice on Mill Road" is available to you and structurally unavailable to a national competitor. Section 7.3.

Play those two hard. They are worth more than the scale you do not have.

## ✅ Before You Move On

- The 2% bar treated as a stop line rather than a target
- Lookalike domains only, with your company domain untouched
- Suppression including customers, open quotes and everyone you know
- A permanent record of who has been contacted and when
- Local knowledge and local proof used deliberately in the copy

---

<aside>
➡️

**Next:** [B2.4 When to Stop Doing This Yourself](B2%204%20When%20to%20Stop%20Doing%20This%20Yourself%20c6e61a134ea18375aa1d01f54802d099.md)

The honest markers.

</aside>