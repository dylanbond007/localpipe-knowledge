# B2.2 Your First Setter or SDR

<aside>
👥

**The trigger for hiring is not revenue. It is the number of replies you are failing to call back inside the hour.**

If that number is consistently above zero and you have tried everything else, you have a staffing problem rather than a campaign problem.

</aside>

## 🚦 When You Are Ready

All four should be true. Hiring before they are is how people end up paying somebody to sit and wait.

- 📬 **Ten or more positive replies a month**, consistently. Below that there is not enough work to hold a role
- 📉 **You are demonstrably missing the window.** Measure it for a month before you conclude it. Section 11.4
- ✅ **The campaign works.** A setter converts replies, they cannot create them. Fix the campaign first
- 💰 **The maths clears.** If a meeting is worth £X and the role costs £Y a month, how many extra held meetings does it need to produce

That last one is usually easier to clear than people expect, because the role is not creating meetings from nothing. It is rescuing meetings you already paid to generate and are currently losing.

## 👤 What You Are Actually Hiring For

Not a salesperson. Read 11.5 for the full role, but the short version: call fast, qualify lightly, book, hand over.

Which means the person you want is different from the person most people go looking for.

- ☎️ **Comfortable on the phone with strangers**, all day, including the ones who are short with them
- ⚡ **Fast rather than polished.** Speed beats eloquence in this role by a wide margin
- 📋 **Happy following a script.** Creativity here is a liability
- 🧱 **Resilient about rejection**, because most calls go nowhere and that is normal
- 📝 **Actually logs things.** Unglamorous and it is what makes the numbers readable

You are not looking for somebody who can sell. You are looking for somebody who will reliably pick up the phone within the hour, forever.

## ⏳ Full Time, Part Time, or Shared

| Shape | Works when | Watch for |
| --- | --- | --- |
| **Part time, a few hours daily** | 10 to 30 replies a month. The usual starting point | Their hours must cover your reply window, not just add up to enough time |
| **Full time** | 30+ replies a month, or the role also handles follow-up and no-show recovery | Idle time. Give them the not-now list and the reactivation list to work |
| **Outsourced or shared** | You want coverage without a hire | Response time is the whole job. Agree it in writing or it drifts |
| **Existing team member** | Somebody already answers the phone well | It has to be their named responsibility, not an addition to a full plate |

## 💷 What to Pay For

Pay for the **outcome you actually want**, which is held meetings rather than activity.

- 🧾 **A base that is genuinely liveable.** A pure commission setter will chase anything that books, and your qualification rate collapses
- 🎯 **A bonus on meetings held**, not booked. Booked is easy to game. Held is not
- 🏆 **A smaller bonus on meetings that qualify**, which is the guardrail against booking anybody with a pulse
- 🚫 **Nothing tied to dials or calls made.** You get dials, and dials are not the point

Two or three components, no more. A comp plan somebody cannot explain back to you is a comp plan that does not change behaviour.

## 🧪 How to Test For It Before You Hire

The interview is a weak signal for this role. Two better ones.

**A live call test.** Give them the script, a real record, and have them call a prospect while you listen. Fifteen minutes tells you more than an hour of conversation, because the job is the call.

**A response time test.** Send them a message at an awkward moment during the process and see how fast they respond. It is the exact behaviour the role depends on, and it is very hard to fake for long.

Look for somebody who sounds like a person on the phone rather than somebody performing confidence. Local owners can spot a call centre voice in three words.

## 📊 What to Hold Them To

Five numbers, and the first is the one that matters.

- ⏱️ **Time from reply to first attempt.** Under an hour in working hours
- 📞 **Attempts per positive reply.** Two or three, across different times of day
- 📅 **Reply to booked.** Around half
- 🤝 **Booked to held.** 70 to 80%
- ✅ **Held to qualified.** Half or better, and this is the guardrail

Review weekly for the first month, then monthly. If time to first attempt drifts, everything else follows it down.

## 🚪 The Alternative Nobody Mentions

**Keep doing it yourself and cap your volume at what you can genuinely work.**

Twenty positive replies a month that you answer inside the hour beats fifty that sit until tomorrow. Sending more than you can convert burns a finite market to produce a bigger number on a dashboard.

That is a legitimate strategy, not a compromise. Section 3.2 shows you how to size the program around the attention you actually have.

## ✅ Before You Move On

- Reply volume measured for a month, not estimated
- The maths on what a rescued meeting is worth
- A role defined as calling and booking, with selling explicitly out of scope
- A comp plan built on held and qualified, not on activity
- A live call test in your hiring process

---

<aside>
➡️

**Next:** [B2.3 Your Reputation Is the Only One at Stake](B2%203%20Your%20Reputation%20Is%20the%20Only%20One%20at%20Stake%204b461a134ea1822ca63981f701d08de2.md)

Why the margin for error is thinner when you run this yourself.

</aside>