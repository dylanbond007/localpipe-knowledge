# 07 · Offer and Lead Magnet

<aside>
🎁

**What this section does.** Builds the two offers you need: the thing you sell, and the free thing that makes a stranger give you thirty minutes. Then makes both irresistible with one tool. Written for a reader whose buyer owns the business, does the work, and signs the cheques.

</aside>

**Applies to:** Both motions for the frameworks. **B→L differs** on proof and awareness level, noted in 7.1.

## Chapters

1. **7.1 Two offers, not one** — the core offer, the lead magnet, and why most people only build one
2. **7.2 The core offer gate and the value equation** — three pass/fail tests, then the four dials
3. **7.3 Reversing the risk** — the guarantee ladder, and what an owner-operator will actually believe
4. **7.4 Lead magnets for owner-operators** — the audit wins. Profile audits, review gaps, missed calls, quote response times
5. **7.5 Offer and magnet by campaign type** — matching the offer to market state and campaign motion

---

[7.1 Two Offers, Not One](07%20%C2%B7%20Offer%20and%20Lead%20Magnet/7%201%20Two%20Offers,%20Not%20One%208e361a134ea183f283ee819bcfa4e1a1.md)

[7.2 The Core Offer Gate and the Value Equation](07%20%C2%B7%20Offer%20and%20Lead%20Magnet/7%202%20The%20Core%20Offer%20Gate%20and%20the%20Value%20Equation%2020761a134ea1822eb317017944e7b43b.md)

[7.3 Reversing the Risk](07%20%C2%B7%20Offer%20and%20Lead%20Magnet/7%203%20Reversing%20the%20Risk%206c561a134ea182b9b90b81d2dc075711.md)

[7.4 Lead Magnets for Owner-Operators](07%20%C2%B7%20Offer%20and%20Lead%20Magnet/7%204%20Lead%20Magnets%20for%20Owner-Operators%204e361a134ea1832a8727013c57f2c1e2.md)

[7.5 Offer and Magnet by Campaign Type](07%20%C2%B7%20Offer%20and%20Lead%20Magnet/7%205%20Offer%20and%20Magnet%20by%20Campaign%20Type%20beb61a134ea1833fa49e81f824ca0d0b.md)

---

<aside>
➡️

**Next section:** [08 · Campaign Architecture](08%20%C2%B7%20Campaign%20Architecture%2080961a134ea182f8bb3781d978dee5fe.md)

The campaign portfolio, and testing in a market that runs out.

</aside>