# 8.3 Testing Inside a Finite Market

<aside>
🧪

**The standard testing protocol needs more contacts than a local market contains.**

This is the sharpest practical difference between local and corporate outbound, and almost nobody writes it down. Here is the collision, and three honest ways through it.

</aside>

**Applies to:** 🏠 **L→L especially.** 🌐 **B→L differs**, and there is a note at the end for you.

## ⚔️ The Collision

The standard advice is to run three or four angles at once, with three or four versions of email one, each needing 500 to 1,000 contacts before the result means anything.

Do that maths:

- 4 angles × 3 versions × 750 contacts = **9,000 contacts** per test round
- A well-decomposed metro vertical yields roughly **2,800 verified sendable contacts** after the four cuts in 3.3

**A single test round needs three times your entire market.**

And the market does not refresh. Every contact you spend on a test is a contact you cannot spend on a campaign that works.

## 🧭 Three Honest Ways Through It

Pick one deliberately. The failure is picking none and discovering halfway through that you have used up the market learning nothing.

### 1️⃣ Test sequentially, and accept slower learning

One variable at a time. Run it to 500 contacts, read it, change one thing, run again.

- ✅ Clean reads. You always know what moved the number
- ✅ Cheapest in contacts spent
- ❌ Slow. Four rounds is four months, not four weeks
- 🎯 **Right when:** you have one market and you intend to work it for years

Use 500 rather than 1,000 per test here. You trade some certainty for the ability to run four tests instead of two, and on a small market that trade is almost always correct.

### 2️⃣ Borrow volume from adjacent markets

Run the same test across several metros, or across neighbouring categories with the same pain.

- ✅ Real sample sizes, real speed
- ✅ You find out whether a result travels, which is worth knowing anyway
- ❌ Adds a variable. A difference between metros might be the metro, not the test
- 🎯 **Right when:** you can service more than one area, or your offer works across two or three categories

### 3️⃣ Pool learning across clients or accounts

If you run outbound for more than one business in the same vertical, the aggregate is readable even when each one is not.

- ✅ The fastest learning available in this market
- ❌ Only available if you genuinely have several programs in the same category
- 🎯 **Right when:** you run several similar campaigns, in-house or otherwise

## 📏 What to Test, in Order

The order matters more when you only get a few rounds.

1. 🎯 **ICP.** Wrong audience makes everything downstream meaningless, and it is the biggest lever
2. 🎁 **Offer.** Second biggest. A different promise, not different wording
3. 💡 **Angle.** The reason you are writing, which is where signals come in
4. ✍️ **Copy.** Last, and smallest. Test the angle, not the adjectives

Most people start at four and never get to one. If you have two test rounds available in your market, spend them on one and two.

## 🔬 Test the Angle, Not the Words

A real test changes the argument. Swapping "boost" for "increase" is not a test, it is a rewrite, and at local volumes you will never detect the difference.

- ❌ **Not a test:** new subject line, tighter sentence, different sign-off
- ✅ **A test:** proximity proof against peer proof. A problem-led opener against an outcome-led one. Audit magnet against no magnet

If you cannot explain what you would learn from the result, it is not a test.

## 🛡️ Protect the Market While You Learn

Three rules that stop testing from burning your market.

- 🎰 **Hold back a control group.** Keep 20% of the market untouched until something works. It is your second chance
- 📦 **Test on your C tier first** where the result will generalise. Learn on the records you can afford to spend. Section 5.3
- ⏳ **Remember the six-month rule.** A contact you burned is workable again later with a new angle, but not next month. Section 3.3

## 📉 When You Simply Do Not Have the Volume

Sometimes the market is small enough that no testing protocol fits. A rural service area, a narrow category, a few hundred businesses.

In that case, stop testing and start talking.

Five phone calls to prospects in that market will tell you more than a statistically meaningless A/B ever will. At this size, qualitative beats quantitative, and it is faster.

## 🌐 If You Sell to Local Businesses From Anywhere

None of this binds you.

Your market is effectively unbounded, so you can run the standard protocol unchanged: four angles, three versions, full sample sizes, readable in a fortnight. Use that. It is one of the few structural advantages you have over a local operator.

The one thing worth keeping from this page is the order. ICP, then offer, then angle, then copy. That holds regardless of how much volume you have.

## ✅ Before You Move On

- One of the three approaches chosen, deliberately
- A test order that starts at ICP, not at copy
- Tests that change the argument rather than the wording
- A control group held back
- An honest answer on whether your market supports testing at all

---

<aside>
📅

### Want Someone to Do All of This for You?

Running several programs in the same vertical is the fastest way to learn what works, and it is exactly what an agency has that a single business does not.

Book a call with Harvey and the Legacy GTM team will build you a free campaign and show you how to get **15 to 30 qualified booked meetings a month** with local businesses.

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [09 · Copy](../09%20%C2%B7%20Copy%20fbe61a134ea18248a6cb815071e4014c.md)

Writing to somebody who reads their own inbox between jobs.

</aside>