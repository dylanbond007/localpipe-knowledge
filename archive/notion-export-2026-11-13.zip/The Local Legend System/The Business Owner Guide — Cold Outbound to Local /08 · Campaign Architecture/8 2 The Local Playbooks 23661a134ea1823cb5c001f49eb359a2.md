# 8.2 The Local Playbooks

<aside>
📚

**Most standard outbound playbooks are built on data that does not exist here.**

Funding rounds, headcount velocity, new-in-role moves, tech-stack changes. Half of what works everywhere else is unavailable on a business with eleven employees.

Here is what survives, what dies, and what replaces it.

</aside>

## ⚰️ The Triage

| Standard playbook | On local tier one | Why |
| --- | --- | --- |
| **Lookalike case study** | ✅ Survives intact | "We work with three practices like yours" is stronger here than anywhere |
| **Lead magnet testing** | ✅ Survives intact | The audit is the strongest asset you have. Section 7.4 |
| **Customised value prop** | ⚠️ Survives weakened | Less data to personalise on, so it leans on category and location |
| **Competitor and page followers** | ❌ Dies | Derived from professional network data that does not exist at this size |
| **Headcount growth or decline** | ❌ Dies | Nobody is publishing headcount for a twelve-person business |
| **New in role** | ❌ Dies | The owner has been in role since they founded it |

**All three dead playbooks come back on tier two.** Franchises and multi-location groups have real titles, real profiles and real role changes. If you sell to them, you already own three campaigns you thought you had lost. Section 0.3.

## 🔄 The Local Replacements

Built off the signal bench in 5.4. Each one is a campaign, not a line of copy.

### 1️⃣ Proximity and density 🏠 **L→L only**

"We already look after four businesses on your street."

The strongest angle available to a local operator and the one a national competitor structurally cannot copy. Build the list as a radius around your existing customers, not as a category across a metro.

### 2️⃣ Review response gap

They have reviews. Most are unanswered. Some of the unanswered ones are bad.

Free on the record, visible, and it gives you something specific and true to open with. Pairs naturally with the audit magnet.

### 3️⃣ Ads running now

They are already paying for leads, which means budget exists and they are actively buying growth.

Anything that converts more of what they are already buying is an easy conversation. They are not saying no on principle, they are choosing between options.

### 4️⃣ Hiring

The highest-volume signal you have, and the role names the problem for you. Hiring an office administrator means admin is the bottleneck. Hiring field staff means demand is outrunning capacity.

### 5️⃣ Second location or expansion

What worked at one site breaks at two. Systems, consistency and coverage all become live problems at exactly the moment they open.

### 6️⃣ Seasonal and weather windows

HVAC before summer. Landscaping in spring. Roofing after a storm. Predictable, schedulable, and urgent when it lands.

### 7️⃣ Bucket two forward prompt

A campaign built entirely on the generic-inbox-with-known-owner segment, where the copy names the owner in the third person or asks to be passed on.

Nobody else is running this, because most operators deleted that segment. Section 6.4.

## 🎁 Your Offer Decides Which Are Available

Not all seven work for everybody. Run them through one test:

> **Can I draw a straight line from this trigger to the thing I sell?**
> 

A commercial cleaner can use proximity, expansion and hiring. A reputation tool can use the review gap and the ads signal. Nobody can use all seven, and trying is how you end up with four campaigns that each get a quarter of the attention.

Pick the two that connect most directly, and run those properly.

## 🏗️ Build the Portfolio, Not the Perfect Campaign

Three or four running beats one that you keep polishing.

- 🐄 **Evergreen** on your core category
- 🥇 **Your strongest signal** from the list above
- 🪣 **A bucket variant**, which is the same campaign in different copy
- 📡 **A second signal**, only once the first one has proved itself

A portfolio also protects you. When a signal dries up for a month, or a category goes quiet, you still have volume running.

## ✅ Before You Move On

- An honest note on which standard playbooks you have lost
- Two local replacements chosen, connected directly to what you sell
- Tier two campaigns revived if you sell to franchises or groups
- A portfolio of three or four, not one perfect campaign

---

<aside>
🔑

### Every Replacement Playbook Needs Data the Standard Tools Do Not Carry

Review gaps, ads running, hiring, second locations, proximity. None of it exists in a corporate database, because the businesses themselves mostly are not in there.

LocalPipe is the local business database this guide runs on:

- 🗺️ Sourced from Maps, so the businesses and the signals are there in the first place
- 👤 **75%** owner name find rate
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- ✅ **Triple verified**, with **sub 1% bounce** on raw exports

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

---

<aside>
➡️

**Next:** [8.3 Testing Inside a Finite Market](8%203%20Testing%20Inside%20a%20Finite%20Market%2018561a134ea18265869e81d9622986e1.md)

What to do when your testing protocol needs more contacts than the market contains.

</aside>