# 8.1 What a Campaign Actually Is

<aside>
🗃️

**A campaign is not an email.**

It is one segment, one offer, one kind of person, one angle, sent to enough people that the result means something. Change any of those between sends and you are running two campaigns under one name.

</aside>

## 🔒 The Four Locked Variables

| Variable | Means |
| --- | --- |
| 🎯 **One segment** | One category, one geography, one tier, one contact bucket |
| 🎁 **One offer** | The same thing on sale, at the same price, with the same promise |
| 👤 **One kind of person** | On local this is usually the owner, so it rarely splits. At tier two it does |
| 💡 **One angle** | The single reason you are writing today |

Lock all four and any change in results is information. Leave them loose and you have a number that cannot tell you anything.

## 🚫 Why Blending Destroys Both the Message and the Data

Two separate costs, and people usually only notice the first.

**The message dilutes.** Copy written for a two-van operator and a twelve-location group at once is written for neither. It ends up general, and general reads as irrelevant to somebody skimming between jobs.

**The data becomes unreadable.** A 1.4% positive reply rate across a blended list might be 3% on one segment and 0.2% on another. You cannot see that. So you conclude the campaign is mediocre, when in fact one half is excellent and the other should be switched off.

The second cost is worse, because it makes you wrong about what to do next.

## 🪣 What Splits a Campaign on Local

The usual splitting axes work differently here.

- 👤 **Persona mostly collapses.** There is one person, the owner. That is a simplification you get for free
- 🪣 **Contact bucket replaces it.** Owner direct, generic with a name, generic without, and personal provider are four different campaigns with four sets of copy. Section 6.4
- 🏗️ **Tier splits hard.** A one-van operator and a regional group are different businesses. Section 0.3
- 🏷️ **Category splits when the pain differs.** Dental practices and restaurants may both buy cleaning, and they worry about different things
- 🗺️ **Geography splits when the proof differs.** If you have local references in one area and none in another, those are different campaigns

## 🧮 How Many Campaigns Is Right

Three or four running at once is the sensible shape for most local programs.

- 🐄 **One evergreen** on your core category and bucket
- 📡 **One signal-based**, on a cheap trigger
- 🪣 **One or two bucket variants** of the evergreen, which are the same campaign in different copy

That is enough to learn from and few enough to actually manage. More than four and you are dividing a finite market into slices too thin to read, which is the subject of 8.3.

## 📋 Write the Brief Before You Write the Email

One page per campaign, filled in before any copy exists:

- **Segment.** Category, geography, tier, bucket
- **Size.** How many contacts, and how many months of volume that is
- **Offer.** The one sentence version
- **Magnet.** Which one, or none
- **Angle.** The reason you are writing today
- **Ask.** What the CTA actually requests
- **Success looks like.** The number you will judge it on, decided in advance

That last line matters most. Decide what good looks like before you see the result, or you will rationalise whatever you get.

## ✅ Before You Move On

- Three or four campaigns defined, not one and not nine
- Four variables locked in each
- A brief per campaign, written before the copy
- A success number chosen in advance

---

<aside>
➡️

**Next:** [8.2 The Local Playbooks](8%202%20The%20Local%20Playbooks%2023661a134ea1823cb5c001f49eb359a2.md)

Which standard playbooks survive here, which die, and what replaces them.

</aside>