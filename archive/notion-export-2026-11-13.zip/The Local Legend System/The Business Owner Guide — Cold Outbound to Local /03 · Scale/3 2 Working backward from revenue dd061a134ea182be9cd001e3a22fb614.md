# 3.2 Working backward from revenue

<aside>
🧮

**Start at the money and work backwards.**

Nine steps from a revenue number to how many people you need to contact this month. Do it before you buy anything, because the answer is often "more than this market contains", and that is much cheaper to learn now.

</aside>

## 🔢 The Nine Steps

Work down the list. Each line divides by the stage rate above it.

1. 💰 **Revenue goal.** Pick a number and a timeframe
2. 🏷️ **Average deal value.** For recurring work, use annual contract value rather than monthly
3. 📝 **Deals needed.** Goal divided by deal value
4. ✅ **Qualified conversations needed.** Deals divided by your close rate
5. 🤝 **Meetings held.** Qualified divided by your qualification rate
6. 📅 **Meetings booked.** Held divided by your show rate
7. 💬 **Positive replies.** Booked divided by your booking rate
8. 👥 **People to contact.** Positive replies multiplied by your leads-per-positive number
9. 📨 **Emails to send.** Contacts multiplied by your sequence length

Step nine catches people out. A three-email sequence means one contact is three sends, so a thousand contacts a month is three thousand sends a month, and that is the number your infrastructure has to be sized for. Section 04.

## ➕ Add a Buffer

Multiply the final number by **1.15**.

Funnels do not behave like spreadsheets. People go quiet, a domain has a bad week, a holiday eats ten days of sending. Planning for 100% efficiency means missing every time and never knowing whether the model was wrong or the execution was.

Plan to hit about 85% of what the maths says, and build the buffer in at the start rather than explaining the gap at the end.

## 📋 A Worked Example

A commercial cleaning company wants **$180,000 of new annual contract value**.

- Average contract is **$1,500 a month**, so **$18,000 a year**
- 💰 $180,000 ÷ $18,000 = **10 new contracts**
- ✅ At a 30% close rate, that is **34 qualified conversations**
- 🤝 At half of meetings qualifying, **68 meetings held**
- 📅 At a 75% show rate, **91 meetings booked**
- 💬 At half of positive replies booking, **182 positive replies**
- 👥 At one positive reply per 75 contacted, **13,650 people contacted**
- ➕ With the 15% buffer, call it **15,700**

Spread over twelve months, that is roughly **1,300 people a month**, or **3,900 sends a month** on a three-email sequence.

## 😬 Now the Uncomfortable Part

A single well-decomposed category in one metro might give you 2,400 usable contacts.

The plan above needs 15,700.

That is not the model being wrong. That is the model doing exactly its job, in week one, for free. You now know something that would otherwise have surfaced in month five when the list ran dry and the meetings stopped.

## 🔧 Five Ways to Close the Gap

When the number is bigger than the market, you have five levers. Most people only reach for the last one.

- 📈 **Improve the funnel.** Going from one positive reply per 75 to one per 50 cuts the contacts needed by a third. That is the cheapest lever and it is mostly a list and offer question
- 💵 **Raise the deal value.** Ten contracts at $2,500 a month instead of $1,500 needs six contracts instead of ten, which is 40% less of everything
- 📬 **Work every contact bucket.** Most businesses yield two usable addresses, not one. Working all four buckets adds volume without finding a single new business. Section 6.4
- 🗺️ **Expand the market.** Adjacent categories first, then geography. Section 3.3 has the order
- 📆 **Move the timeline.** Eighteen months instead of twelve makes the same goal comfortable. Less satisfying, and often the honest answer

If none of the five gets you there, section 2.4 is the page to reread.

## ⏳ The Volume Rule

One more number, and it constrains everything above.

**Between 500 and 1,000 people contacted per campaign before the results mean anything.**

Which end you use depends on how much market you have:

- 🌊 **1,000 if your TAM is deep.** More contacts means more confidence, and you can afford to spend them
- 🪣 **500 if your TAM is tight.** You trade some certainty for the ability to run more than one test before the market is gone. On a small local market this is usually the right call

Below 500 you are not running a campaign, you are taking a sample. Positive replies on local arrive at roughly one in fifty to one hundred, so 300 contacts might produce three, and three is noise. 500 gives you five to ten, which is thin but readable. 1,000 gives you ten to twenty, which you can act on with some confidence.

Two consequences:

- 🎯 Do not judge anything, kill anything, or rewrite anything before at least 500 contacts have been through it
- 🧪 If your whole market is 2,400 contacts, that is about four tests at 500 each, or two at 1,000. Decide which you are doing before you start rather than discovering it halfway. Section 8.3

## 🧾 What to Do With the Output

You should now have four numbers written down:

- Contacts needed per month
- Sends needed per month
- The market size you need for that to be sustainable
- How many months of volume your actual market holds

Take the last two into **3.3**, which is where you find out whether the plan survives contact with the market.

---

<aside>
📅

### The Plan Is Built. Executing It Is the Work

Working backward from revenue takes an afternoon. Hitting the number takes domains, a list nobody else has, three sets of copy and somebody on the phone within the hour.

Book a call with Harvey and the Legacy GTM team will:

- 🎯 **Build you a free campaign**, not a pitch deck
- 📈 Show you how to get **15 to 30 qualified booked meetings a month** with local businesses
- 🛠️ Run the whole system so you never touch the software

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [3.3 Market size is the ceiling, not the target](3%203%20Market%20size%20is%20the%20ceiling,%20not%20the%20target%20c9e61a134ea182f99b11816cc545ae6d.md)

Sizing in usable sends rather than business counts, and what to do when it comes back short.

</aside>