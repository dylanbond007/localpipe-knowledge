# 3.1 The funnel and the one ratio

<aside>
📉

**Outbound is six stages and one ratio.**

Get the ratio right and the rest is arithmetic. Get it wrong and no amount of volume saves you.

</aside>

## 🪜 The Six Stages

Every outbound program is the same funnel, whatever you sell:

1. 📨 **People contacted**
2. 💬 **Positive replies**
3. 📅 **Meetings booked**
4. 🤝 **Meetings held**
5. ✅ **Qualified conversations**
6. 💰 **Deals closed**

Each stage loses people. That is not a problem to fix, it is the shape of the thing. What matters is knowing which stage is losing more than it should, because that tells you what to work on.

## 🎯 The One Ratio

If you track one number, track this:

> **How many people do you contact to get one positive reply?**
> 

Healthy is **one in fifty to one in a hundred**. Better than one in fifty and you have something worth scaling hard.

This is the number to watch because it is the only one that combines everything upstream of it. Deliverability, list quality, targeting, offer and copy all land in this single figure. If it is healthy, none of those four is badly broken. If it is not, one of them is, and section 10.4 tells you which.

It is also the number that lets you forecast. Once you know it, every revenue goal converts into a send volume, and every send volume converts into a market size question. That is the whole of 3.2 and 3.3.

Note - this can depend on what you sell and your market. Size it to what make sense to your TAM and your own system

## ⚠️ Why Reply Rate Alone Misleads

Reply rate counts everything: the interested, the annoyed, the unsubscribes, the out of offices.

A 6% reply rate sounds excellent and can easily be 5% negative. A 2% reply rate that is almost all positive is a better campaign.

So reply rate is still useful, just not as the thing you optimise:

- 📮 **Reply rate tracks deliverability** more than it tracks data quality. If it collapses, check the inbox before you touch the copy
- 🎯 **Positive reply rate tracks message-market fit.** That is the one that tells you whether the offer and the list belong together
- 🧭 Track both. Use the first as a health check and the second as a scoreboard

## 📊 What Good Looks Like at Each Stage

Treat these as starting assumptions. At day ninety you replace them with your own, which is the whole point of 3.4.

| Stage | Healthy range | If you are below it |
| --- | --- | --- |
| **Contacted to positive reply** | 1 in 50 to 1 in 100 | Work down the stack. Deliverability, then list, then offer, then copy. Section 10.4 |
| **Positive reply to meeting booked** | Around 30%-50% | Usually speed, not wording. On local, a reply needs a phone call within the hour. Section 11.1 |
| **Booked to held** | 70 to 80% | Your confirmation and reminder sequence is thin, or the booking window is too far out. Section 11.3 |
| **Held to qualified** | Half or better | A targeting problem, not a sales problem. You are booking the wrong businesses. Section 05 |
| **Qualified to closed** | Your own number, and you already know it | If outbound deals close worse than your other channels, look at the promise the campaign made |

## 🔍 Reading the Funnel

The useful thing about six stages is that the first one that underperforms tells you where to look. Work top down:

- 😶 **Few positive replies.** The problem is upstream of the conversation. On local it is the list about three times out of four
- 📅 **Good replies, few bookings.** Almost always response time. Everything else is a distant second
- 👻 **Bookings but no shows.** Nothing wrong with the campaign. Your confirmation layer is missing
- 🙅 **Shows but nothing qualifies.** You are reaching the wrong kind of business. Tighten the ICP before you touch anything else
- 🤷 **Qualified but no close.** Outbound did its job. Look at pricing, at the offer, or at what the email implied you would do

Fix the first broken stage, not all of them. Changing five things at once means learning nothing.

## 🧮 A Worked Example

Say you want **four new customers a month**, and one in three qualified conversations closes.

- 4 closed needs **12 qualified conversations**
- At half of held meetings qualifying, that is **24 meetings held**
- At a 75% show rate, that is **32 meetings booked**
- At half of positive replies booking, that is **64 positive replies**
- At one positive reply per 75 contacted, that is **4,800 people contacted**

So four customers a month is roughly 4,800 contacts a month. Now you know two things you did not know a minute ago: what your send volume has to be, and whether your market contains that many businesses.

If it does not, that is not a failure of the plan. It is the plan telling you something true, early, while it is still cheap to act on.

---

<aside>
📅

### Not Sure What Your Numbers Should Be?

These benchmarks come from 20M+ cold emails and 2,143 meetings booked with local business owners. If yours are a long way off and you cannot tell which stage is the problem, that is a half-hour conversation rather than a three-month experiment.

Book a call with Harvey and the Legacy GTM team will:

- 🎯 **Build you a free campaign**, not a pitch deck
- 📈 Show you how to get **15 to 30 qualified booked meetings a month** with local businesses
- 🛠️ Run the whole system so you never touch the software

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [3.2 Working backward from revenue](3%202%20Working%20backward%20from%20revenue%20dd061a134ea182be9cd001e3a22fb614.md)

The same maths run from a revenue target instead of a customer count.

</aside>