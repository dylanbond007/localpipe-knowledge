# 3.3 Market size is the ceiling, not the target

<aside>
🧱

**This is where the plan meets the market.**

In most channels, volume is a dial you turn. In local outbound it is a ceiling somebody else set. Finding out where that ceiling is takes an hour, and it is the most valuable hour in this guide.

</aside>

**Applies to:** 🏠 **L→L especially.** 🌐 **B→L differs**, and there is a note at the bottom for you.

## 🔢 Count in Usable Contacts, Not Businesses

"There are 9,000 restaurants in this metro" is not a market size. It is the number you start with before four rounds of subtraction.

Size it in stages instead:

| Stage | Example | What happened |
| --- | --- | --- |
| **Businesses in your categories and geography** | 9,400 | After proper decomposition, not one search. Section 6.3 |
| **Surviving hygiene** | 6,900 | Closed, duplicated, out of category, chains and franchises you cannot sell to |
| **Yielding at least one contactable address** | 4,100 | Around 60% combined coverage. Section 6.6 |
| **Usable contacts after bucket expansion** | 5,600 | More than the business count, because many businesses give you two addresses |
| **Verified and actually sendable** | 2,800 | Plan on keeping about half. Catch-alls, unverifiable and risky addresses get dropped before send |

Two rows deserve a second look.

**The bucket expansion row goes up, not down.** That is not an error. Many businesses yield both an owner address and a generic inbox, and both are worth contacting with different copy. Section 6.4. Work owner-direct addresses only and 5,600 becomes roughly 2,400 before verification even runs.

**The verification row is the one people forget.** Enrichment finding an address is not the same as that address being safe to send to. Catch-all domains, unverifiable mailboxes and anything a validator flags all come out before launch. Plan on keeping about half of what enrichment returns. A well-sourced list with good cross-referencing keeps more, but budget at 50% so a good result is a surprise in the right direction rather than a shortfall in the wrong one.

<aside>
🔑

### The Two Rows That Just Halved Your Market

Coverage and verification are where most of the market disappears, and they are the two things a purpose-built local database actually fixes.

LocalPipe is what this guide runs on:

- 👤 **75%** owner name find rate, so more records survive the coverage row
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- ✅ **Triple verified, sub 1% bounce** on raw exports, so the verification haircut takes far less than half
- 🗺️ Sourced from Maps rather than LinkedIn, which is why the businesses are there at all

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

## ⏱️ Turn It Into Months

Take your monthly contact target from 3.2 and divide.

Our cleaning company needed **1,300 new contacts a month**. After verification the market holds **2,800**.

That is **about two months** of first-touch volume before they have spoken to everybody once.

And the plan in 3.2 called for 15,700 contacts over the year. The market has 2,800.

## 🧱 So It Is a Ceiling, Not a Target

This is the mental shift, and it is the whole reason this section exists.

Everywhere else, the money model tells you what to aim for. Here it frequently tells you what is possible, and the honest response is to change the goal, change the market, or change the maths, rather than to send harder.

Nobody wants to hear this in week one. Everybody would rather hear it in week one than in month five, when the list runs dry, the meetings stop, and the obvious conclusion is that outbound does not work.

## 🗺️ When It Comes Back Short, Expand in This Order

Cheapest first. Most people jump straight to the fourth one.

**1. 📬 Contact buckets.** The records are already sourced and paid for. Working generic inboxes, generic-with-a-name and personal-provider addresses alongside owner-direct roughly doubles usable contacts. Nothing new to buy. Section 6.4

**2. 🏷️ Adjacent categories.** Who else has the same problem? A commercial cleaner sized on restaurants can add medical offices, dental practices, gyms, childcare centres and property managers without changing a word of the offer. Usually the biggest single unlock, and free. Section 6.3

**3. 🗺️ Geography.** Widen the radius or add the next town. Real, but check it against what you can actually service. Winning work ninety minutes out can cost more than it makes

**4. 🎚️ Loosen qualification.** Smaller businesses, ones without websites, lower review counts. This works, and it lowers conversion, so do it knowingly rather than by accident

**5. 🕐 Time.** Local markets are not permanently used up. After about six months, with a new angle and a new offer, the same market is workable again. People change jobs, situations change, and the person who ignored you in March is not the same person in October

**6. 🛑 Tell yourself the truth.** If none of the five gets you there, the market will not support the goal. Section 2.4 covers what to do instead, and it is not nothing

## 🌐 If You Are Business to Local

None of the above binds you in the same way, and the page still matters.

Your ceiling is not the market, it is what you can service. Size to your fulfilment capacity rather than your TAM, because booking thirty meetings a month you cannot deliver on is a worse problem than booking none.

What you should take from this page:

- The stage-by-stage method is still how you size **one metro**, and you will want that number when you decide where to expand next
- Bucket expansion still roughly doubles your usable contacts, and skipping it still throws away half your list
- The verification haircut still applies. Budget on half of what enrichment returns being sendable
- The two-month figure becomes a **per-market** number. It tells you how long a metro lasts before you move on, which is how you plan a rollout

## ✅ What You Should Have Written Down

By the end of this page:

- Businesses in your categories and geography
- How many survive hygiene
- How many yield a contactable address
- Usable contacts after bucket expansion
- How many survive verification, at roughly half
- Months of volume at your target rate
- Whether that clears the number 3.2 asked for

If the last one is a no, work the expansion order before you change anything else.

---

<aside>
📅

### Market Is There but the Build Is Not?

Sizing a market is the easy hour. Building the list, the infrastructure and the campaigns is the next six weeks.

Book a call with Harvey and the Legacy GTM team will:

- 🎯 **Build you a free campaign**, not a pitch deck
- 📈 Show you how to get **15 to 30 qualified booked meetings a month** with local businesses
- 🛠️ Run the whole system so you never touch the software

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [3.4 What it costs, and the calculator](3%204%20What%20it%20costs,%20and%20the%20calculator%206eb61a134ea183d58d038163156148b8.md)

Infrastructure, data, and the cost of a booked meeting.

</aside>