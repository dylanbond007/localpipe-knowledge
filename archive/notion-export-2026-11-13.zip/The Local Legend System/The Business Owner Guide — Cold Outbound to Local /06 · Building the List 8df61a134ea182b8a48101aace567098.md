# 06 · Building the List

<aside>
🗺️

**What this section does.** The longest and most important section, and the one most people came for. Google Maps is a consumer directory being used as a sales database. It holds the business, the category, the address, the phone and usually a website. It does not hold an email address and it does not hold an owner name. Everything hard follows from those two missing fields.

</aside>

**Applies to:** Both motions. The data layer does not care who you are. **B→L differs** only on 6.3, where you go wide across metros rather than deep into one.

<aside>
🤝

**Co-authored with Dylan Bond, founder of LocalPipe.** The find rates and provider comparisons in this section come from a controlled test across four data providers and an analysis of roughly 7.2 million emails sent to local businesses.

</aside>

## Chapters

1. **6.1 Why the databases you know fail on local** — coverage and saturation, and what each does to market size
2. **6.2 Sourcing from Google Maps** — what a raw record holds, and the five-stage loop
3. **6.3 Category matching and query depth** — 4,000 categories, and the three techniques that multiply your market
4. **6.4 The four contact buckets** — owner direct, generic with a name, generic without, and the personal provider address the owner reads themselves
5. **6.5 Generic and free-provider inboxes in practice** — why deleting either removes most of your reachable market
6. **6.6 Owner identification and enrichment** — the anchor chapter. Cross-referencing, the waterfall, find rates, and where cheap tools break
7. **6.7 Hygiene, coverage math and pre-send QA** — filter before you enrich, size in usable sends, and the checks that have each cost somebody a campaign
8. **6.8 Building it** — the LocalPipe interface, the API driven from Claude Code, and the judgment enrichment layer in Clay

---

[6.1 Why the Databases You Know Fail on Local](06%20%C2%B7%20Building%20the%20List/6%201%20Why%20the%20Databases%20You%20Know%20Fail%20on%20Local%2046b61a134ea1832c95c9013efc93da2f.md)

[6.2 Sourcing From Google Maps](06%20%C2%B7%20Building%20the%20List/6%202%20Sourcing%20From%20Google%20Maps%208b961a134ea1828d960b81c2fea7dc66.md)

[6.3 Category Matching and Query Depth](06%20%C2%B7%20Building%20the%20List/6%203%20Category%20Matching%20and%20Query%20Depth%20b9861a134ea18262b962810a5f0cce3a.md)

[6.4 The Four Contact Buckets](06%20%C2%B7%20Building%20the%20List/6%204%20The%20Four%20Contact%20Buckets%204ab61a134ea18394b78c818b6be4500a.md)

[6.5 Generic and Free-Provider Inboxes in Practice](06%20%C2%B7%20Building%20the%20List/6%205%20Generic%20and%20Free-Provider%20Inboxes%20in%20Practice%2088e61a134ea182a68540815d7e370d17.md)

[6.6 Owner Identification and Enrichment](06%20%C2%B7%20Building%20the%20List/6%206%20Owner%20Identification%20and%20Enrichment%200b161a134ea18287954301ca2e090be3.md)

[6.7 Hygiene, Coverage Math and Pre-Send QA](06%20%C2%B7%20Building%20the%20List/6%207%20Hygiene,%20Coverage%20Math%20and%20Pre-Send%20QA%209ea61a134ea182158ee501d1cfd9152c.md)

[6.8 Building It](06%20%C2%B7%20Building%20the%20List/6%208%20Building%20It%204aa61a134ea183f297f58111c52b869e.md)

---

<aside>
➡️

**Next section:** [07 · Offer and Lead Magnet](07%20%C2%B7%20Offer%20and%20Lead%20Magnet%2041761a134ea182ffb9c1018ddd08deca.md)

What you pitch an owner-operator, and the free thing that earns the meeting.

</aside>