# 08 · Campaign Architecture

<aside>
🗂️

**What this section does.** Turns one ICP and one offer into a set of campaigns that compounds. Then confronts the problem nobody writing general outbound material has to: the standard testing protocol needs more contacts than a local market contains.

</aside>

**Applies to:** Both motions for structure. **L→L only** for the testing constraint, which is the whole of 8.3. **B→L** can run the standard protocol unchanged.

## Chapters

1. **8.1 What a campaign actually is** — one segment, one offer, one person, one angle, and why blending destroys your data
2. **8.2 The local playbooks** — which of the six standard playbooks survive local, which die, and what replaces them
3. **8.3 Testing inside a finite market** — the volume rule against the coverage math, and three honest ways out

---

[8.1 What a Campaign Actually Is](08%20%C2%B7%20Campaign%20Architecture/8%201%20What%20a%20Campaign%20Actually%20Is%2068561a134ea183939f2c812f9c47dab8.md)

[8.2 The Local Playbooks](08%20%C2%B7%20Campaign%20Architecture/8%202%20The%20Local%20Playbooks%2023661a134ea1823cb5c001f49eb359a2.md)

[8.3 Testing Inside a Finite Market](08%20%C2%B7%20Campaign%20Architecture/8%203%20Testing%20Inside%20a%20Finite%20Market%2018561a134ea18265869e81d9622986e1.md)

---

<aside>
➡️

**Next section:** [09 · Copy](09%20%C2%B7%20Copy%20fbe61a134ea18248a6cb815071e4014c.md)

Writing to somebody who reads their own inbox between jobs.

</aside>