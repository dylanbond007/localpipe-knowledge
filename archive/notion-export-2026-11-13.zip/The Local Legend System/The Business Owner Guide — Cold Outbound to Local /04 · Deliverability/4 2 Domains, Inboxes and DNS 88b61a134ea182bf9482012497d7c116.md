# 4.2 Domains, Inboxes and DNS

<aside>
🏗️

**Get this right once and everything else has a foundation.**

Get it wrong and you will burn domains faster than you can buy them. This is the part you set up once and then hand off.

</aside>

## 🚫 Never Send From Your Main Domain

Rule one, no exceptions.

If your company runs on [**yourcompany.com**](http://yourcompany.com), you do not run cold outbound from it. One bad campaign tanks the reputation and suddenly your team cannot get invoices delivered, quotes cannot reach customers, and you are dealing with a business problem rather than a marketing one.

Buy **lookalike domains** instead:

- [getyourcompany.com](http://getyourcompany.com)
- [tryyourcompany.com](http://tryyourcompany.com)
- [yourcompany.io](http://yourcompany.io)
- [theyourcompany.com](http://theyourcompany.com)
- [yourcompanyhq.com](http://yourcompanyhq.com)

They point back to your brand, so a recipient who looks you up finds the real thing. If one burns, you throw it away and your real domain never feels it.

<aside>
🤖

**Generate them with Claude rather than by hand.**

*I'm setting up lookalike domains for cold email. Primary domain: [[yourcompany.com](http://yourcompany.com)]. Brand keyword: [brand]. Generate 25 lookalike sending-domain options using patterns like get[brand], try[brand], the[brand], join[brand], use[brand], [brand]hq, [brand]app. Must be under 35 characters. Allowed TLDs: [insert]. No hyphens, no numbers, short, readable, clearly tied to my brand. Output as a CSV, one per line.*

</aside>

## 🏷️ Picking a Registrar

Recommended: **Spaceship** or **Dynadot**.

Two rules:

- 🔀 **Do not register these at the same registrar as your main company domain.** Keep the two estates separate
- 📦 **Buy in small batches.** Never put more than about 250 domains in one account, in case of a mass ban

Spaceship often price-matches on .com and .co, so it is a fine swap if you want to shop on price. Buy the same way, follow the same rules, connect them the same way.

## 💰 Cheap Against Premium Domains

<aside>
🪙

**Cheap — around $3 to $4 each**

.info and similar.

Cheaper to start, and they burn out faster. Guaranteed. Cold emailers piled onto the cheap TLDs, almost every .info registration today is for cold email, and the spam filters caught on.

</aside>

<aside>
💎

**Premium — around $10 to $12 each**

.com and .co.

Best deliverability, longest lasting. If you have the budget, or your deal size is over $5k, skip the cheap phase entirely. The maths justifies it.

</aside>

**The honest trade-off.** If you need to prove cold email works before committing real budget, start cheap. But know that once you have proved it, you will rebuild the infrastructure on premium domains for best results. So you are paying twice.

For most local programs the deal size makes premium the right call from day one. Run it through 3.4 if you are unsure.

## 🪪 The Three Records: SPF, DKIM, DMARC

Every sending domain needs all three, correct.

- **SPF** lists which servers are allowed to send mail for your domain
- **DKIM** is a signature proving the email really came from you, untampered
- **DMARC** is a policy telling receivers what to do when one of the first two fails, and reports back to you

If one is missing or wrong, deliverability suffers and you look spammy on arrival.

That is genuinely all you need to know. Not how they work underneath. Which brings us to the next bit.

## 🙅 Why You Should Outsource the Setup

This is one of the few places worth being completely unambiguous: **do not build your own outbound infrastructure.**

- 🧰 **It is tedious and error-prone.** Buying domains, configuring DNS on each one, provisioning mailboxes, warming them, monitoring them, replacing burnt ones. That is a full-time job for somebody who already knows how
- 💸 **The savings are an illusion.** Specialist providers buy in bulk, and the reseller rate is roughly half of retail. That difference often covers the service fee on its own, and you save the labour on top
- 🎯 **Your job is running campaigns, not infrastructure.** Every hour on DNS records is an hour not spent on the offer, the copy or the list

There is a less obvious benefit too. A managed partner sending millions of emails a month spots a provider having a bad week, or a warm-up protocol that has stopped working, far faster than any single sender can. Then they tell you what to change. That pattern recognition is most of how results stay consistent month to month.

<aside>
🎁

### What We Use: InboxKit and Sendkit

**InboxKit** for managed infrastructure. You buy your domains and import them, and they configure SPF, DKIM and DMARC on every one, provision the inboxes in your chosen mix, run warm-up, and export them straight to your sequencer. You never touch a DNS record.

Pricing starts around **$3 per inbox per month** with no commitment, against a usual rate of $3.50 to $3.90. That $0.50 is $50 saved on a hundred mailboxes, and it scales from there.

Use code **GTMLAUNCHPAD**

**Sendkit** as the sequencer. Code **10GTMLAUNCHPAD** for 10% off all plans.

Full stack and buy order in section 13.1.

</aside>

## 📮 Your Inbox Lanes

Three places your mailboxes can live. Pick the mix before you buy.

| Factor | Google Workspace | Microsoft 365 (real) | Azure tenants |
| --- | --- | --- | --- |
| **Inboxes per domain** | 3 | 3 | 50 per tenant, 1 to 2 domains per tenant |
| **Cold emails per inbox per day** | 15 to 20 | About 10 | 2 to 5 |
| **Cost per inbox per month** | About $3.50 | About $3.50 | About $0.60 |
| **Best for** | Default. Your primary lane | Outlook and gateway-heavy ICPs | Cheap volume at scale |
| **Main watch-out** | Most predictable | Age-sensitive, needs aged mailboxes | One bad mailbox drags all 50 |

**Google is your primary lane, always.** It is the most predictable provider in the game and the benchmark everyone else is measured against. If you are landing in primary on Google, your fundamentals are sound. Start here.

**Azure is the cheap way to add scale.** Fifty mailboxes per tenant at around sixty cents each. The catch is that reputation is pooled across the whole tenant, so one slipping mailbox can damage all fifty, and Azure boxes burn faster than Google. Directionally, if Google gets a 2% reply rate, Azure might land 1.5 to 1.8%.

**Microsoft 365 real inboxes** are the premium Microsoft lane. Each carries its own isolated reputation, at the same cost as Google, and is native to Microsoft-heavy environments.

<aside>
🏪

**For local, Google-only is almost always right.**

Tier one local businesses are overwhelmingly on Google Workspace or a consumer provider. You are not fighting Outlook estates or security gateways at this end of the market, so the default mix in the calculator is 100% Google and you should leave it there. Section 0.3 covers when that changes.

</aside>

## 🏢 When to Actually Use Microsoft 365

Reach for M365 when your ICP genuinely lives behind Outlook and gateways:

- Healthcare organisations with 100+ employees
- Any organisation with 500+ employees
- Regulated industries: aviation, defence, finance and the like

These run Outlook plus gateways, and they trust Microsoft-to-Microsoft mail more than Google-to-Microsoft cross-provider mail.

**The caveat is that age is everything.** Only warmed, roughly three-month-old M365 mailboxes reliably land in these organisations. A fresh M365 box gets bounced no matter how cleanly you send. So you have to warm and send healthy for about three months before pointing M365 at enterprise or gateway targets.

In local terms, this is a **tier three** consideration. If you are selling to owner-operators, skip it entirely.

## 🔁 The Google to Microsoft 365 Swap

If your offer serves both smaller companies and 500-plus employee organisations, build in this order:

1. 🟢 **Build on Google.** Stand up infrastructure for the smaller segment first
2. ⏳ **Run and warm for three or more months.** Get consistent results while the mailboxes age
3. 🔵 **Then add M365** and point it at the larger, gateway-protected segment

You get revenue from the easy segment while the hard segment's infrastructure matures. Trying to do both on day one means the M365 boxes bounce and you conclude the segment does not work.

## ✅ Before You Move On

- Lookalike domains generated and bought, at a registrar separate from your company domain
- Premium unless you have a specific reason to start cheap
- Handed to a managed provider rather than configured by you
- Google-only unless you sell into tier three
- Sized using the numbers from 3.4

---

<aside>
➡️

**Next:** [4.3 Sizing Your Sending Estate](4%203%20Sizing%20Your%20Sending%20Estate%2041061a134ea182019fc2815ac1ffb76b.md)

How many inboxes and domains your volume actually needs.

</aside>