# 4.7 What to Monitor, and Reading Bounces

<aside>
📡

**Two numbers tell you almost everything.**

Reply rate against its own baseline, and bounce rate. Everything else on this page is detail underneath those two.

This is not set-and-forget, even with a managed provider.

</aside>

## 📊 The Two Numbers

**Reply rate, measured against your own baseline.** A steady 2.5% that suddenly drops to 1.5% with nothing else changed means something is happening on the deliverability side. Pause and investigate before you scale.

The absolute number matters far less than the direction. A campaign that has always run at 2% is fine. A campaign that ran at 3.5% last month and runs at 2% now has a problem, even though 2% looks acceptable on paper.

**Bounce rate, against the 2% bar.** Under 2% is healthy, 2 to 3% means investigate the list, 5% means pause, 10% means stop everything. Section 4.5.

## ⏱️ The Rhythm

| When | How long | What you check |
| --- | --- | --- |
| **Daily** | 5 minutes | Reply rate against baseline, and bounce rate. That is it |
| **Weekly** | 30 minutes | Batch rotation, warm-up status, a sample of actual bounce messages, and a real placement test |
| **Monthly** | 1 to 2 hours | Full audit with your provider. Review the lane mix and shift toward whatever is performing |

Five minutes a day is genuinely enough when nothing is wrong. The weekly half hour is where problems get caught early, and it is the one people skip.

## 👁️ Trust Placement, Not the Dashboard

This one costs people months.

Many warm-up tools report every email as landing in the primary inbox by default, even when it is sitting in spam, because a healthy-looking dashboard is easier to sell than an honest one.

**Run a real placement test weekly.** Send to seed inboxes across Gmail, Outlook and Yahoo, and confirm with your own eyes where you actually land. Insist on a tool that reports real placement, primary against spam, per mailbox.

A dashboard showing 99% inbox placement while your reply rate quietly halves is not a contradiction. It is the dashboard being useless.

## 📦 Launch in Weekly Batches

Do not dump tens of thousands of contacts into one always-on campaign.

If a bad week happens, it gets buried in the averages and takes weeks to surface. Smaller weekly batches let you isolate exactly which week slipped and react while it still matters.

On local this matters more than elsewhere, because your market is small enough that a bad fortnight can burn a meaningful share of the total contacts you will ever have. Section 3.3.

## 📨 Reading Bounce Messages

Bounce messages are diagnostic gold, and most people delete them unread.

| What the bounce says | What it means | What you do |
| --- | --- | --- |
| Mailbox does not exist, or user unknown | Invalid address | Re-verify the list. Section 6.7 |
| Domain age too young | Your sending domain is too new | Slow down, warm longer, and stay on the easy lane |
| Listed on blocklist | Domain or IP is flagged | Pause, investigate, switch domains |
| Message rejected as spam | Content or reputation | Audit the copy and the list. If that does not improve it, switch infrastructure |
| Recipient mailbox is full | Stale lead | Remove it |
| Internal company filter, or gateway reject | A security gateway is blocking outsiders | Tier three problem. Needs the aged M365 approach in 4.2 |
| Greylisted, try again later | Temporary rate limit | Usually resolves itself |

## 🔬 The Pattern That Matters Most

Read the mix, not just the rate.

<aside>
🔥

**Bounces climbing, and most of them say spam, blocked or blocklist**

Your sender reputation is in trouble.

Pause everything. This does not fix itself and sending through it makes it worse.

</aside>

<aside>
📋

**Bounces climbing, and most of them say mailbox does not exist**

This is a list problem, not an infrastructure problem.

Re-verify, find the batch or source it came from, and fix that.

</aside>

Same number on the dashboard, completely different response. Reading the messages is what tells them apart.

## 🚫 The Mistakes That Wreck Deliverability

- ✕ **Sending from your main domain.** Always lookalikes
- ✕ **Pushing volume too fast on new infrastructure.** Skip or compress warm-up and you burn a month of capacity
- ✕ **Pointing fresh infrastructure at gateways.** Easy lanes first, always
- ✕ **Ignoring bounces.** The best leading indicator you have, and free
- ✕ **Putting everything on one provider.** Hedge across lanes and shift toward what is working
- ✕ **Building it yourself to save money.** Once you price in labour and the risk of misconfiguration, the saving is usually negative

## 🗺️ Your Setup, Start to Finish

The whole of section 04 in seven steps:

1. 📊 **Decide your monthly send volume.** Section 3.2
2. 🧮 **Run the Infra Calculator.** Default to Google-only. Section 4.3
3. 🛒 **Order lookalike domains and inboxes** through a managed provider. Section 4.2
4. 🔥 **Kick off warm-up** and leave it alone for two weeks. Section 4.4
5. 🔌 **Connect the inboxes to your sequencer** and confirm warm-up is running
6. 🔑 **Stand up the free-provider lane separately**, parked and rotating. Section 4.6
7. 📡 **Set the monitoring rhythm** on this page before the first send, not after the first problem

## ✅ Before You Move On

- Reply rate baseline recorded, so you can spot a drop
- Bounce rate visible daily, against the 2% bar
- A weekly placement test using real seed inboxes, not a dashboard number
- Campaigns launching in weekly batches rather than one always-on list
- Someone actually reading the bounce messages

---

<aside>
🔑

### Building This In-House?

Most of what you monitor on this page traces back to data quality. Bounces, complaints, and the placement drift that follows them all start with who is on the list.

LocalPipe is the local business database this guide runs on:

- ✅ **Triple verified**, with **sub 1% bounce** on raw exports
- 👤 **75%** owner name find rate
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

<aside>
📅

### Or Hand the Whole Thing Over

Two estates, a rotation schedule, weekly placement tests and a bounce inbox somebody has to actually read. It is not hard. It is just permanent.

Book a call with Harvey and the Legacy GTM team will:

- 🛠️ Run **both lanes** on our infrastructure, monitoring included
- ⚡ Launch your pilot on **inboxes that are already aged and warmed**
- 📈 Show you how to get **15 to 30 qualified booked meetings a month** with local businesses

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [05 · ICP and Signals](../05%20%C2%B7%20ICP%20and%20Signals%202c161a134ea1837ba5cd813877e8c994.md)

Who to target, how to score them, and the public signals that actually exist on a local business.

</aside>