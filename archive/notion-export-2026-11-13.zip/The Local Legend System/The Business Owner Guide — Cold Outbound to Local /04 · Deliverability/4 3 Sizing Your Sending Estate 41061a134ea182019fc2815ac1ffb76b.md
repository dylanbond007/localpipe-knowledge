# 4.3 Sizing Your Sending Estate

<aside>
📐

**How many inboxes and domains do you actually need?**

One short chain of arithmetic, and the answer is almost always smaller than people expect. Lane selection is in 4.2. This page is the maths.

</aside>

## 🔗 The Chain

Four steps, in this order. Everything follows from your monthly send volume.

1. 📨 **Monthly sends.** From 3.2. Contacts multiplied by sequence length
2. 📅 **Daily sends.** Monthly divided by sending days per month
3. 📬 **Inboxes.** Daily sends divided by sends per inbox per day
4. 🌐 **Domains.** Inboxes divided by inboxes per domain

That is it. Three divisions.

## 🗓️ Sending Days per Month

Use **22** for business sending. Weekdays only, because emailing a business owner on a Sunday gets you ignored at best.

Use **30** only for the free-provider lane, where calendar-aligned cycling maths applies. Section 4.6.

This single number moves everything downstream, so set it once and leave it.

## ⚡ Sends per Inbox per Day

| Lane | Steady state | Inboxes per domain |
| --- | --- | --- |
| 🟢 **Google Workspace** | 15 to 20 | 3 |
| 🟠 **Microsoft 365** | About 10 | 3 |
| 🔵 **Azure** | 2 to 5 | 50 per tenant |

**Size on 15 for Google.** It is the conservative end of the range and it costs you very little to have one spare inbox.

<aside>
⚠️

**Steady state is not day one.**

These are the numbers you reach *after* warm-up and ramp, around week five or six. You do not start here. Size your estate for steady state, then ramp into it. Section 4.4.

</aside>

## 📋 A Worked Example

The cleaning company from section 03 needs **1,300 contacts a month** on a three-email sequence.

- 📨 1,300 × 3 = **3,900 sends a month**
- 📅 3,900 ÷ 22 = **178 sends a day**
- 📬 178 ÷ 15 = **12 inboxes**
- 🌐 12 ÷ 3 = **4 domains**

Twelve inboxes at roughly $3 each is about **$36 a month**. Four premium domains at $11, reused across a quarter, is about **$15 a month**.

Around **$50 a month** of sending infrastructure to support a program targeting five new contracts a year at $18,000 each. This is why the monthly bill is the least interesting number in section 03.

## 🔄 Running It Backwards

Useful when you already own an estate and want to know what it can carry.

**Inboxes × sends per inbox × sending days = monthly capacity.**

Twelve Google inboxes: 12 × 15 × 22 = **3,960 sends a month**.

If your plan needs more than that, you add inboxes. You do not push the existing ones harder, which is the single most common way people burn infrastructure they have already paid for.

## 📈 Size With Headroom

Add about **20%** to whatever the chain returns.

Three reasons:

- 🔧 A mailbox occasionally goes offline or needs replacing mid-month
- 📊 Volume is never perfectly even. Batch launches cluster
- 🚀 You will want to add a second campaign before you want to buy more infrastructure

Twelve inboxes becomes fourteen or fifteen. At three dollars each, headroom is the cheapest insurance in this section.

**Oversizing is close to harmless.** Each inbox simply sends less, which providers read as more human, not less. Undersizing means pushing inboxes past their safe rate, which is how you lose them.

## 🔥 Budget for Replacement

Domains do not last forever. On business sending you reuse a domain across roughly a quarter, which is why the calculator divides domain cost by three to get a monthly figure.

Plan on replacing a portion of the estate every quarter as a normal running cost rather than a failure. When a domain's placement degrades, you retire it and warm a replacement. That is the job, not a sign something went wrong.

The free-provider lane is far more aggressive on this, and it gets its own maths in 4.6.

## 🚦 When to Add More

Four triggers, and only four:

- 📈 **Your monthly contact target goes up.** Rerun the chain
- 🆕 **You add a campaign** that is not replacing an existing one
- 🔑 **You start working the free-provider segment.** That is a separate estate, not an extension of this one
- ♻️ **A domain gets retired** and you need to hold capacity while its replacement warms

Not a trigger: a low reply rate. More inboxes will not fix a message problem, and sending more of something that is not working is the most expensive mistake in this guide. Section 10.4.

## 🧮 Let the Calculator Do It

The **Infra Calculator** tab runs this whole chain. Enter your monthly send volume, leave the split at 100% Google, and it returns inboxes, domains and total monthly cost.

Defaults are already set for local: 22 sending days, 15 sends per inbox, 3 inboxes per domain. Section 3.4 explains why you should not change them yet.

<aside>
📊

### Open the Calculator

[**👉 The Local Legend Money Model**](https://docs.google.com/spreadsheets/d/1SCPMYKU4_lguC11AGqwnlqoJSqLd-lsJhnt4iEeTpTQ/edit?gid=1669046753#gid=1669046753)

File > Make a copy, then go to the **Infra Calculator** tab and enter your monthly send volume in the blue cell.

</aside>

---

<aside>
📅

### Rather Not Own an Estate at All?

Twelve inboxes, four domains, DNS on every one, warm-up running, and a replacement cycle every quarter. It is not difficult, it is just permanent.

Book a call with Harvey and the Legacy GTM team will:

- 🎯 **Build you a free campaign**, not a pitch deck
- 📈 Show you how to get **15 to 30 qualified booked meetings a month** with local businesses
- 🛠️ Run the infrastructure on our estate so you never touch a DNS record or replace a domain

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

<aside>
➡️

**Next:** [4.4 Warm-Up and Ramp](4%204%20Warm-Up%20and%20Ramp%203cc61a134ea182ff992c81263d182821.md)

Two different things, both skipped constantly, and what happens when you skip them.

</aside>