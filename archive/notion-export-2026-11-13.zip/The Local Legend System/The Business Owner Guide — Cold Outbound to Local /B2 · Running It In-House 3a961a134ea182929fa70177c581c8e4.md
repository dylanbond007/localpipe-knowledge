# B2 · Running It In-House

<aside>
🏠

**What this section does.** Everything about operating this yourself rather than paying somebody. Who works the replies, when to hire, and the honest markers that tell you it is time to stop doing it alone.

</aside>

**Applies to:** Both motions. This section does not exist in the agency version.

## Chapters

1. **B2.1 Fitting this into a job you already have** — fifteen minutes daily, an hour weekly, and what happens when you skip it
2. **B2.2 Your first setter or SDR** — when to hire, what to pay, what to test for
3. **B2.3 Your reputation is the only one at stake** — no client estate to fall back on, which raises the cost of a mistake
4. **B2.4 When to stop doing this yourself** — the markers, honestly

---

[B2.1 Fitting This Into a Job You Already Have](B2%20%C2%B7%20Running%20It%20In-House/B2%201%20Fitting%20This%20Into%20a%20Job%20You%20Already%20Have%203da61a134ea182829adc01c03faeb847.md)

[B2.2 Your First Setter or SDR](B2%20%C2%B7%20Running%20It%20In-House/B2%202%20Your%20First%20Setter%20or%20SDR%20a9f61a134ea1837d8cbd0194c74b6e6e.md)

[B2.3 Your Reputation Is the Only One at Stake](B2%20%C2%B7%20Running%20It%20In-House/B2%203%20Your%20Reputation%20Is%20the%20Only%20One%20at%20Stake%204b461a134ea1822ca63981f701d08de2.md)

[B2.4 When to Stop Doing This Yourself](B2%20%C2%B7%20Running%20It%20In-House/B2%204%20When%20to%20Stop%20Doing%20This%20Yourself%20c6e61a134ea18375aa1d01f54802d099.md)

---

<aside>
➡️

**Next section:** [12 · Beyond the Inbox](12%20%C2%B7%20Beyond%20the%20Inbox%20ecc61a134ea1829dabdb015177ef0806.md)

Direct mail, the phone, territory and referral loops.

</aside>