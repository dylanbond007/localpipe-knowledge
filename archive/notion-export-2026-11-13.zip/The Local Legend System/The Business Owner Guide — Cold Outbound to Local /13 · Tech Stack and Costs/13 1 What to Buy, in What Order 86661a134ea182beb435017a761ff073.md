# 13.1 What to Buy, in What Order

<aside>
🧰

**Buy in this order. Nothing before its turn.**

The stack is smaller than people expect. Most of what gets sold as essential is optional, and buying it early is how a program costs three times what it should before it has sent anything.

</aside>

## 🛒 The Buy Order

| # | Layer | When | Why now |
| --- | --- | --- | --- |
| **1** | 🌐 **Domain registrar** | Day one | Warm-up clock starts here. Nothing else has a waiting period |
| **2** | 📬 **Managed inbox infrastructure** | Day one | Same reason. Provisioning and warm-up run in parallel with everything else |
| **3** | 📤 **Sequencer** | Day one to three | The inboxes need somewhere to connect to |
| **4** | 🗺️ **Local data source** | Day three | Before you build the list, which is day four |
| **5** | 🧠 **Enrichment and orchestration** | Day three to four | Only if you need judgment enrichment. Many programs do not |
| **6** | ✅ **Verification** | Day four | For anything you resolved yourself. Skip it on pre-verified data |
| **7** | 📅 **Booking tool** | Before launch | Needed the day the first reply arrives, not before |
| **8** | 🔔 **Reply alerting** | Before launch | Non-negotiable. Section 11.4 |
| **9** | 🗂️ **CRM** | Only if you do not have one | A spreadsheet is genuinely fine at this volume |
| **10** | 🎙️ **Call recording** | Month two or three | Useful for improving the call, useless before you have calls |

## 1️⃣ Registrar

Where you buy the lookalike domains. Section 4.2.

**Spaceship** or **Dynadot**. Not the same registrar as your company domain, and buy in small batches rather than hundreds in one account.

Premium TLDs unless you have a specific reason to start cheap. On most local deal sizes the maths clears immediately.

## 2️⃣ Managed Inbox Infrastructure

The one thing on this list you should definitely not do yourself.

**InboxKit** is what I use. You import the domains and they configure the authentication records on every one, provision the inboxes, run warm-up and export them into the sequencer. You never touch a DNS record.

Around **$3 per inbox per month** with code **GTMLAUNCHPAD**, against a usual rate closer to $3.50 to $3.90.

You also need a **premium warm-up pool** if you are running the free-provider lane, because a standard pool cannot generate signal against personal inboxes. Warmy is the one I use. Section 4.6.

## 3️⃣ Sequencer

**Sendkit** is the default here. Code **10GTMLAUNCHPAD** for 10% off all plans.

Whatever you pick, it needs to handle multiple inboxes, per-bucket campaigns, fallback text on merge fields, and reliable reply detection. Reply detection is the one people do not check until it fails.

## 4️⃣ Local Data Source

**This replaces the corporate database at the primary slot, rather than sitting alongside it.**

That is the single biggest difference between this stack and a standard outbound stack. Under 5% of local businesses appear in the major B2B databases, so a tool built for corporate targeting is not a partial solution here, it is the wrong tool. Section 6.1.

## 5️⃣ Enrichment and Orchestration

Only for the judgment layer: reading a site and answering a question specific to your offer.

**Clay** is the default if you want it visual. **Claude Code** if your sourcing already lives there. Plenty of local programs never need either. Section 6.8.

## 6️⃣ to 🔟 Everything Else

- ✅ **Verification** for anything you resolved yourself. Pre-verified data does not need a second pass
- 📅 **A booking tool** with a mobile-friendly page, redirecting to your pre-call page. Section 11.3
- 🔔 **Reply alerting** to a phone. A text or a push, not another email
- 🗂️ **A CRM only if you lack one.** At 2,000 sends a month a spreadsheet holds up fine
- 🎙️ **Call recording** from month two, to improve the call rather than to create it

## 💸 The Minimum Viable Stack

What you actually need on day one, for a program sending a few thousand a month:

- Domains
- Managed inboxes
- A sequencer
- A local data source

That is it. Four things. Everything else is either free, already owned, or bought later.

## 🚫 What to Skip

- 🤖 **AI SDR platforms.** They automate the part that should not be automated
- 🧲 **Intent data tools** built on corporate signals, which do not exist at tier one
- 🏢 **Enterprise sales platforms.** Built for teams of twenty
- 📦 **All-in-one suites** that do six things adequately and the data layer badly
- 💼 **A corporate contact database**, unless you sell to tier two or three as well

## ✅ Before You Move On

- Domains and inboxes ordered on day one, before anything else
- A local data source at the primary slot
- A four-item minimum stack, with everything else deferred
- Reply alerting sorted before launch, not after

---

<aside>
🔑

### The One Purchase That Decides the Rest

Everything downstream runs on what the data layer returns. A thin record cannot be scored, segmented, personalised or called.

LocalPipe is the local business database this guide runs on:

- 👤 **75%** owner name find rate
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- 📞 Owner phone returned alongside the email
- ✅ **Triple verified**, with **sub 1% bounce** on raw exports
- 💸 Pay on find, so empty records cost you nothing

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

---

<aside>
➡️

**Next:** [13.2 The Data Layer Compared](13%202%20The%20Data%20Layer%20Compared%20bda61a134ea182b2b64681a3692c31f5.md)

Five approaches, honestly.

</aside>