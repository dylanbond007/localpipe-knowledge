# 10 · Launch, Operate, Diagnose

<aside>
🚀

**What this section does.** Takes it live without burning the domains you just paid for, keeps it running on a rhythm, and finds the real break when the numbers slip. On local the break is in the list about three times out of four, which is why the diagnostic runs bottom-up.

</aside>

**Applies to:** Both motions. One change worth flagging: the pre-email fast lane is the phone and direct mail here, not LinkedIn.

## Chapters

1. **10.1 The launch timeline** — two lanes, six weeks, and what goes live in week two
2. **10.2 Pre-launch and copy QA** — the infrastructure, list, copy and tracking checks, merged into one pass
3. **10.3 The numbers to watch** — four leading, four lagging, and the good-campaign benchmark
4. **10.4 The four-pillar diagnostic** — deliverability, prospect, offer and copy, scale. In that order

---

[10.1 The Launch Timeline](10%20%C2%B7%20Launch,%20Operate,%20Diagnose/10%201%20The%20Launch%20Timeline%2093c61a134ea182ab8bf881f1006889c6.md)

[10.2 Pre-Launch and Copy QA](10%20%C2%B7%20Launch,%20Operate,%20Diagnose/10%202%20Pre-Launch%20and%20Copy%20QA%2025461a134ea18286865e8101341eb346.md)

[10.3 The Numbers to Watch](10%20%C2%B7%20Launch,%20Operate,%20Diagnose/10%203%20The%20Numbers%20to%20Watch%2073d61a134ea1835ba91a01249a418e35.md)

[10.4 The Four-Pillar Diagnostic](10%20%C2%B7%20Launch,%20Operate,%20Diagnose/10%204%20The%20Four-Pillar%20Diagnostic%2024461a134ea18394bc9801cd07bb7b1c.md)

---

<aside>
➡️

**Next section:** [11 · Replies to Booked Meetings](11%20%C2%B7%20Replies%20to%20Booked%20Meetings%201de61a134ea182a9829881f4f9d162ba.md)

Why on local the reply is a cue to pick up the phone.

</aside>