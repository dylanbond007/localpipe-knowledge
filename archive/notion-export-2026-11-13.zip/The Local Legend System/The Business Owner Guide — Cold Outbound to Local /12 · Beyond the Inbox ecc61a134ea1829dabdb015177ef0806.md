# 12 · Beyond the Inbox

<aside>
📦

**What this section does.** The channels that compound on top of a working email program. Direct mail is the standout and it is barely used against local businesses. LinkedIn is close to useless on one-van operators and genuinely good on franchises, which is why the tier model earns its place.

</aside>

**Applies to:** Mixed, and marked per chapter. 12.3 is **L→L only**. 12.1 and 12.4 apply to both.

## Chapters

1. **12.1 Direct mail to local businesses** — when it beats email, cost per touch, and QR scan routing into a real workflow
2. **12.2 The phone, LinkedIn and DMs** — layering the phone, and where LinkedIn does and does not exist
3. **12.3 Territory, proximity and density** — why a scattered list produces work you cannot profitably service
4. **12.4 Referral loops and recommendation threads** — the highest-converting channel local has, and it falls out of outbound as a side effect

---

[12.1 Direct Mail to Local Businesses](12%20%C2%B7%20Beyond%20the%20Inbox/12%201%20Direct%20Mail%20to%20Local%20Businesses%20fd561a134ea183b0828181f6c96f6163.md)

[12.2 The Phone, LinkedIn and DMs](12%20%C2%B7%20Beyond%20the%20Inbox/12%202%20The%20Phone,%20LinkedIn%20and%20DMs%202fb61a134ea18241a60281a4ac20baed.md)

[12.3 Territory, Proximity and Density](12%20%C2%B7%20Beyond%20the%20Inbox/12%203%20Territory,%20Proximity%20and%20Density%2045d61a134ea18272b619017529707584.md)

[12.4 Referral Loops and Recommendation Threads](12%20%C2%B7%20Beyond%20the%20Inbox/12%204%20Referral%20Loops%20and%20Recommendation%20Threads%20c5461a134ea18383b14f01c3b4fbb0b3.md)

---

<aside>
➡️

**Next section:** [13 · Tech Stack and Costs](13%20%C2%B7%20Tech%20Stack%20and%20Costs%205d761a134ea182ebb9c90117f192e548.md)

What to buy, in what order, and nothing you do not need.

</aside>