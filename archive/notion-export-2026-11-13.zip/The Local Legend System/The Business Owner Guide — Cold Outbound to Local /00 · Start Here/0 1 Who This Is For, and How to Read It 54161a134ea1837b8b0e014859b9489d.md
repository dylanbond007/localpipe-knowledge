# 0.1 Who This Is For, and How to Read It

<aside>
🏪

**This guide is about selling to local businesses.**

Everything in it, from the data to the deliverability work to the copy, is built around one kind of buyer: someone who owns a business with a physical location, does some of the work themselves, and reads their own inbox.

If that is who you want meetings with, you are in the right place.

</aside>

## 🏪 What "Local Business" Means Here

The definition matters, because it does real work throughout the guide. A local business, for our purposes, has four properties:

- 📍 **A physical location, or a defined service area.** A shop, a clinic, a yard, a fleet of vans
- 👤 **An owner who is close to the work.** They quote jobs, they answer the phone, they know every customer's name. No procurement process, and often no marketing person
- 🗺️ **A customer base defined by geography.** They serve the city, the county, the metro
- 🕳️ **Almost no presence in the B2B databases.** This is the operative one. The tools most people use to build lists were built for companies with LinkedIn pages, funding rounds and org charts. A twelve-person landscaping company has none of those, so as far as those tools are concerned it does not exist

That last property is why this guide exists at all. Everything difficult about local outbound follows from it.

**Not local, for our purposes:** remote-first companies, ecommerce brands, software companies, and anything with a head office and distributed staff. Those are well served by the standard playbook.

## 👤 Who This Version Is Written For

You run a business, and you want more meetings with local business owners. The meetings land on your calendar, or your team's. You are either building this in-house or working out whether you should.

Within that, there are two kinds of reader:

- 🏠 **You are also a local business**, selling into your own area. A commercial cleaner going after restaurants. A landscaper going after property managers
- 🌐 **You are not location-constrained**, but your customers are local businesses. Software for trades. Coaching for contractors. A lender to small business owners

Work out which you are in **0.2 Pick Your Motion**. Two minutes, and it determines which version of about a fifth of the pages applies to you.

## 🚫 Who This Is Not For

- **Agencies running this for clients.** There is a separate version covering client acquisition, pricing, cross-client suppression and the handoff. Go back to the entry page and take that one
- **Anyone selling to consumers.** Cold email to private individuals is a different practical and legal problem, and none of this transfers
- **Anyone who needs meetings this week.** Warm-up alone takes two weeks before the first real send. This is still the right thing to start, but it is not the thing that fixes this month

## ✅ What You Need Before You Start

<aside>
✅

**An offer that has closed at least once.** Cold outbound is an amplifier. It finds more of what already works. It does not discover what works.

**Someone who can call back within the hour.** On local, a reply is a cue to pick up the phone. If nobody can do that reliably, read 11 before you spend anything.

**Two weeks of patience before the first send**, and six to eight before the first meeting.

**Fifteen minutes a day** once it is running, and a couple of hours a week in the first month.

**A budget you can hold for ninety days.** Real numbers are in B1.2.

</aside>

If you cannot tick the first two, fix those first. Nothing in the rest of this guide will compensate.

## 🧭 How to Read It

**Reading order and doing order are not the same thing.**

The sections are numbered so the ideas build on each other. Follow that order literally and you will spend two weeks waiting for inboxes to warm at exactly the wrong moment.

So:

1. 🥇 **Order your infrastructure on day one**, before you have decided anything else. Section 04 tells you what to buy. The warm-up clock runs in the background whether or not you are ready
2. 🔁 **Then work the loop.** Who you are emailing decides what you pitch. What you pitch decides your campaigns. Your campaigns decide your copy. Your copy decides what data you need to go and find
3. 📋 **Build the list last.** Deliberate. Your copy tells you what to enrich for, and email addresses go stale within weeks, so you pull them days before launch rather than months

The full schedule is in **0.5 Launch in 15 Days**.

## 🔀 The Markers

Most rules here apply to everybody. Where they do not, the page says so in place:

| Marker | What it means |
| --- | --- |
| **Both motions** | The rule holds either way. Most of the guide |
| **L→L only** | True because you have to service the work locally. Skip it if you sell everywhere |
| **B→L differs** | The rule changes if you are not location-constrained, and the page says how |
| **Tier-dependent** | Changes depending on whether you sell to one-van operators, franchises, or large commercial. See 0.3 |

## ❌ What This Guide Does Not Cover

Said plainly so you are not waiting for it:

- **Consumer marketing.** Nothing here applies to selling to the public
- **Paid ads and search**, except where they interact with outbound. Good complement, different craft
- **Anything that changes quarterly.** Warm-up ratios and platform settings move constantly. Where a number like that appears, it is labelled as a current baseline rather than a rule
- **Legal advice.** 15.4 covers the operational side of compliance. It is not a substitute for a lawyer in your jurisdiction

## 🎯 One Expectation Worth Setting Now

Most of the work in local outbound happens before a single email is written. The list is where campaigns are won and lost here, far more than in ordinary B2B, because the list is something you build rather than something you buy.

If you take one thing from this page: **the copy is not the lever. The list is.**

---

<aside>
➡️

**Next:** [0.2 Pick Your Motion](0%202%20Pick%20Your%20Motion%208f661a134ea1838192840113fad7c17e.md)

Two minutes, and it decides which version of the guide you are reading.

</aside>