# 0.4 The Numbers, and Where They Come From

Every number in this guide appears again on the page where it matters. This is the one place they all sit together, so you can plan against them before you spend anything.

Read them as ranges, not promises. A well-built list hits these. A badly built one misses them by a lot, and the gap between a good process and a lazy one is wider than the gap between one industry and another.

## 📊 The Numbers to Plan Against

| Measure | What to expect | Notes |
| --- | --- | --- |
| Bounce rate | Under 2% | 2–3% means investigate the list. 5% means pause. 10% means stop everything |
| Bounce on free-provider addresses | About 1.6% | Roughly a third higher than the rest of your list. Fine on its own, bad mixed in |
| Owner name found | About 75% | Depends entirely on how many sources you check. One source lands far below this |
| Owner's direct email found | About 42% | The number to size a market on |
| Any usable email found | About 60% | Includes records that give you a generic inbox but no personal address |
| Owner's direct phone found | About 20% | Low, and worth more per record than anything else on this list |
| Reply rate | 3–4% | Tracks deliverability more than data quality |
| People contacted per positive reply | 50–100 | The main efficiency number. Better than 1 in 50 and you have something worth scaling |
| Monthly sends (Local-local) | 2,000–4,000 | Limited by how big the market is, not by how many inboxes you own |
| Qualified meetings a month | 8–12 | At that volume, in a market that can support it |

## 🗺️ The Numbers Behind the List

These come up in section 06. They are worth seeing early, because they explain why the list is where the work is.

| Measure | Figure |
| --- | --- |
| Local businesses covered by the major B2B databases | Under 5% |
| Home service businesses missing from them entirely | 80–90% |
| Extra coverage from sourcing out of Maps instead | 3–20x, depending on the trade |
| Positive reply lift on contacts nobody else has | About 1.6x |
| Extra results from going past page one | About 84% |
| Extra results from more query phrasings | About 23% |
| Extra results from splitting a dense area by ZIP | Roughly double |
| Categories in the Maps taxonomy | About 4,000 |
| Cost to scrape a thousand businesses | Around a dollar |

## 📚 Where These Came From

Three places, and they carry different weight.

Most of the market-level figures come from LocalPipe's analysis of roughly 7.2 million emails sent to local businesses. That is a big enough sample to trust the direction, though it is one company's dataset rather than an industry survey.

The find rates and the provider comparisons come from testing four data providers against the same lists, holding the offer and the infrastructure steady. That is the cleanest evidence here.

The rest comes from running these campaigns. Legacy GTM has sent over 20 million cold emails and booked 2,143 meetings with local business owners. Real numbers from real programs, but they are our programs, so treat them as informed expectations rather than proven averages

## 🎯 On the 2% Bounce Rate

This one gets its own note because you will see other numbers elsewhere.

General cold email advice often treats 3% as acceptable. For local lists, 2% is the line. Local data is built rather than bought, so a high bounce rate almost always means something upstream is wrong — you skipped verification, the list went stale, or you kept addresses scraped off websites that were never real mailboxes.

Under 2% is healthy. Between 2 and 3%, go and look at the list. At 5%, pause and fix it. At 10%, stop everything, because you are actively damaging domains you paid for.

- ✅ **Under 2%.** Healthy
- 👀 **2 to 3%.** Go and look at the list
- ⏸️ **5%.** Pause and fix it
- 🛑 **10%.** Stop everything. You are actively damaging domains you paid for

The one exception is the free-provider segment, which runs higher by design and needs its own infrastructure. That is covered in 4.6.

## 🤔 When Your Numbers Disagree

They will, and it is usually fine.

If you are above these, you probably have a good list in an under-worked market. Do more of it.

If you are below, work down the stack rather than across it. Check deliverability first, then the list, then the offer, then the copy. On local the problem is in the list about three times out of four, which is the opposite of where most people look. Section 10.4 walks the diagnosis properly.

And do not average these across trades. Plumbers and dental practices behave differently, and a blended number hides the campaign that is working inside a portfolio that is not.

---

<aside>
🔑

### Where These Numbers Come From

The find rates on this page are what a purpose-built local data layer returns. A corporate database returns roughly a fifth of the owner names and a sixth of the email coverage on the same market.

LocalPipe is the one this guide runs on:

- 👤 **75%** owner name find rate
- ✉️ **60%** combined email coverage
- ✅ **Triple verified**, with **sub 1% bounce** on raw exports

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

---

<aside>
➡️

**Next:** [0.5 Launch in 15 Days](0%205%20Launch%20in%2015%20Days%201b061a134ea183108c698102f24e3421.md)

The build schedule day by day, then the first 90 days.

</aside>