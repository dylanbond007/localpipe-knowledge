# The Agency Guide — Cold Outbound to Local Business ICPs

<aside>
🏢

**For agencies already running outbound who want better results in local markets.**

This is not a course on cold email. It assumes you can build a sequence, provision domains, read your own metrics and construct an offer. What it explains is why a playbook that works everywhere else underperforms against local businesses, and what to change.

</aside>

## ⚠️ One Question First

<aside>
🔀

### Are You an Agency Trying to Win Clients for Yourself, Rather Than Running Outbound for Clients?

If you want more meetings on **your own** calendar, and outbound is not a service you currently sell, you are a business wanting meetings rather than an agency running campaigns. Everything will make more sense in the other version.

Take [**The Business Owner Guide**](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20%20f2961a134ea18308bfbe014b0ee3475c.md) instead, and read it as **Business → Local**, since your customers are local businesses but you are not tied to a place.

**Still here?** Then you run outbound for clients, and the rest of this is written for you.

</aside>

## 🎯 What Is Different in This Version

Compared to the version written for businesses running this in-house:

- **No fundamentals.** You have a method. What survives is the page on what local changes, lever by lever
- **Two sections that only exist here.** Winning the client, and running the engagement
- **A dozen shared pages that shift.** Market sizing becomes a pre-sale feasibility test, the handoff becomes a contract conversation, and the setter becomes something you sell rather than something you hire
- **One advantage you have and they do not.** You can pool test learning across several clients in the same vertical, which is the only honest way around the volume problem in a small market

## 📊 Benchmarks at a Glance

Every figure is qualified on its own page. These are the reference ranges for a well-built local list.

| Measure | Range | Note |
| --- | --- | --- |
| **Bounce rate** | Under 2% | The single bar for this guide. 2 to 3% investigate the list, 5% pause, 10% stop everything |
| Bounce, free-provider segment | About 1.6% | Roughly 32% higher than the rest. Workable in isolation, ugly mixed in |
| Owner name find rate | About 75% | Depends entirely on how many sources you cross-reference |
| Owner direct email find rate | About 42% | The number to size a market on |
| Combined contactable coverage | About 60% | Counts records giving a generic address but no owner-specific one |
| Owner phone find rate | About 20% | Low, and disproportionately valuable |
| Reply rate | 3 to 4% | Tracks deliverability more than data quality |
| Contacts per positive reply | 1 per 50 to 100 | The primary efficiency number |
| Monthly sends per client | 2,000 to 4,000 | Constrained by market size, not by infrastructure |
| Qualified meetings per month | 8 to 12 | At the volume above, in a healthy market |

## 📚 The Guide, in Reading Order

[00 · Start Here](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/00%20%C2%B7%20Start%20Here%20b6161a134ea18311a0478176a68865ad.md)

[01 · Foundations](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/01%20%C2%B7%20Foundations%2068b61a134ea1836ca4be818647e47d09.md)

[02 · The Two Motions](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/02%20%C2%B7%20The%20Two%20Motions%20f1f61a134ea1829c8896016efbf2524a.md)

[A1 · Winning the Client](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/A1%20%C2%B7%20Winning%20the%20Client%2010e61a134ea1826c8c9681cee86cac25.md)

[03 · Scale](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/03%20%C2%B7%20Scale%20fb961a134ea182f5ac4b8136dfa130fa.md)

[04 · Deliverability](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/04%20%C2%B7%20Deliverability%2026161a134ea182e081c781d62f3fe915.md)

[05 · ICP and Signals](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/05%20%C2%B7%20ICP%20and%20Signals%205a161a134ea183c4b05f81b6c9136ec0.md)

[06 · Building the List](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/06%20%C2%B7%20Building%20the%20List%20baa61a134ea182f5969a818c8b0ad4b1.md)

[07 · Offer and Lead Magnet](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/07%20%C2%B7%20Offer%20and%20Lead%20Magnet%20def61a134ea1826989cb81369073bdbb.md)

[08 · Campaign Architecture](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/08%20%C2%B7%20Campaign%20Architecture%2016761a134ea183d5bad00117ab4d1ae5.md)

[09 · Copy](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/09%20%C2%B7%20Copy%2040861a134ea183568a1d010e8eb21736.md)

[10 · Launch, Operate, Diagnose](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/10%20%C2%B7%20Launch,%20Operate,%20Diagnose%2096561a134ea182dba81001eca4f5ad4a.md)

[11 · Replies to Booked Meetings](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/11%20%C2%B7%20Replies%20to%20Booked%20Meetings%20d2261a134ea182fc9a6801299e1fe472.md)

[A2 · Running the Engagement](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/A2%20%C2%B7%20Running%20the%20Engagement%20e4161a134ea183f0bcc481fbc0f15e9c.md)

[12 · Beyond the Inbox](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/12%20%C2%B7%20Beyond%20the%20Inbox%20b9661a134ea182a4953801274a94aed3.md)

[13 · Tech Stack and Costs](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/13%20%C2%B7%20Tech%20Stack%20and%20Costs%20c7e61a134ea18260a32d01d2dad72212.md)

[14 · Case Studies](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/14%20%C2%B7%20Case%20Studies%204a561a134ea18316a83581ebb4319032.md)

[15 · Reference](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/15%20%C2%B7%20Reference%20a2b61a134ea183e8b1d5016bb26c979e.md)

[16 · Webinar Hub](The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business/16%20%C2%B7%20Webinar%20Hub%209c561a134ea183868fdf8155ec82fd12.md)

## ⚡ Shorter Paths

<aside>
⚡

**If you have an hour**

A1.2 Size the market before you sell, then 6.4 The four contact buckets, then A2.6 The handoff conversation.

Those three are where local engagements are won and lost, and each is something a competent agency gets wrong on its first local client.

</aside>

<aside>
🔧

**If a client campaign is running badly**

10.3 The numbers to watch, then 10.4 The four-pillar diagnostic, then 06 if the problem is upstream in the data.

On local it is the list about three times out of four.

</aside>

---

<aside>
🔑

### The Data Layer This Guide Runs On

LocalPipe gives you verified contacts for direct local business owners, not addresses scraped off a website. Under 5% of local businesses sit in the standard B2B databases, which is why the usual stack underperforms here.

- 👤 **75%** owner name find rate
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- 📞 Owner phone returned alongside the email
- ✅ **Triple verified**, with **sub 1% bounce** on raw exports
- 💸 Pay on find, so empty records cost you nothing

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>