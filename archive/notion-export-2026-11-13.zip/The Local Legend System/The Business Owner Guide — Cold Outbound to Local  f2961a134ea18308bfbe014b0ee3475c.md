# The Business Owner Guide — Cold Outbound to Local Business ICPs

<aside>
🏪

**For business owners who want a predictable flow of qualified meetings with local businesses, built in-house.**

Plumbers, dentists, landscapers, restaurants, cleaners, clinics, contractors, salons, gyms, garages. Businesses with a physical location, an owner who answers their own phone, and almost no presence in the databases everyone else is buying from.

Everything here is written for selling to that ICP. Nothing about managing clients, because you don't have any. The meetings land on your own calendar.

</aside>

## One Question Before You Start

You are selling to local businesses either way. What changes is whether **you** have to be local too.

<aside>
🏠

**Selling in your own area** · the default

You service what you can drive to. Commercial cleaning to restaurants. A landscaper to property managers. An HVAC company to dental offices.

One metro, a hard market ceiling, and proximity is your best proof.

</aside>

<aside>
🌐

**Selling to local businesses from anywhere** · the exception

Your customers are local businesses but you aren't constrained. Software for trades. Coaching for contractors. A lender to small business owners.

No territory limit, effectively unbounded market, and you need volume proof instead of proximity.

</aside>

**This guide is written for the first one by default.** Where the second changes the answer, the page says so in place with a marker, rather than leaving you to work it out.

<aside>
🔀

**The markers**

**Both motions.** The rule holds either way. Most of the guide.

**L→L only.** True because you have to service the work locally.

**B→L differs.** The rule changes if you sell everywhere, and the page says how.

</aside>

---

## Where to Start

1. **Read 00 · Start Here.** Ten minutes. Pick your motion and your tier.
2. **Then B1 · Before You Start**, which tells you what this costs in money and hours before you spend either.
3. **Order your infrastructure on day one.** It warms for two to three weeks whether or not you're ready. See section 04.
4. **Then work the loop.** Who you're emailing decides what you pitch, which decides your copy, which decides what data you go and find. The list comes last on purpose.

Never run cold outbound before? Section 01 covers the fundamentals. Read it before anything tactical.

---

## Benchmarks at a Glance

Every figure is qualified on its own page. These are the reference ranges for a well-built local list.

| Measure | Range | Note |
| --- | --- | --- |
| **Bounce rate** | Under 2% | The single bar for this guide. 2–3% investigate the list, 5% pause, 10% stop everything |
| Bounce, free-provider segment | About 1.6% | Roughly 32% higher than the rest. Workable in isolation, ugly mixed into the main program |
| Owner name find rate | About 75% | Depends entirely on how many sources you cross-reference |
| Owner direct email find rate | About 42% | The number to size a market on |
| Combined contactable coverage | About 60% | Counts records giving a generic address but no owner-specific one |
| Owner phone find rate | About 20% | Low, and disproportionately valuable |
| Reply rate | Roughly 3–4% | Tracks deliverability more than data quality |
| Leads contacted per positive reply | 1 per 50–100 | The primary efficiency number. Better than 1-in-50 means you have something |
| Monthly sends | Roughly 2,000–4,000 | Constrained by market size, not by infrastructure |
| Qualified meetings per month | Roughly 8–12 | At the volume above, in a healthy market |

---

## The Guide, in Reading Order

[00 · Start Here](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/00%20%C2%B7%20Start%20Here%202aa61a134ea183ffbcb28124d9c25d54.md)

[B1 · Before You Start](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/B1%20%C2%B7%20Before%20You%20Start%2075b61a134ea183f5a11f01227052ba23.md)

[01 · Foundations](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/01%20%C2%B7%20Foundations%20e4f61a134ea1820d873e01c86b3d38e3.md)

[02 · The Two Motions](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/02%20%C2%B7%20The%20Two%20Motions%2082161a134ea18312b195012ef4f09f0f.md)

[03 · Scale](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/03%20%C2%B7%20Scale%20a7861a134ea182e6940d015247395b45.md)

[04 · Deliverability](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/04%20%C2%B7%20Deliverability%203d061a134ea18219a7f701fc750226c9.md)

[05 · ICP and Signals](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/05%20%C2%B7%20ICP%20and%20Signals%202c161a134ea1837ba5cd813877e8c994.md)

[06 · Building the List](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/06%20%C2%B7%20Building%20the%20List%208df61a134ea182b8a48101aace567098.md)

[07 · Offer and Lead Magnet](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/07%20%C2%B7%20Offer%20and%20Lead%20Magnet%2041761a134ea182ffb9c1018ddd08deca.md)

[08 · Campaign Architecture](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/08%20%C2%B7%20Campaign%20Architecture%2080961a134ea182f8bb3781d978dee5fe.md)

[09 · Copy](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/09%20%C2%B7%20Copy%20fbe61a134ea18248a6cb815071e4014c.md)

[10 · Launch, Operate, Diagnose](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/10%20%C2%B7%20Launch,%20Operate,%20Diagnose%20e2061a134ea183848b2801116fbba8b0.md)

[11 · Replies to Booked Meetings](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/11%20%C2%B7%20Replies%20to%20Booked%20Meetings%201de61a134ea182a9829881f4f9d162ba.md)

---

[B2 · Running It In-House](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/B2%20%C2%B7%20Running%20It%20In-House%203a961a134ea182929fa70177c581c8e4.md)

[12 · Beyond the Inbox](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/12%20%C2%B7%20Beyond%20the%20Inbox%20ecc61a134ea1829dabdb015177ef0806.md)

[13 · Tech Stack and Costs](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/13%20%C2%B7%20Tech%20Stack%20and%20Costs%205d761a134ea182ebb9c90117f192e548.md)

[14 · Case Studies](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/14%20%C2%B7%20Case%20Studies%20db361a134ea183bfbb7381ee6553df1a.md)

[15 · Reference](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/15%20%C2%B7%20Reference%2044161a134ea183bbb16c81458e76510b.md)

[16 · Webinar Hub](The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20/16%20%C2%B7%20Webinar%20Hub%20c6261a134ea182f2aae201879133b6df.md)

## Shorter Paths

<aside>
⚡

**If you have an hour**

02 · The Two Motions, then 6.4 The four contact buckets, then 11 · Replies to Booked Meetings.

Those three carry the differences that change results most, and each is something competent people get wrong on their first local campaign.

</aside>

<aside>
🔧

**If something is already running badly**

10.3 The numbers to watch, then 10.4 The four-pillar diagnostic, then 06 if the problem turns out to be upstream in the data.

On local it is the list about three times out of four. Resist rewriting copy first.

</aside>

---

<aside>
🔑

**If you're building this in-house**

### Building This In-House?

LocalPipe is the database this guide runs on. Verified contacts for direct local business owners, not the addresses scraped off a website.

- 👤 **75%** owner name find rate
- ✉️ **60%** combined email coverage
- ✅ Sub 1% bounce on verified exports

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

<aside>
📅

### Want Someone to Build It for You?

Book a call and the Legacy GTM team will:

- 🎯 **Build you a free campaign**, not a pitch deck
- 📈 Show you how to get **15 to 30 qualified booked meetings a month** with local businesses
- 🛠️ Run the whole system so you never touch the software

**You keep the strategy either way, whether you work with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>