# 3.4 What It Costs, and the Calculator

<aside>
💷

**Cold outbound is cheap in money and expensive in attention.**

The monthly bill surprises people by being small. The time cost surprises them by being real. Both matter, and only one of them shows up on a card statement.

</aside>

## 🧾 What You Are Actually Paying For

Five lines, and only two of them scale with volume.

- 🌐 **Domains.** A handful of lookalike domains, renewed yearly. Small enough to round to zero monthly
- 📬 **Inboxes.** Priced per mailbox per month. This is one of the two that scales
- ⚙️ **Sequencer.** A flat monthly platform fee at the volumes in this guide
- 🗃️ **Data and enrichment.** Usually priced per successful find. The other one that scales
- ✅ **Verification.** Per address checked, and cheap relative to what it saves you

What you do not need on day one: a CRM you do not already have, a dialler, an AI SDR, or anything sold as an all-in-one. Section 13.1 has the buy order and what to skip.

## 📐 Sizing the Infrastructure From Your Volume

Work from the send number, not the contact number.

Our cleaning company needs **1,300 contacts a month**. On a three-email sequence that is **3,900 sends a month**, or roughly **180 sends a working day** across 22 sending days.

At **15 sends per inbox per day**, which is the safe rate for cold sending on Google, that is **12 inboxes**. At **3 inboxes per domain**, that is **4 domains**.

That is the whole estate. Local programs at sensible volumes need far less infrastructure than people expect, which is why the monthly bill is usually the least interesting part of this page.

Those three numbers, 22 sending days, 15 sends per inbox and 3 inboxes per domain, are already set as defaults in the calculator. Section 4.3 explains where they come from and when they change.

<aside>
⚠️

**One thing that changes the bill.** The free-provider segment runs on its own estate, with domains parked before use and two batches rotating so neither is ever pushed hard. It gets its own tab in the calculator and its own page in 4.6. Do not fold it into your main estimate.

</aside>

## 💸 Turning It Into Cost Per Outcome

This is the only cost number that means anything. Take your monthly spend and walk it down the funnel from 3.1.

Using the same example, and rough rates:

- **1,300 contacts** a month
- → **17 positive replies** at one per 75
- → **8 meetings booked** at half of positives
- → **6 held** at a 75% show rate
- → **3 qualified**
- → **1 new customer** at a 30% close rate

One customer a month, at an $18,000 annual contract value.

Now divide your monthly spend by each stage. Whatever your actual bill is, you get a cost per positive reply, per booked meeting, and per customer. Those three numbers are what you compare against every other channel you run.

## ⚖️ The Test That Matters

> **Is your cost per customer a small fraction of what a customer is worth?**
> 

For most local businesses running sensible volume, hard costs land at a few hundred a month and produce something in the region of one new customer. If the contract is worth thousands, the maths is not close and you should stop worrying about tool pricing.

Where it gets tight:

- 💵 **Low deal value with no repeat business.** A one-off job worth a couple of hundred rarely survives once you add the time
- 🐌 **Long cycles with low close rates.** You pay for twelve months before you learn anything
- 🧊 **Bad fit dressed up as a cost problem.** If cost per customer looks terrible, it is usually the funnel, not the tools. Section 10.4

## ⏰ The Cost Nobody Budgets

The hard costs are small. Your time is not.

- 🏗️ **Setup.** Most of a working week across the first fifteen days. Section 0.5
- 🔁 **Operating.** Fifteen minutes a day once it is live
- 📞 **Replies.** This is the real one. Seventeen positive replies a month, each needing a phone call inside the hour, is not fifteen minutes a day

That last line is the whole reason A2.6 exists. The program does not fail because the tools cost too much. It fails because nobody had an hour free at 2pm on a Tuesday when the reply came in.

Price your own time into the model. If the answer is that you cannot afford the hours, that is a real finding, and hiring or outsourcing is a legitimate response to it rather than an admission of anything.

## 🧮 The Calculator Does All of This

Rather than doing any of the above by hand, the money model calculator runs the whole chain. Four tabs, in the order you use them:

1. 💰 **Money Model.** The backward maths from 3.2, across up to three tiers at once. Enter your goal, your ACV and your conversion rates, and it returns contacts to reach and emails to send
2. 🗺️ **Local Market Sizing.** The four cuts from 3.3. Enter what your sourcing returned and it gives you usable verified contacts, months of volume, and a verdict on whether the market holds your plan
3. 📮 **Infra Calculator.** Enter your monthly send volume and it returns inboxes, domains and total monthly cost
4. 🔓 **Infra Calc, Free Provider.** The separate lane for personal-provider addresses, costed on its own because it behaves nothing like the rest

Run them in that order. The Money Model feeds the sizing check, and the sizing check tells you whether to carry on before you spend an hour on infrastructure numbers.

<aside>
📊

### Open the Calculator

All four tabs, live and ready to copy.

[**👉 The Local Legend Money Model**](https://docs.google.com/spreadsheets/d/1SCPMYKU4_lguC11AGqwnlqoJSqLd-lsJhnt4iEeTpTQ/edit?gid=1669046753#gid=1669046753)

File > Make a copy, then edit the blue cells. Black cells are formulas, so leave them alone.

</aside>

## 📬 You Will Hit Deliverability Questions. Skip Them for Now

The infrastructure tabs ask for things this section has not taught you yet: a Google, Microsoft and Azure split, inboxes per domain, sends per inbox per day, cheap against premium domains, sending days per month, and a cycling multiplier on the free-provider tab.

**Leave every one of them alone.** The defaults are already set correctly for a local program. Google at 100%, three inboxes per domain, fifteen sends per inbox per day, twenty-two sending days.

The only number you need out of this page is the monthly cost. Everything behind those inputs is section 04's job:

| What the calculator asks for | Where it is explained |
| --- | --- |
| The Google, Microsoft and Azure split | **4.2** Provider lanes. Short version: Google is right for local, because tier one owners are overwhelmingly on consumer and small-business providers |
| Inboxes per domain, and cheap against premium domains | **4.2** Domains, inboxes and DNS. Lookalike domains, registrars, and why cheap means paying twice |
| Sends per inbox per day | **4.4** Warm-up and ramp. Fifteen is the steady-state figure, and you do not start there |
| Why the free-provider lane has its own tab and its own cycling multiplier | **4.6** The free-provider lane. On a local list a gmail address is usually the owner, not bad data |
| What happens if the estimate is wrong | **4.5** and **4.7**. The 2% bounce bar, and what to watch once you are live |

Come back and revise the numbers after section 04 if your situation turns out to need a different mix. For most local programs it will not.

## ✅ Before You Move On

You should now be able to answer:

- What your monthly hard cost will be at your target volume
- How many inboxes and domains that volume needs
- Your cost per positive reply, per meeting and per customer
- How many hours a month this takes, and whose hours they are
- Whether that is comfortably less than a customer is worth

If the last one is a no, go back to 2.4 rather than forward to section 04.

---

<aside>
➡️

**Next:** [04 · Deliverability](../04%20%C2%B7%20Deliverability%2026161a134ea182e081c781d62f3fe915.md)

Domains, warm-up, the 2% bar, and the one problem unique to local lists.

</aside>