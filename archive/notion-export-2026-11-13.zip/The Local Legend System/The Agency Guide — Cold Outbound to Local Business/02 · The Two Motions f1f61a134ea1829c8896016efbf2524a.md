# 02 · The Two Motions

<aside>
🔀

**What this section does.** The fork everything else hangs off. Both motions sell to the same ICP and build lists the same way. Everything after the list differs, and this section names every difference in one place so later pages can refer back.

</aside>

**Applies to:** Both. This is the reference page for every marker in the guide.

<aside>
🏢

**Ask this per client, not once for your agency.** Every new local client is either selling inside their own area or selling to local businesses from anywhere, and it changes the geography strategy, the proof that works and what you can promise on volume. It belongs on the intake form. A2.1.

</aside>

## Chapters

1. **2.1 Local → Local.** The default case, defined, with five worked examples
2. **2.2 Business → Local.** The marked exception, defined, with six worked examples
3. **2.3 Where the Rules Diverge.** The master table: geography, market ceiling, proof, awareness, offer shape, who works the reply, suppression, channel mix
4. **2.4 When Local Outbound Is the Wrong Call.** Disqualification criteria, and the questions to ask before you sign---

[2.1 Local → Local](02%20%C2%B7%20The%20Two%20Motions/2%201%20Local%20%E2%86%92%20Local%2014061a134ea182fda0930107ff8f6e26.md)

[2.2 Business → Local](02%20%C2%B7%20The%20Two%20Motions/2%202%20Business%20%E2%86%92%20Local%20df761a134ea1820d951381b860888357.md)

[2.3 Where the Rules Diverge](02%20%C2%B7%20The%20Two%20Motions/2%203%20Where%20the%20Rules%20Diverge%205b461a134ea1829295f881c6a9824cb7.md)

[2.4 When Local Outbound Is the Wrong Call](02%20%C2%B7%20The%20Two%20Motions/2%204%20When%20Local%20Outbound%20Is%20the%20Wrong%20Call%2052d61a134ea1822b8526816047496be3.md)

---

<aside>
➡️

**Next section:** [A1 · Winning the Client](A1%20%C2%B7%20Winning%20the%20Client%2010e61a134ea1826c8c9681cee86cac25.md)

Positioning, sizing the market before you quote, and scoping.

</aside>