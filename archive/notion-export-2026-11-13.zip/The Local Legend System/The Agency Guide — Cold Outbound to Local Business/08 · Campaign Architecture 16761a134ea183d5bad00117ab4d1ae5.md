# 08 · Campaign Architecture

<aside>
🗂️

**What this section does.** Turns one ICP and one offer into a set of campaigns that compounds. Then confronts the problem nobody writing general outbound material has to: the standard testing protocol needs more contacts than a local market contains.

</aside>

**Applies to:** Both motions for structure. **L→L clients only** for the testing constraint, which is the whole of 8.3. A **B→L client** can run the standard protocol unchanged.

<aside>
🏢

**8.3 is where your book of clients becomes an advantage.** A single local market is too small to test properly in. Three clients in the same trade is a readable sample, and that is the one structural edge you have over a business running this in-house.

</aside>

## Chapters

1. **8.1 What a Campaign Actually Is.** One segment, one offer, one person, one angle, and why blending destroys the data
2. **8.2 The Local Playbooks.** Which standard playbooks survive local, which die, and what replaces them
3. **8.3 Testing Inside a Finite Market.** The volume rule against the coverage maths, and three honest ways out

---

[8.1 What a Campaign Actually Is](08%20%C2%B7%20Campaign%20Architecture/8%201%20What%20a%20Campaign%20Actually%20Is%2022c61a134ea18376a47881e9a4c5cda3.md)

[8.2 The Local Playbooks](08%20%C2%B7%20Campaign%20Architecture/8%202%20The%20Local%20Playbooks%20c3e61a134ea18370bbc881a5d0627cbe.md)

[8.3 Testing Inside a Finite Market](08%20%C2%B7%20Campaign%20Architecture/8%203%20Testing%20Inside%20a%20Finite%20Market%202d861a134ea1827a99e8811592620c5b.md)

---

<aside>
➡️

**Next section:** [09 · Copy](09%20%C2%B7%20Copy%2040861a134ea183568a1d010e8eb21736.md)

Writing to somebody who reads their own inbox between jobs.

</aside>