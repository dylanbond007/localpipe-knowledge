# 15.1 Glossary

<aside>
📖

**Terms used precisely throughout this guide.**

Several of these mean something narrower here than they do elsewhere, which is usually the point.

</aside>

## 🗂️ The Data Layer

**Business record.** One business, as returned by sourcing. A name, a category, an address, usually a phone and a website. **It is not a contact.** You cannot email a business record.

**Contact record.** One address you can send to. A single business record commonly produces two or three contact records, which is the whole argument of 6.4.

**Contactable coverage.** The share of sourced businesses that yield at least one usable address of any kind. Around 60% on a well-built process.

**Combined coverage.** Same thing. Used interchangeably, and it counts records that give you a generic address but no owner-specific one.

**Owner direct.** A personal address for the owner, on the business domain. `dan@brightcleaning.com`

**Generic inbox.** A role address. `info@`, `contact@`, `hello@`. Read by the owner at this size.

**Free provider address.** An address on gmail, [outlook.com](http://outlook.com), yahoo and similar. On a local record this usually means the owner personally. Bucket four.

**Usable sends.** Contact records after verification, which is the number to size a program on. Not business count.

**Title waterfalling.** Searching a priority-ordered list of job titles and taking the first match, for offers that do not sell to the owner.

## 🎯 Targeting

**ICP.** The kind of business worth selling to. A company-level definition.

**Buyer persona.** The person inside it who reads your email. On local this is usually the owner, so the two often collapse into one.

**Anti-ICP.** The businesses you deliberately exclude, derived from your worst customers. A filter, not a preference.

**Tier.** The size band of local business. Tier one is owner-operators and small SMBs, tier two is franchises and multi-location groups, tier three is enterprise-local. Section 0.3.

**Motion.** Whether you are a local business selling locally, or a business selling to local businesses from anywhere. Section 0.2.

**Signal or trigger.** A specific, recent, observable event that makes a business more buyable today than yesterday. Section 5.4.

**Ocean state.** How saturated your category is. Red means everybody is pitching this, blue means almost nobody is.

## 📊 Performance

**Reply rate.** The share of contacted people who reply at all, positive or negative. Tracks deliverability more than data quality.

**Positive reply rate.** The share of replies that are interested. This is the one that reflects message-market fit.

**Interested rate.** Positive replies as a share of everybody contacted. The cleanest single measure of whether a campaign works.

**Contacts per positive reply.** How many people you contact to get one positive reply. Benchmark 1 in 50 to 100. **The single most useful number in this guide.**

**Lead to appointment.** The share of positive replies that become booked meetings. On local this is mostly a measure of response speed.

**Show rate.** Booked meetings that actually happen. 70 to 80% with a working pre-call process.

**Opportunity.** A qualified conversation with somebody who could realistically buy. Defined by you, and the number worth reporting.

**Market exhaustion.** The point at which you have contacted everybody in your sourced market once. On a single metro vertical this arrives in six to eight months.

## 📬 Deliverability

**Sending domain.** A lookalike domain used only for outbound. Never your company domain.

**Warm-up.** Building mailbox reputation by sending and receiving mail within a controlled pool before any real sending. Two to three weeks.

**Ramp.** Gradually increasing cold volume after warm-up. A separate thing from warm-up, and the one people skip.

**Placement.** Whether mail lands in the primary inbox, promotions, or spam. Invisible unless you test it deliberately.

**Bounce rate.** Sends that fail. **Under 2% is the bar throughout this guide.**

**Spam complaint rate.** The share of recipients marking you as spam. 0.3%, or three per thousand, is where real damage starts.

**Suppression.** The permanent list of people who must never be contacted. Customers, unsubscribes, open deals, recent contacts.

**Rotation.** Running two batches of infrastructure, one sending while the other rests and re-warms. Section 4.6.

## ✍️ Campaigns and Copy

**Campaign.** One segment, one offer, one persona, one angle, sent at enough volume to mean something. Section 8.1.

**Evergreen campaign.** The broad, always-on list. Sets your volume floor.

**Signal campaign.** A smaller list built on a trigger. Converts better, runs as a trickle.

**Angle.** The reason you are writing today. What a campaign is actually built on.

**Core offer.** What you sell.

**Lead magnet.** The free thing that earns you the meeting. A different job from the core offer.

**Merge field.** A variable in your copy filled from the record. Every one needs fallback text.

**Fallback copy.** What renders when a merge field is empty. Not optional on local.

**Spintax.** Phrasing variations across sends, so thousands of identical emails do not get fingerprinted.

---

<aside>
➡️

**Next:** [15.2 Benchmarks With Confidence](15%202%20Benchmarks%20With%20Confidence%20e9a61a134ea183308d6b01f420ac3525.md)

Every figure in this guide, and how much weight it carries.

</aside>