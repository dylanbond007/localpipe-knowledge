# 15.2 Benchmarks With Confidence

<aside>
🔬

**Every number in this guide, and how much weight it can carry.**

This page exists so you can tell which figures to plan against and which to treat as directional. Nothing here is audited, and where a figure comes from somebody with an interest in it, that is stated.

</aside>

## 🏷️ The Three Kinds of Number

| Type | What it means | How much to trust it |
| --- | --- | --- |
| 📊 **Measured at scale** | From LocalPipe's analysis of roughly 7.2 million emails sent to local businesses | High on direction. One company's dataset, not an industry survey |
| 🧪 **Controlled comparison** | Four data providers tested against the same lists, with offer and infrastructure held steady | The cleanest evidence here, and the basis of the find rates |
| 🛠️ **Practitioner figures** | From Legacy GTM running these programs, across 20 million or more cold emails sent | Real, but from our programs. Informed expectations rather than proven averages |

## 📈 Find Rates and Data Quality

| Figure | Value | Type | Caveat |
| --- | --- | --- | --- |
| Owner name find rate | About 75% | 🧪 Controlled | Depends entirely on how many sources are cross-referenced. One source lands far below |
| Owner direct email | About 42% | 🧪 Controlled | Average across verticals. Wide spread by category |
| Combined coverage | About 60% | 🧪 Controlled | Includes generic fallback addresses |
| Owner phone | About 20% | 🧪 Controlled | Low, and the Maps listing number often fills the gap |
| Records returning nothing | About 40% | 🧪 Controlled | No provider fixes this. Plan for it |
| Verification survival | Around half | 🛠️ Practitioner | A conservative planning figure. Good sources keep more |

## 🗺️ Market and Coverage

| Figure | Value | Type |
| --- | --- | --- |
| Local SMBs in major B2B databases | Under 5% | 📊 Measured |
| Home service businesses missing | 80 to 90% | 📊 Measured |
| Maps-derived coverage advantage | 3 to 20x, by vertical | 📊 Measured |
| Positive reply lift on contacts absent from the big databases | About 1.6x | 📊 Measured |
| Pagination depth | About +84% results | 🧪 Controlled |
| Query stacking | About +23% results | 🧪 Controlled |
| ZIP-level splitting in dense verticals | Roughly 2x | 🧪 Controlled |
| Maps category taxonomy | About 4,000 categories | 📊 Fact |

## 📬 Deliverability

| Figure | Value | Type |
| --- | --- | --- |
| Bounce on a well-built local list | Under 2% | 🛠️ Practitioner |
| Bounce lift on free-provider addresses | About 32% higher | 📊 Measured |
| Spam complaint damage threshold | 0.3% | 📊 Industry standard |
| Infrastructure burn without warm-up | 5 to 10x faster | 🛠️ Practitioner |
| Free-provider infrastructure burn | 3 to 5x faster | 🛠️ Practitioner |

## 💬 Campaign Performance

| Figure | Value | Type |
| --- | --- | --- |
| Reply rate on a working local campaign | 3 to 4% | 📊 Measured |
| Contacts per positive reply | 1 in 50 to 100 | 🛠️ Practitioner |
| Positive reply to booked | Around half | 🛠️ Practitioner |
| Show rate with a pre-call process | 70 to 80% | 🛠️ Practitioner |
| No-show recovery | 20 to 30% | 🛠️ Practitioner |
| Monthly sends per program | 2,000 to 4,000 | 🛠️ Practitioner |
| Qualified opportunities per month | 8 to 12 | 🛠️ Practitioner |
| Minimum contacts before a result means anything | 500 to 1,000 | 🛠️ Practitioner |

## ⚠️ Known Conflicts, and How This Guide Resolves Them

Three places where you will find different advice elsewhere.

**Bounce threshold.** General cold email advice often treats 3% as acceptable. This guide uses **2%** throughout, because local data is built rather than bought, so a high bounce rate is almost always something you did and can fix.

**Contacts per business.** Standard practice caps you at around five contacts per company. This guide works two to three contacts per business, because those are multiple routes to the same person rather than multiple people at one account. Section 6.4. **This is the most contested position in the guide and there is no controlled study behind it.**

**Free-provider addresses.** Standard practice deletes them. This guide isolates them, because on a local record they usually reach the owner personally. Section 4.6.

## 🧭 How to Use All of This

- 📐 **Plan against the controlled figures.** The find rates are the most reliable thing here
- 🤔 **Treat practitioner figures as starting assumptions** and replace them with your own by day ninety
- 🚫 **Do not average across verticals.** Plumbers and dental practices behave differently, and a blended number hides a working campaign inside a failing portfolio
- 🔍 **The spread between approaches is wider than the spread between verticals.** A bad process in a good vertical loses to a good process in a hard one

## 📚 Where to Check

- Provider comparison figures and the data-layer numbers: [LocalPipe's published comparison](https://www.localpipe.io/best/local-business-lead-generation-tools)
- Verification stack and sourcing model: [LocalPipe.io feature summary](https://www.saasworthy.com/product/localpipeio)

Both are published by or derived from LocalPipe, who co-authored the list building section of this guide. Their free tier is 400 credits with no card, so run it against your own market rather than taking any of it on trust.

---

<aside>
➡️

**Next:** [15.3 Measurement and Attribution](15%203%20Measurement%20and%20Attribution%207f561a134ea1822a8d1d81b6297cf586.md)

Reporting what actually happened.

</aside>