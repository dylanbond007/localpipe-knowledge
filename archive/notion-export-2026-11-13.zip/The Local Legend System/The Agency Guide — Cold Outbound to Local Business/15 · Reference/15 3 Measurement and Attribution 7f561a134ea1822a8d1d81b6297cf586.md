# 15.3 Measurement and Attribution

<aside>
📐

**Local deals close on the phone, weeks later, with no digital trail.**

Which means the standard attribution approach quietly under-reports outbound, and people switch off channels that were working.

</aside>

## 🎯 Measure Opportunities, Not Activity

Three tiers of number, and only the third one matters to anybody outside the program.

- 🔧 **Activity.** Emails sent, calls made. Useful to you, alarming to everybody else, and not evidence of anything
- 📊 **Leading indicators.** Bounce, reply rate, positive reply share, contacts per positive. What you fix things with
- 💰 **Opportunities.** Qualified conversations with people who could realistically buy. **The number to report**

Define what an opportunity is before you start, in one sentence, and do not change the definition mid-program. If you change it, say so.

## 🕳️ Why Attribution Breaks on Local

Four reasons, and they compound.

- 📞 **The conversation moves to the phone immediately.** Nothing after the reply is tracked by your sequencer
- 🐢 **The deal closes weeks later**, often after a site visit, and by then nobody remembers where it came from
- 🗣️ **They tell somebody else.** A referral that started with your email looks like a referral
- 🏘️ **They might have heard of you anyway.** In a small market you are visible through several routes at once

So the digital trail ends at the reply. Everything of value happens after that, off-platform.

## 🔗 What to Do Instead

Four practical moves, none of which require a tracking stack.

**1. Record the source at the moment of the reply.** Not later. The second somebody replies, log which campaign, which bucket, which angle. That is the last moment the attribution is unambiguous.

**2. Carry an identifier through to the booking.** Whatever your booking tool is, pass the campaign through it. A meeting that arrives with no source attached will be attributed to nothing.

**3. Reconcile on a fixed cadence.** Once a month, take the list of closed business and walk it back against the reply log. Ten minutes, and it catches everything the automation missed.

**4. Ask them.** On the call, at the point they are already talking: "how did this land with you?" People will tell you, and it is more accurate than any system.

## 📅 The Lag Problem

Outbound produces revenue on a delay, and the delay is longer than the reporting cycle.

- Month one: spend, no revenue
- Month two: first meetings, maybe first deals
- Month three: revenue from month two's meetings

**Judging month one on revenue is judging a channel before it has produced anything.** That is why the day forty-five review in A2.1 uses leading indicators.

If you report monthly, show the leading indicators alongside revenue, or somebody will draw a conclusion from a number that cannot yet exist.

## 🧾 What a Monthly Report Should Contain

Short. Five lines.

- 📨 Contacts reached
- 💬 Positive replies, and contacts per positive reply
- 📅 Meetings held
- ✅ Opportunities, using the agreed definition
- 💰 Closed business, where the cycle allows

Plus one sentence on what changed and one on what you are changing next.

**What to leave out:** open rates, emails sent, anything that sounds like activity. It invites the wrong conversation.

## 📉 Open Rates Are Not a Metric Here

Worth saying plainly, because dashboards still show them.

Open tracking adds a redirect that can hurt placement, and the numbers have been unreliable since mail clients started pre-fetching images. This guide tells you to turn it off in 10.2.

You lose nothing. Reply rate is the real leading indicator and it is measured accurately.

## 🔍 Instrument the Handoff

One number that is easy to miss and expensive to ignore.

**Time from reply to first call attempt.** If somebody other than you works the replies, this is the number that tells you whether the system is functioning.

It drifts. Twenty minutes becomes two hours becomes next day, over about six weeks, and nobody notices until the booked rate falls. Measuring it turns a vague complaint into a shared fact. Section 11.4.

## ✅ Before You Move On

- One written definition of an opportunity
- Source recorded at the moment of reply, not later
- A monthly reconciliation against closed business
- Leading indicators reported alongside revenue
- Open tracking off
- Time to first call attempt measured

---

<aside>
➡️

**Next:** [15.4 Compliance](15%204%20Compliance%20a6d61a134ea18215ba1901c35cfe9725.md)

Operational guidance, not legal advice.

</aside>