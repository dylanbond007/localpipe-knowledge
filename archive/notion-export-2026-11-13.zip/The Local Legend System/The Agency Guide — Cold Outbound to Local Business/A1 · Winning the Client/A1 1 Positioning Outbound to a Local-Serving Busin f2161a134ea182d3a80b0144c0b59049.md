# A1.1 Positioning Outbound to a Local-Serving Business

<aside>
🎯

**Assume they have been sold this before, and it did not work.**

Most local businesses of any size have paid somebody for leads, marketing or outbound and got very little back. You are not introducing a category. You are arriving after somebody who disappointed them.

</aside>

## 🔍 What They Have Already Bought

Usually one or more of these, and knowing which changes your whole approach.

- 💸 **Paid ads**, which produced enquiries of mixed quality and stopped the day they stopped paying
- 🔎 **SEO or a directory listing** sold on a twelve-month contract, with results that were never clearly attributable
- 🤖 **A lead-gen service** selling shared leads, meaning the same enquiry went to four competitors
- 📬 **Cold email**, run badly, that produced complaints and nothing else

The fourth one is the most dangerous for you, because it looks identical to what you are proposing from the outside.

## 🗣️ Name It Before They Do

The strongest opening move in this conversation is to raise their scepticism yourself.

> "You have probably paid somebody for leads before and not got much out of it. Most people I speak to have. Here is what was different about that, and here is what I would do instead."
> 

That does three things. It signals you have had this conversation many times, it removes the objection they were saving, and it lets you draw the distinction rather than defending against a comparison they make privately.

## 🧩 What Actually Differentiates You

Not effort, and not care. Everybody claims both.

- 🗺️ **Data nobody else has.** Their competitors are working the same few hundred records from a standard database. You are working the whole market. This is concrete, checkable and genuinely rare
- 🎯 **Exclusivity.** The leads are theirs, not shared with three other firms in the same trade
- 📞 **The follow-up is designed**, not assumed. Most failed programs failed at the reply, not at the send
- 📊 **A stopping rule.** You will tell them at day forty-five whether it is working, on numbers you agree in advance

That last one is worth more than it looks. Somebody who has been burned is not looking for confidence. They are looking for a way out if it goes wrong.

## 💬 How to Talk About the Mechanism

Lead with the outcome, then explain the mechanism only when they ask how.

But when they do ask, be specific, because specificity is the differentiator here. Most agencies cannot explain where their data comes from. You can:

- Where the businesses come from, and why that is different from a standard database
- How an owner name gets resolved, and roughly how often it works
- What happens to the records where it does not
- What happens the moment somebody replies

An owner who understands the mechanism is a much better client, because they stop expecting magic and start engaging with the numbers.

## ⚠️ What Not to Promise

- ❌ **A meeting count in month one.** You do not control it and it is how the engagement gets killed in month three
- ❌ **A conversion rate you have not measured in their market**
- ❌ **Exclusivity in a category you already serve** unless you mean it, and you should mean it
- ❌ **Anything about their close rate.** You produce meetings. What happens on the call is theirs

Promise the process, the timeline and the decision point. Section A1.2 gives you the numbers to back it.

## ✅ Before You Move On

- An opening that names their scepticism before they do
- A specific, checkable answer to why your data is different
- A stopping rule you propose yourself
- Nothing promised that you do not control

---

<aside>
➡️

**Next:** [A1.2 Size the Market Before You Sell the Retainer](A1%202%20Size%20the%20Market%20Before%20You%20Sell%20the%20Retainer%204c061a134ea18262a95a010439fefe48.md)

The feasibility check, and what to do when the answer is no.

</aside>