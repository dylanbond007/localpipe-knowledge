# A1.3 Scoping So You Do Not Inherit Unfixable Problems

<aside>
🔎

**Some engagements are lost before they start.**

Not because the market is wrong or the offer is weak, but because something structural on the client's side makes success impossible. These are the questions that surface it while you can still walk away.

</aside>

## ☎️ Question One: Who Calls Back, and How Fast?

**The single most important question in this conversation**, and almost nobody asks it during a sales process.

On local, a positive reply is a cue to dial and the window closes within the hour. If the answer is "the owner, when he gets off site", you are about to generate expensive intent that goes cold, and they will experience that as poor lead quality.

Ask for a name. Not a team, not a process. A name.

If there is no credible answer, you have three options, and they are all better than proceeding as if there is:

- 👥 **Sell the calling as part of the engagement.** A setter, yours or theirs
- 📉 **Cap the volume** to what the available attention can convert, and say so
- 🚫 **Decline.** Manufacturing intent that dies is worse for your reputation than not taking the work

## 🎯 Question Two: Has This Offer Ever Closed?

Outbound amplifies. It does not discover.

If they have never sold this thing to this kind of customer at this price, you are not running a campaign, you are running a product test with their money and your reputation attached.

That can be a legitimate engagement. It just has to be named as one, with different expectations and a different timeline.

## 🗺️ Question Three: Can They Service What You Win?

Specific to local, and routinely missed.

- Can they take on the volume of work the goal implies, with the crew they have?
- Is there a geography beyond which a won contract loses money?
- Are there categories they cannot legally or practically serve?

Winning work a client cannot deliver is worse than winning nothing. It damages them and it comes back to you.

**Turn the answers into list filters**, not into caveats in a proposal.

## 🔥 Question Four: Have They Burned This Market Already?

Ask directly whether they have run cold outreach into this exact market before, and when.

If they blasted the same metro six months ago with a bad campaign, you are not starting from zero. You are starting from negative, and the first thing you need is a different angle, a different sender identity and possibly a wait.

This is very hard to find out after you have started, and very easy to ask.

## 📊 Question Five: What Do They Consider a Good Month?

Get it in numbers before you quote.

The gap between what they imagine and what the maths supports is the source of almost every unhappy engagement. Surfacing it in the sales conversation is uncomfortable once. Surfacing it in month four is expensive forever.

## 🚩 The Disqualifiers

Walk away, or restructure, if:

- 🔴 Nobody can work replies inside a workable window and nothing will change
- 🔴 The market holds under three months of volume
- 🔴 The offer has never closed and they are not willing to call it a test
- 🔴 They want a meeting guarantee in month one
- 🔴 They cannot service the work the goal implies
- 🔴 They burned the same market recently and will not change the angle

## 🧾 What Goes in the Agreement

From the answers above, four things belong in writing before anybody signs.

- 👤 **The named person** who works replies, and the response window
- 🗺️ **The serviceable geography**, as a filter
- 📅 **The review date** and the leading indicators it will be judged on
- 📈 **The expansion path**, so month five is not a surprise

None of that is legal protection. It is a shared understanding, which is what actually prevents the argument.

## ✅ Before You Move On

- A named person for replies, with a window
- Confirmation the offer has closed before
- Service capacity and geography turned into filters
- An honest answer on whether the market has been burned
- Their definition of a good month, in numbers

---

<aside>
➡️

**Next:** [03 · Scale](../03%20%C2%B7%20Scale%20fb961a134ea182f5ac4b8136dfa130fa.md)

The money model, and how to tell whether a client's market can support the number they have in mind.

</aside>