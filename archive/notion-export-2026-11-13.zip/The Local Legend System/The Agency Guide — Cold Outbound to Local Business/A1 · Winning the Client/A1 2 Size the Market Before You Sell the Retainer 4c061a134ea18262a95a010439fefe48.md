# A1.2 Size the Market Before You Sell the Retainer

<aside>
🧮

**The most expensive mistake in this niche is selling a retainer into a market that cannot support it.**

It takes an hour to check. Skipping that hour is how you end up four months in with a client who is unhappy and correct.

</aside>

## ⚠️ Why This Is Worse on Local Than Anywhere Else

In corporate outbound, a market that comes back thin is an inconvenience. You widen the filters, move to an adjacent segment, and carry on.

A local market is finite and countable. There are only so many dental practices within forty minutes of their yard. If the number does not support the volume you need, no amount of execution fixes it, and you will have signed a twelve-month retainer against it.

## 🔢 Run It Before You Quote

Same method as section 03, done in the sales process rather than after it.

1. 🏷️ **Agree the category set and the geography** with them, on the call. This is a good conversation to have anyway, because it surfaces how they actually think about their market
2. 🗺️ **Source it properly.** Decomposed, paginated, stacked. Not one query
3. ✂️ **Apply the four cuts.** Hygiene, contactable coverage, bucket expansion, verification
4. 📅 **Divide by the monthly volume** their goal requires

You now know how many months of first-touch volume exist. That is the single most useful number in the entire sales conversation.

## 🚦 What the Answer Means

| Months of volume | What to do |
| --- | --- |
| 🟢 **12+ months** | Comfortable. Sell the retainer |
| 🟡 **6 to 12 months** | Workable, and say so out loud. Plan the expansion path into the proposal from day one |
| 🟠 **3 to 6 months** | Short engagement or a project, not an open-ended retainer. Be explicit that the market has a floor |
| 🔴 **Under 3 months** | Do not sell it. Tell them why |

## 🎁 Telling Them No Is a Sales Asset

Counterintuitive and true.

An agency that runs the numbers and says "your market will not support what you are asking for, here is what it will support" is doing something no competitor of theirs has ever done. It is the single most credible thing you can do in a first conversation.

Two outcomes, and both are good:

- They buy the smaller, honest version, which you can actually deliver
- They do not buy, and they remember you as the one who told the truth. Local markets are small and that comes back

## 🔍 Expand Before You Decline

When it comes back short, work the expansion order with them on the call. Section 3.3.

- 📬 **Contact buckets first.** Free, already sourced, roughly doubles usable contacts
- 🏷️ **Adjacent categories.** Who else has the same problem? Usually the biggest unlock and it costs nothing
- 🗺️ **Geography.** Check it against what they can actually service
- 🎚️ **Loosen qualification.** Works, lowers conversion, do it knowingly

Doing this live is also a demonstration. They watch you solve their problem with a method rather than a promise.

## 📄 Put the Number in the Proposal

Not buried. On the first page.

> Your market contains roughly **X** verified contactable businesses in the categories and geography we agreed. At the volume required to hit your goal, that is about **Y** months of first-touch coverage, after which we expand into [named categories] or pause.
> 

That paragraph prevents the month-five conversation where they think you have run out of ideas and you think they never understood the constraint.

## ✅ Before You Move On

- The market sized before the proposal, not after signature
- The months-of-volume figure agreed with them
- An expansion path named in writing
- A willingness to decline, and a smaller version to offer instead

---

<aside>
➡️

**Next:** [A1.3 Scoping So You Do Not Inherit Unfixable Problems](A1%203%20Scoping%20So%20You%20Do%20Not%20Inherit%20Unfixable%20Probl%2004b61a134ea183bb9e3181828a12629d.md)

The five questions to ask before you sign.

</aside>