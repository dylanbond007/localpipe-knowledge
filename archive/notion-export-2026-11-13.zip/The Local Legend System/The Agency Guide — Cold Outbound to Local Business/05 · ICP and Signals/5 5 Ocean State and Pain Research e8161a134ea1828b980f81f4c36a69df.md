# 5.5 Ocean State and Pain Research

<aside>
🌊

**How crowded is the category you are selling into?**

That answer decides how hard your offer and copy have to work. Get it wrong and you either overbuild a message nobody needed, or send a plain one into a market that has heard it a hundred times.

</aside>

## 🎯 First, Niche at the Campaign Level

Two different decisions, and only one of them is urgent.

**Campaign-level niching is mandatory.** Every campaign targets one segment and one persona. Never blend a two-van operator with a twelve-location group in the same send. The message dilutes and the data becomes unreadable, so you cannot tell which part worked.

**Brand-level niching is optional**, and eventually right. Once you have the case studies to own one category, owning it beats being available to everyone.

The usual correct move: **niche at the campaign level from day one, niche at the brand level once you have the proof.**

## ⏳ The Hourglass

Most businesses follow the same shape across their life:

- 🔍 **Early.** Experiment broadly to find a niche you can win
- 🚀 **Growth.** Go all in where the experiments worked. This is where revenue compounds
- 🌱 **Scale.** Expand into adjacent niches once you have dominated the first

If you are early, the mistake is staying broad because it feels safer. Pick a niche, prove it, then expand.

## 🌊 Red Ocean or Blue Ocean

<aside>
🔴

**Red ocean**

Your prospects get cold emails about this every week. Competitors two or three times your size do roughly what you do.

Generic value props die here. You need a creative offer, a specific mechanism, sharp differentiation and strong risk reversal.

</aside>

<aside>
🔵

**Blue ocean**

Few competitors emailing them. The problem is real and largely unsolved.

Direct wins. Three-sentence emails, a plain "we do X for Y without Z", and fast conversion because you are often the first person to raise it.

</aside>

The difference is not subtle. In a genuine blue ocean, complexity actively hurts. A creative mechanism that would be essential in a red ocean just gets in the way when you are the first person to mention the problem at all.

## 🔍 Three Checks to Find Out

You can answer this in twenty minutes.

- 📧 **Ask five prospects how many pitches like yours they get.** Cold call five businesses in your target category and ask directly. They will tell you, usually with feeling
- 🔎 **Search your category and area as a buyer would.** Count how many competitors are bidding on it and how polished their positioning is
- 🗣️ **Read their reviews and their complaints.** If people are complaining about the problem you solve and nobody is named as solving it, that is a blue ocean

## 🪸 The Local Twist

Here is the thing that is specific to this market, and it cuts in your favour.

**Saturation on local is as much a data question as a market question.**

The small pool of local businesses that appear in the standard databases is the same pool every competitor finds, exports and sequences. Those particular businesses are in a deep red ocean. They get four cold emails a week and they have learned to ignore all of them.

The same category, sourced properly from scratch, is a different market. Those businesses get four cold emails a *year*, and a plain, direct message still works on them.

So two operators can sell the identical thing into the identical category and be in completely different oceans, purely because of where the list came from.

---

<aside>
🔑

### The Oceans Are Made of Data

The businesses everyone else is emailing are the ones sitting in the standard databases. The rest of the market has barely been touched.

LocalPipe is the local business database this guide runs on:

- 🗺️ Sourced from Maps rather than LinkedIn, so you reach businesses your competitors cannot find
- 👤 **75%** owner name find rate
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- ✅ **Triple verified**, with **sub 1% bounce** on raw exports

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

---

## 🩺 Pain Research: Six Questions

Before anybody writes a word of copy, answer these for your ICP. Not what your product does. What they wake up worried about.

1. ❓ **What pain do they actually face?** In their words, not yours
2. 🩹 **What are they doing about it now?** A workaround, a competitor, or just living with it
3. 💸 **What is it costing them?** Money, hours, risk, work they are losing
4. 🔧 **Why is their current fix broken**, and worse than yours
5. 🎯 **What do they want instead?** The end state they picture if it went away
6. 🏆 **What emotional and logical win can you deliver** better than anyone else

Answer these and the offer and the copy practically write themselves. Skip them and you will write generic copy, because you do not actually know what this person cares about.

## ⚡ How to Research It Fast

Especially for a trade you have never sold into.

- 💬 **Their forums and groups.** Trade subreddits and Facebook groups are where owners complain honestly to each other
- ⭐ **Reviews of their competitors.** One-star reviews tell you what goes wrong in that trade. Five-star reviews tell you what they are proud of
- 🎧 **Trade podcasts and publications.** Every trade has them, and the recurring topics are the recurring problems
- 📞 **Five real conversations.** Five owners, asking about the problem rather than pitching. An afternoon, and it beats a month of guessing
- 🤖 **Have AI read it all and surface the pattern**, then sanity check the pattern against the five conversations

## 🏠 What Changes by Motion

**If your client sells in their own area**, they already know more than any research can tell you. They have met these people. Use that, and check it against the six questions rather than assuming it is complete.

**If your client sells to local businesses from anywhere**, they are more often in a blue ocean, because their buyer frequently does not know the category exists. That is an advantage on differentiation and a cost on comprehension. Part of your first email has to establish that a solution is possible at all.

## ✅ Before You Move On

- One ICP segment and one persona per campaign, decided
- An honest read on whether this category is red or blue, and evidence for it
- The six pain questions answered in the prospect's language
- A note on whether your saturation is real, or an artefact of where your list came from

---

<aside>
➡️

**Next:** [06 · Building the List](../06%20%C2%B7%20Building%20the%20List%20baa61a134ea182f5969a818c8b0ad4b1.md)

The longest section in the guide, and the one people came for.

</aside>