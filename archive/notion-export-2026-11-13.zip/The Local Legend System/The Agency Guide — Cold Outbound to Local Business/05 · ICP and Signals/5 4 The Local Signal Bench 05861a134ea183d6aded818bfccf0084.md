# 5.4 The Local Signal Bench

<aside>
📡

**A trigger is a specific event that makes a business more buyable today than it was yesterday.**

The standard trigger set is built on funding rounds, headcount velocity, new-in-role moves and tech-stack changes. A business with eleven employees and no filings has none of those.

This page is what replaces them.

</aside>

## ✅ What Makes a Usable Local Signal

Three tests. A signal has to pass all three or it is trivia.

- 👁️ **Observable from outside.** You can find it without knowing anybody at the business
- 🕐 **Recent.** It happened in a window short enough that it is still on their mind
- 🔗 **Connected to a problem you solve.** If you cannot draw a straight line from the signal to your offer, it is a fact rather than a trigger

That third test is the one that kills most ideas. A business celebrating fifteen years in trade is observable and datable and means nothing unless you sell something to businesses hitting fifteen years.

## 🧰 The Bench

| Signal | Where you find it | What it tells you |
| --- | --- | --- |
| 🏗️ **New location or second site** | A new Maps listing under the same brand, site footer, social post | Growth, capacity strain, and a moment where systems that worked stop working |
| 📋 **Permit filings** | City and county permit portals, usually public and searchable | They are spending money on the premises right now |
| 🚚 **Fleet growth** | Vehicle photos on the site, in reviews, or on social | More vans means more jobs, more staff and more admin |
| 💼 **Hiring** | Indeed, local job boards, a careers page, a notice in the window | The strongest everyday signal. The role itself tells you the gap |
| 📣 **Ads running right now** | Meta ad library, paid results on their category and area | They have budget and are actively buying growth, so they are not saying no on principle |
| 🌐 **New or rebuilt website** | Site changes, a copyright year that just moved | They are investing in how they present, and open to adjacent spend |
| 🕸️ **No website, or one clearly untouched for years** | The record itself | A visible gap. Works as a trigger for anything that fixes presence |
| ⭐ **Review velocity change** | Review counts over time | A sharp rise means growth. A sharp fall means something broke |
| 😠 **A recent bad review** | The review feed, sorted by date | Especially about response time, missed calls or no-shows. That is a problem with a named cause |
| 🔇 **Reviews going unanswered** | The review feed | Nobody owns the reputation. Also a reliable proxy for admin overload |
| 📜 **Licence or certification renewal** | State and trade licensing registers, which are usually public | A dated compliance moment, and a reason to be in touch that week |
| 🌦️ **Weather and storm events** | Local news and weather services | Roofing, restoration, tree work and plumbing all get a demand spike and a capacity problem |
| 📅 **Seasonal window** | The calendar and the trade | HVAC before summer, landscaping in spring, retail before the holidays. Predictable and easy to schedule |
| 👤 **Ownership change** | An owner name that resolves differently from last time, or an About page rewrite | The local equivalent of new-in-role. Everything is up for review in the first few months |

## 🎯 The Signal to Offer Map

The useful discipline is that **the same data point scores the lead and writes the opening line**. One enrichment, two jobs.

| Signal | The angle it unlocks |
| --- | --- |
| Hiring an office administrator | Admin is the bottleneck. Anything that removes admin, or does the job the hire was meant to do |
| Hiring field staff | Demand is outrunning capacity. Anything that raises throughput or job value |
| A bad review about missed calls | They are losing work they already won the right to. Answering, booking, follow-up |
| Second location opening | What worked at one site breaks at two. Consistency, systems, coverage |
| Ads running | They are paying for leads. Anything that converts more of what they are already buying |
| Reviews unanswered for months | Nobody has time. A visible, checkable gap you can show them in ninety seconds |
| Storm event in their area | A demand spike they cannot staff. Capacity, scheduling, overflow |

## 🔎 What It Costs to Collect

Not all signals are equally easy. Build in this order.

- 🆓 **Free on the record.** No website, dated website, review count, unanswered reviews, location count. You already have these from sourcing, so use them first
- 🔍 **One check per record.** Ads running, recent bad reviews, hiring posts. Cheap to automate across a list, and this is where most of the value sits
- 🛠️ **Needs real tooling.** Permit filings, licence registers, weather triggers. Worth building only once a signal has proved it converts

**Start with one signal, not eleven.** Pick the one that is free or nearly free, build a campaign on it, and see whether it lifts the numbers before you build a second.

## ⏳ Signals Decay

A trigger is only a trigger inside its window. After that it is a fact.

| Signal | Useful for roughly |
| --- | --- |
| Storm or weather event | Days |
| Bad review | 2 to 4 weeks |
| Hiring post | While the post is live, plus a month |
| Ads running | While they are running |
| New location | 3 to 6 months |
| Ownership change | 3 to 6 months |
| Licence renewal | The month either side |

This is why signal campaigns run continuously on a small trickle rather than in one big batch. You are catching businesses as they enter the window, not sending to everyone who was ever in it.

## 🏁 What to Build First

If you do nothing else on this page:

1. 🥇 **Hiring.** Highest volume, easiest to check, and the role names the problem for you
2. 🥈 **Unanswered or recent bad reviews.** Free on the record, visible, and it gives you something specific to open with
3. 🥉 **Ads running.** Proves budget and intent before you spend a word on them

Those three cover most categories, cost almost nothing, and will tell you within a month whether signal campaigns are worth more effort in your market.

---

<aside>
🏢

### Signals Are What Separate You From the Last Agency

Your client has seen a list before. They have not seen outreach that fires because somebody posted a job yesterday, or because a bad review about response times went up last week.

Build it once and it works across every client in that trade, which is the closest thing to leverage an agency has here.

Start with the three that are nearly free: hiring, review gaps, and ads running.

</aside>

---

<aside>
➡️

**Next:** [5.5 Ocean State and Pain Research](5%205%20Ocean%20State%20and%20Pain%20Research%20e8161a134ea1828b980f81f4c36a69df.md)

How saturated your category is, and the six questions to answer before you write anything.

</aside>