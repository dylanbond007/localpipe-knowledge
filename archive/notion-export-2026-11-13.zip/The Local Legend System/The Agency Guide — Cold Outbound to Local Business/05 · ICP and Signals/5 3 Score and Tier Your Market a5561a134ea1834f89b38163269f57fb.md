# 5.3 Score and Tier Your Market

<aside>
🎚️

**A list without a score treats every business as equal, and they are not.**

Some records deserve a phone call and a piece of direct mail. Some deserve one templated email. Some deserve nothing at all, and sending to them costs you money and reputation for no return.

</aside>

## 💡 Why Score Instead of Just Filter

Filtering is binary. In or out. Scoring is a ranking, and it lets you spend differently across the list.

That matters because enrichment is the expensive line. Resolving an owner name and a direct email costs real money per record, and it makes no sense to spend the same amount on a business that scores 85 as on one that scores 45.

**Score first, then decide what each band is worth spending on.** That single sequencing decision usually saves a third of the enrichment budget.

## 🧮 Build the Rubric

Pick five to eight criteria you can actually see on a record, weight them out of 100, and score every business.

Here is a working example for a commercial cleaning company:

| Criteria | Points | How you score it |
| --- | --- | --- |
| **Category match** | 25 | Core category 25, adjacent category 15, edge case 5 |
| **Size proxy** | 20 | Review count and location count as a stand-in for headcount. In the target band 20, one band off 10 |
| **Geography** | 15 | Inside 30 minutes 15, inside 45 minutes 10, beyond that 0 |
| **Tenure** | 10 | Trading five years or more 10, three to five 7, under three 3 |
| **Web presence** | 10 | Current site 10, dated site 5, no site 0 |
| **Review behaviour** | 10 | Owner replies to reviews 10, reviews exist but unanswered 5, none 0 |
| **A live signal** | 10 | Any current trigger present 10, none 0 |

The weights are yours. What matters is that they reflect what your best customers actually had in common, from the paragraph you wrote in 5.2.

## 🅰️ Four Tiers, Four Levels of Spend

| Tier | Score | What it earns |
| --- | --- | --- |
| 🅰️ **A** | 80 to 100 | Full enrichment including owner phone. Custom personalization. Email, phone and direct mail. Longest sequence. Worth a human looking at the record |
| 🅱️ **B** | 60 to 79 | Standard enrichment. Location and owner name personalization. Email and phone. Standard sequence |
| 🅲 **C** | 40 to 59 | Cheap enrichment only. A generic inbox is fine. Templated copy, email only, shorter sequence |
| 🅳 **D** | Under 40 | Nothing. Do not enrich, do not send |

The gap between A and C is not effort for its own sake. An A-tier record justifies four times the spend because it converts at a multiple, and the only way to know which is which is to have scored them.

## 💰 Score Before You Enrich

The order matters more than the rubric.

Everything in that scoring table comes free on a sourced record. Category, review count, location count, distance, tenure, website, whether reviews are answered. None of it costs a penny to read.

So:

1. 🗺️ **Source the full list**
2. 🎚️ **Score everything.** Free
3. 🗑️ **Drop the D tier.** Free
4. 💸 **Enrich what remains**, at a depth set by tier
5. 📬 **Segment and send**

Enrich first and score afterwards and you have paid to resolve owner names for businesses you were never going to contact.

## 🚫 Disqualify Properly

The hardest part of scoring is acting on a low score.

There is a strong pull toward emailing the D tier anyway, because the list looks bigger and sending feels like progress. It is not progress. It is the fastest route to a spam complaint, and at three reports per thousand sends you do not have much room.

**A business that has no use for your offer is not a weak lead. It is a wrong one.** Cut it and let the list be smaller.

If cutting the D tier leaves you short on volume, that is a sizing problem, and the answer is in 3.3 rather than in lowering the bar.

## 🔁 Rescore as Things Change

A score is a snapshot. Local businesses change faster than corporate ones, because a single hire, a second van or a new location moves them materially.

- Rescore before every new campaign into a market you have worked before
- A business that scored C eighteen months ago may be a B now
- Anything that has picked up a live signal since you last looked jumps a tier on its own

## ⚠️ What Not to Score On

Three things that feel like signal and are not:

- ⭐ **Star rating on its own.** A 4.2 with 400 reviews is a bigger, better-run business than a 5.0 with six. Score review *count* for size and *replies* for owner engagement. The rating itself tells you very little
- 💅 **How nice the website looks.** Plenty of excellent local businesses have terrible websites because they are too busy doing the work. A dated site can be a buying signal rather than a disqualifier
- 🗣️ **Whether you personally like them.** Score on what predicted your best customers, not on who you would enjoy working with

## ✅ Before You Move On

- A rubric of five to eight criteria, weighted to 100, built from your own best customers
- Every record scored, before any enrichment spend
- Four tiers with a different spend level attached to each
- A D tier you actually cut rather than email anyway

---

<aside>
🔑

### You Can Only Score on Fields You Actually Have

Every criterion in the rubric above assumes the record carries it. Category, review count, location count, tenure, website, owner name. A thin record cannot be scored, which means it cannot be prioritised, which means you spend the same on everything.

LocalPipe is the local business database this guide runs on:

- 👤 **75%** owner name find rate
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- ✅ **Triple verified**, with **sub 1% bounce** on raw exports
- 🗺️ Full Maps fields on every record, so the free scoring inputs are actually there

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

---

<aside>
➡️

**Next:** [5.4 The Local Signal Bench](5%204%20The%20Local%20Signal%20Bench%2005861a134ea183d6aded818bfccf0084.md)

The triggers that actually exist on a business with eleven employees and no filings.

</aside>