# 12.4 Referral Loops and Recommendation Threads

<aside>
🤝

**Local trades sit in dense referral networks with no corporate equivalent.**

A commercial cleaner and a commercial landscaper share customers and do not compete. Those introductions convert at rates outbound cannot approach, and outbound is how you find the partners.

</aside>

## 🔗 Why This Works Better Here

In corporate B2B, a referral is a nice-to-have. In local it is often the dominant channel, for structural reasons.

- 🏘️ **The same buyers use many suppliers.** One property manager buys cleaning, landscaping, HVAC, security and pest control. Five businesses, one customer
- 🗣️ **Trust travels locally.** A recommendation from somebody they already pay carries more weight than any case study
- 🚫 **Non-competing overlap is everywhere.** Most local trades serve the same customers and never bid against each other
- 🔁 **It compounds.** Each partner is a permanent source rather than a one-off lead

## 🎯 Outbound Finds the Partners

This is the part people miss. Running a cold campaign into a vertical surfaces partner opportunities as a side effect, and most operators throw them away.

**Every "not for us, but talk to X" reply is a partner introduction.** Section 11.2 files it as reply type three, and it is worth more than most positives.

Two things to do with them:

- 📇 **Log every referral reply separately.** After fifty campaigns you have a map of who refers to whom in your market
- 🤝 **Go back to the referrer.** Somebody who sent you a lead unprompted is a candidate for a standing arrangement, not a one-off thank you

## 🏗️ Building a Referral Loop Deliberately

Four steps, and it takes weeks rather than months.

### 1️⃣ List the non-competing trades

Who else sells to your exact customer without competing with you? Write down five to ten categories.

A commercial cleaner's list: landscaping, pest control, HVAC, security, waste management, window cleaning, office fit-out.

### 2️⃣ Build a list of those businesses in your radius

Same sourcing process as any campaign. Same tools, same filters. Section 06.

The difference is the target. You are looking for operators of roughly your size in your area, not customers.

### 3️⃣ Run a partner campaign

Different offer, same machinery. You are not selling, you are proposing an exchange.

The pitch is straightforward: we serve the same customers, we do not compete, and we both lose work we cannot take. Send each other what fits.

**Keep the ask small.** Not a formal agreement. A conversation, then one referral each way, then see.

### 4️⃣ Make it easy to send you work

The most common failure. People agree to refer and then never do, because at the moment it comes up they cannot remember what you do or how to introduce you.

- ✉️ **Give them a one-line description** of exactly who to send you
- 📱 **Be easy to contact.** They should be able to forward a name in ten seconds
- 🔁 **Refer first, and keep doing it.** Reciprocity is the whole mechanism
- 📞 **Follow up on every referral fast**, and tell the referrer what happened. Nothing kills a loop faster than sending somebody a lead and hearing nothing back

## 💬 Recommendation Threads

The other half of this. Local Facebook groups, neighbourhood forums, trade groups and community pages where somebody asks "can anyone recommend a good X".

Those threads rank, they persist, and they carry more weight than advertising.

**How to do it without it backfiring:**

- ✅ **Contribute as the business**, openly. Never as a fabricated customer. That gets found out and it is fatal locally
- ✅ **Answer the actual question.** If somebody asks for advice, give advice. The credit comes later
- ✅ **Be genuinely useful in threads that are not about you**, so your name is already familiar when a relevant one appears
- ❌ **Do not post the same comment everywhere.** It reads as spam, because it is

**This is a client activity you hand over with instructions**, not something you do on their behalf. It only works in their voice, and an agency posting as a client in a local community group is a genuine reputational risk for both of you.

What you can do is find the threads, brief them on how to answer, and remind them monthly. That is a real deliverable and it costs you very little.

## 🔍 Search Visibility as a Complement

Worth one paragraph, because it interacts with everything else.

Inbound takes the demand that is already searching. Outbound takes the contracts nobody searches for. They are not competing for the same work.

For a small market, inbound is often the better first investment, because outbound will exhaust the market and inbound will not. For a large one, outbound produces faster and inbound compounds. Run both if you can.

## ✅ Before You Move On

- A list of five to ten non-competing trades who share your customers
- Referral replies logged as a separate category, not filed as negatives
- A partner campaign planned, with a small first ask
- A one-line description of who to send you, given to every partner
- A rule that you refer first and report back fast

---

---

<aside>
➡️

**Next:** [13 · Tech Stack and Costs](../13%20%C2%B7%20Tech%20Stack%20and%20Costs%20c7e61a134ea18260a32d01d2dad72212.md)

What to buy, in what order, and nothing you do not need.

</aside>