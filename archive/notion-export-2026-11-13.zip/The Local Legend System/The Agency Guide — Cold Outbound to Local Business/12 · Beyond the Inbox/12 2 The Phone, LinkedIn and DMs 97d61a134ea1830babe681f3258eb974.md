# 12.2 The Phone, LinkedIn and DMs

<aside>
📞

**The phone works at every tier. LinkedIn works at one of them.**

Getting that the wrong way round is how people spend three months on a channel their buyers are not using.

</aside>

## ☎️ The Phone

The most underrated channel in local outbound, and the one with no warm-up requirement.

**Three ways it earns its place:**

- ⚡ **As the fast lane.** Live in week two while email warms. Section 10.1
- 🔥 **After a reply.** The highest-value use by a distance. Section 11.1
- 🎯 **Cold, on your A tier.** Manual and slow, so reserve it for records that justify it

**On the number itself.** A Maps record almost always carries a phone number. On the smallest businesses that number is often a personal mobile, which means you have a direct line without paying for one. Owner-direct phone numbers resolve on only about 20% of records through enrichment, so the free one on the listing is worth more than people assume.

**What works on the call:** short, direct, and a reason for calling today. The same opener discipline as email. They are on a job, so the first ten seconds decide whether you get the next thirty.

## 💼 LinkedIn

Honest answer: **mostly useless at tier one, genuinely good at tier two.**

| Tier | LinkedIn |
| --- | --- |
| 🚐 **One-van operators and small SMBs** | Most are not there. The ones who are do not check it. Skip entirely |
| 🏬 **Franchises and multi-location groups** | Real profiles, real titles, real activity. Everything you know about LinkedIn outbound applies |
| 🏭 **Enterprise-local** | Fully present, and often the better channel than email given the gateways |

This is why the three dead playbooks in 8.2 come back on tier two. If you sell to groups and head offices, LinkedIn is not a local channel at all, it is ordinary B2B and you already know how to run it.

## 💬 Instagram and Facebook DMs

Worth knowing about, narrow in application.

- 🍽️ **Consumer-facing trades only.** Restaurants, salons, gyms, retail, anything with a visual business
- 👤 **Often run by the owner personally**, which is the appeal
- 🐢 **Low volume, manual, and slow.** This is not a scalable channel, it is a way to reach twenty specific businesses
- 🚫 **Not for trades, B2B services or professional practices.** The account is either dormant or run by an agency

Use it when a business has no website, no resolved email and an active Instagram. That combination is more common than you would think, and DMs are the only route in.

## 🧱 Stacking Channels Properly

Multi-channel does not mean the same message everywhere on the same day.

**The order that works:**

1. 📧 **Email** carries the volume and does the discovery
2. 📮 **Direct mail** interrupts the sequence for your best records. Section 12.1
3. 📞 **Phone** converts anything that moves, and works cold on the A tier
4. 💼 **LinkedIn** runs as a parallel track on tier two only

**Two rules:**

- 🔇 **Suppress across channels on reply.** Somebody who answered the email should not get the cold call
- 🧾 **One coherent story.** If they meet you three times in a fortnight, it should feel like one person being persistent, not three campaigns colliding

## ⚖️ How to Choose

Rather than running everything, ask two questions per channel:

- **Are my buyers actually there?** Not businesses in general. Mine, at my tier
- **Can I sustain it?** A channel you run for three weeks and abandon is worse than one you never started, because it costs the contacts

For most tier one local programs the honest answer is email, phone and direct mail. That is the whole stack, and it is enough.

## ✅ Before You Move On

- The phone live in week two, not held until the email is proven
- LinkedIn used only if you sell to tier two or three
- DMs reserved for consumer-facing businesses with no other route in
- Suppression working across channels, not just within email
- Every channel you run being one you can sustain

---

<aside>
🔑

### The Phone Number Is Only Useful if the Record Has One

Every channel on this page depends on the record carrying the right contact details. A listing with no owner name, no verified email and no direct number is a business you cannot reach by any route.

LocalPipe is the local business database this guide runs on:

- 📞 Owner phone returned alongside the email, not as a separate purchase
- 👤 **75%** owner name find rate
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- ✅ **Triple verified**, with **sub 1% bounce** on raw exports

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

---

<aside>
➡️

**Next:** [12.3 Territory, Proximity and Density](12%203%20Territory,%20Proximity%20and%20Density%20b7f61a134ea183d483d4015a40402b5b.md)

Why a scattered list produces work you cannot profitably do.

</aside>