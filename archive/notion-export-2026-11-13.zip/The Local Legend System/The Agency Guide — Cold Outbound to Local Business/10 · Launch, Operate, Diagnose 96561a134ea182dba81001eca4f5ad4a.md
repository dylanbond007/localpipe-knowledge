# 10 · Launch, Operate, Diagnose

<aside>
🚀

**What this section does.** Takes it live without burning the domains you just paid for, keeps it running on a rhythm, and finds the real break when the numbers slip. On local the break is in the list about three times out of four, which is why the diagnostic runs bottom-up.

</aside>

**Applies to:** Both motions. One change worth flagging: the pre-email fast lane is the phone and direct mail here, not LinkedIn.

<aside>
🏢

**Week two is where a client's patience is tested.** Nothing has sent, nothing has arrived, and they are paying. Getting the phone and direct mail lane live in week two is as much about the relationship as it is about pipeline. Say it at onboarding so the quiet fortnight is expected rather than alarming.

</aside>

## Chapters

1. **10.1 The Launch Timeline.** Two lanes, six weeks, and what goes live in week two
2. **10.2 Pre-Launch and Copy QA.** Infrastructure, list, copy and tracking checks, merged into one pass
3. **10.3 The Numbers to Watch.** Four leading, four lagging, and which of them a client ever sees
4. **10.4 The Four-Pillar Diagnostic.** Deliverability, prospect, offer and copy, scale. In that order

---

[10.1 The Launch Timeline](10%20%C2%B7%20Launch,%20Operate,%20Diagnose/10%201%20The%20Launch%20Timeline%209de61a134ea183a9b36901000cac349f.md)

[10.2 Pre-Launch and Copy QA](10%20%C2%B7%20Launch,%20Operate,%20Diagnose/10%202%20Pre-Launch%20and%20Copy%20QA%20a7961a134ea1824280c80177c6a8de1b.md)

[10.3 The Numbers to Watch](10%20%C2%B7%20Launch,%20Operate,%20Diagnose/10%203%20The%20Numbers%20to%20Watch%20f1f61a134ea183518a7101ed48d9e6a7.md)

[10.4 The Four-Pillar Diagnostic](10%20%C2%B7%20Launch,%20Operate,%20Diagnose/10%204%20The%20Four-Pillar%20Diagnostic%2048061a134ea183d5a56001da9e4c3034.md)

---

<aside>
➡️

**Next section:** [11 · Replies to Booked Meetings](11%20%C2%B7%20Replies%20to%20Booked%20Meetings%20d2261a134ea182fc9a6801299e1fe472.md)

The section that decides whether your work looks successful.

</aside>