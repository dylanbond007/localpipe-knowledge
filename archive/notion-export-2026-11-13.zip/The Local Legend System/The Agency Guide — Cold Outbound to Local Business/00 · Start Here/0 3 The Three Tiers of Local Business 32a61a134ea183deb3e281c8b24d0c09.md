# 0.3 The Three Tiers of Local Business

<aside>
🏗️

**"Local business" covers a one-van plumber and a 400-employee facilities contractor.**

Almost nothing about selling to them is the same. Tier does more to decide your campaign than vertical does.

</aside>

<aside>
🏢

**Ask which tier at qualification, not after signature.**

A client selling to one-van operators and a client selling to franchise groups need different data sources, different channels and different expectations, and the difference is invisible until you have built the list. Tier is the first question on your intake form for a reason. A2.1.

</aside>

## 🏗️ Why Tier Beats Vertical

Most people segment local lists by category. Plumbers here, dentists there. Useful for copy, but it is not what decides whether the campaign works.

Size is. Size decides:

- Whether the owner reads their own inbox
- Whether a professional profile for them exists anywhere
- Whether there is a procurement process
- How long the deal takes
- Whether the personalization you planned is even available on the record

A plumbing company with two vans and a plumbing company with sixty are different businesses that happen to share a category.

## 🚐 Tier One: Owner-Operator and Small SMB

Roughly 1 to 25 people. One location, or a service area worked out of one yard.

- 📬 **Who reads the inbox:** the owner, their spouse, or an office manager who has been there nine years. Nobody to delegate to
- 🔍 **Professional profile:** usually none. No LinkedIn, no bio page, sometimes no website
- 📧 **Contact reality:** a generic inbox and a personal address, often on a free provider. The owner's personal Gmail frequently **is** the business address
- ⚡ **Decision:** fast, made by one person. A reply can become a signed job the same week
- 💵 **Deal size:** small. The volume is in the count, not the contract
- 🎯 **What they care about:** cash this month. Not strategy, not efficiency in the abstract, but the next job, the unpaid invoice, the van that is off the road
- ✅ **What works:** the phone, direct mail, plain language, and an offer that pays for itself quickly

**This is the tier the guide is calibrated to.** It is where the four contact buckets in 6.4 matter most, and where every LinkedIn tactic you know is unavailable.

## 🏬 Tier Two: Franchise and Multi-Location

Roughly 25 to 250 people, or several locations under one owner. Regional groups, franchise systems, roll-ups.

- 📬 **Who reads the inbox:** depends where you send. A location inbox is read by a manager. Head office has a real marketing or ops function
- 🔍 **Professional profile:** yes. Titles exist, LinkedIn exists, and the playbooks that die on tier one come back to life
- 📧 **Contact reality:** business domains, structured addresses, a named decision maker who is usually not the founder
- 🕐 **Decision:** a process. Two or three people, a budget cycle, sometimes a pilot at one site before rollout
- 💵 **Deal size:** materially larger. One deal can be worth twenty tier-one deals
- 🎯 **What they care about:** consistency across sites, cost control, and not breaking what already works
- ✅ **What works:** email plus LinkedIn, case studies from comparable groups, a pilot framed as low-risk

<aside>
🔀

**The head-office question.**

With a multi-location group you have to choose: pitch the individual locations, or pitch head office.

Locations are easier to reach and often cannot buy. Head office can buy and is harder to reach.

Pitching both at once is how you end up in a conversation where the location manager has already told corporate no.

</aside>

## 🏭 Tier Three: Enterprise-Local

Large commercial, industrial, facilities, construction, energy. Physically local, structurally corporate.

- 📬 **Who reads the inbox:** a gatekeeper, or nobody. Mail passes a security gateway before a human sees it
- 🔍 **Professional profile:** complete. Full org charts, and the standard B2B databases actually cover these
- 📧 **Contact reality:** structured corporate addresses. The four-bucket model barely applies
- 🕐 **Decision:** a buying committee, procurement, sometimes a formal tender
- 💵 **Deal size:** large, and slow
- 🎯 **What they care about:** risk, compliance, insurance, whether you can service the whole contract
- ✅ **What works:** conventional enterprise outbound

**If most of your pipeline sits here, you do not have a local data problem.** The standard databases cover these companies. Use the ordinary playbook.

## 📊 Side by Side

|  | Tier One | Tier Two | Tier Three |
| --- | --- | --- | --- |
| **Owner reads own inbox** | Almost always | At the location, not head office | Never |
| **Findable on LinkedIn** | Rarely | Usually | Always |
| **Where the data comes from** | Maps sourcing and enrichment | Both | Standard B2B databases |
| **Four contact buckets apply** | Completely | Partly | Barely |
| **Free-provider addresses** | Common, often the owner | Rare | Never |
| **Decision cycle** | Days | Weeks to a quarter | A quarter or more |
| **Direct mail** | Strong | Works at head office | Rarely worth it |
| **Phone follow-up** | Essential | Useful | Gatekept |
| **Optimizing for** | Cash this month | Consistency and cost | Risk and enterprise value |

## 🔍 How to Tell Which Tier a Record Is

A Maps record does not carry headcount, so you work from proxies. These are reliable enough to filter on:

- 📍 **Number of locations under the same brand.** Strongest single signal, and free
- ⭐ **Review volume.** A business with 2,000 reviews is not a one-van operation
- 💼 **Whether a careers page exists**, and whether it lists more than one role
- 🚚 **Fleet size**, visible on the website or in photos, for trades
- 👔 **Whether the site names a leadership team** rather than just an owner
- ❓ **Whether an owner name resolved at all.** Enrichment failing on a business with a slick site usually means there is a management layer

## ⚠️ The Mistake This Page Exists to Prevent

**Category searches return all three tiers, and most people never split them.**

Search commercial cleaning in a metro and you get the two-person operation, the regional group with eleven locations, and the national contractor's local branch, all in one export.

Write one sequence for that list and it will be:

- Too corporate for tier one
- Too casual for tier three
- Slightly wrong for the middle

Worse, the list looks fine. Nothing in the file says these are three different businesses. You find out from a reply rate that sits stubbornly below what the data quality should support.

**Split by tier before you write anything.** It is a filter on the record, it costs nothing, and it is the cheapest lift available to a local campaign.

## 🔀 Tier and Motion Together

Your motion from 0.2 and your tier here combine:

- 🏠🚐 **Local → Local, tier one.** The core case this guide is built for. Proximity proof, direct mail, phone, and the bucket model doing heavy lifting
- 🏠🏬 **Local → Local, tier two.** Bigger contracts in your own metro. Fewer targets, so quality per record beats volume
- 🌐🚐 **Business → Local, tier one.** National, high volume, unbounded market. The bucket model is your cheapest lever
- 🌐🏬 **Business → Local, tier two.** Where the LinkedIn playbooks you already own come back. Often the highest-value combination available

---

<aside>
➡️

**Next:** [0.4 The Numbers, and Where They Come From](0%204%20The%20Numbers,%20and%20Where%20They%20Come%20From%20e4961a134ea1835c9fdd010a51d31041.md)

The benchmark table, and how much weight each figure can carry.

</aside>