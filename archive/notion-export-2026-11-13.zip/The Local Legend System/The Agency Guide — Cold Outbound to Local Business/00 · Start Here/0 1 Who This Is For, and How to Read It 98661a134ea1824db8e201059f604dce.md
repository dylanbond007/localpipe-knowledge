# 0.1 Who This Is For, and How to Read It

<aside>
🏪

**This guide is about selling to local businesses.**

Everything in it, from the data to the deliverability work to the copy, is built around one kind of buyer: someone who owns a business with a physical location, does some of the work themselves, and reads their own inbox.

If that is who your clients are trying to reach, you are in the right place.

</aside>

## 🏪 What "Local Business" Means Here

The definition matters, because it does real work throughout the guide. A local business, for our purposes, has four properties:

- 📍 **A physical location, or a defined service area.** A shop, a clinic, a yard, a fleet of vans
- 👤 **An owner who is close to the work.** They quote jobs, they answer the phone, they know every customer's name. No procurement process, and often no marketing person
- 🗺️ **A customer base defined by geography.** They serve the city, the county, the metro
- 🕳️ **Almost no presence in the B2B databases.** This is the operative one. The tools most people use to build lists were built for companies with LinkedIn pages, funding rounds and org charts. A twelve-person landscaping company has none of those, so as far as those tools are concerned it does not exist

That last property is why this guide exists at all. Everything difficult about local outbound follows from it.

**Not local, for our purposes:** remote-first companies, ecommerce brands, software companies, and anything with a head office and distributed staff. Those are well served by the standard playbook.

## 👤 Who This Version Is Written For

You run outbound for clients, and at least one of them sells to local businesses. The meetings land on a client's calendar rather than your own, and you are judged on whether they get held.

The motion is a property of the client, not of your agency. Every local client is one of two:

- 🏠 **The client is also a local business**, selling into their own area. A commercial cleaner going after restaurants. A landscaper going after property managers
- 🌐 **The client is not location-constrained**, but their customers are local businesses. Software for trades. Coaching for contractors. A lender to small business owners

Ask it per client rather than once for your agency, and put it on your intake form. It changes the geography strategy, the proof that works, and what you can honestly promise on volume. **0.2 Pick Your Motion** settles it in two minutes, and determines which version of about a fifth of the pages applies to that engagement.

## 🚫 Who This Is Not For

- **Businesses that want meetings on their own calendar.** If outbound is not a service you sell to clients, take [The Business Owner Guide — Cold Outbound to Local Business ICPs](../../The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20%20f2961a134ea18308bfbe014b0ee3475c.md) instead. The same system, without the client acquisition, pricing and multi-tenant work
- **Anyone selling to consumers.** Cold email to private individuals is a different practical and legal problem, and none of this transfers
- **Any client who needs meetings this week.** Warm-up alone takes two weeks before the first real send. Worth starting, but it will not fix the month they are currently worried about

## ✅ What the Client Needs Before You Start

<aside>
✅

**An offer that has closed at least once.** Cold outbound is an amplifier. It finds more of what already works. It does not discover what works, and no amount of copy covers for an offer nobody has bought.

**Someone on their side who can call back within the hour.** On local, a reply is a cue to pick up the phone. Name that person during scoping, rather than discovering in month two that nobody owned it. Section 11.4.

**A market big enough to hold a program.** Size it before you quote the retainer, not after you have signed it. A1.2.

**Two weeks before the first send**, and six to eight before the first meeting. Set that expectation during the sale.

**A budget they can hold for ninety days.** Cancelled at month two, a program costs them everything it cost and returns nothing, and it lands as a mark against your work rather than against their patience.

</aside>

The first three are disqualifiers rather than warnings. A1.3 turns them into the questions you actually ask on a first call.

## 🧭 How to Read It

**Reading order and doing order are not the same thing.**

The sections are numbered so the ideas build on each other. Follow that order literally and you will spend two weeks waiting for inboxes to warm at exactly the wrong moment.

So:

1. 🥇 **Order infrastructure on day one of the engagement**, before anything else is decided. Section 04 says what to buy. The warm-up clock runs whether or not the rest is ready, and holding a pre-warmed pool removes the longest delay in selling a local retainer. Section 4.4
2. 🔁 **Then work the loop.** Who you are emailing decides what you pitch. What you pitch decides your campaigns. Your campaigns decide your copy. Your copy decides what data you need to go and find
3. 📋 **Build the list last.** Deliberate. Your copy tells you what to enrich for, and email addresses go stale within weeks, so you pull them days before launch rather than months

The full schedule is in **0.5 Launch in 15 Days**.

## 🔀 The Markers

Most rules here apply to everybody. Where they do not, the page says so in place:

| Marker | What it means |
| --- | --- |
| **Both motions** | The rule holds either way. Most of the guide |
| **L→L only** | True because the client has to service the work locally. Skip it where a client sells everywhere |
| **B→L differs** | The rule changes when the client is not location-constrained, and the page says how |
| **Tier-dependent** | Changes depending on whether the client sells to one-van operators, franchises, or large commercial. See 0.3 |

## ❌ What This Guide Does Not Cover

Said plainly so you are not waiting for it:

- **Consumer marketing.** Nothing here applies to selling to the public
- **Paid ads and search**, except where they interact with outbound. Good complement, different craft
- **Anything that changes quarterly.** Warm-up ratios and platform settings move constantly. Where a number like that appears, it is labelled as a current baseline rather than a rule
- **Legal advice.** 15.4 covers the operational side of compliance. It is not a substitute for a lawyer in your jurisdiction

## 🎯 One Expectation Worth Setting Now

Most of the work in local outbound happens before a single email is written. The list is where campaigns are won and lost here, far more than in ordinary B2B, because the list is something you build rather than something you buy.

It is also the expectation to set with a client early. Otherwise they will be asking about subject lines in week two, while the work that decides the result is happening somewhere they cannot see.

If you take one thing from this page: **the copy is not the lever. The list is.**

---

<aside>
➡️

**Next:** [0.2 Pick Your Motion](0%202%20Pick%20Your%20Motion%20da661a134ea182268288015b8c56817a.md)

Two minutes, and it decides which version of the guide you are reading.

</aside>