# 4.6 The Free-Provider Lane

<aside>
🔑

**On a corporate record, a gmail address usually means bad data.**

**On a local record, it usually means the owner.**

A business started in 2009 by one person with a truck set up a free address, the business grew, and nobody ever saw a reason to migrate. That address is now the most direct line to a decision maker you will ever get, and standard practice says delete it.

</aside>

## 🚫 Why the Standard Advice Fails Here

Every general cold email guide tells you to strip gmail, [outlook.com](http://outlook.com) and yahoo addresses out of your list. That advice is correct in corporate outbound, where a free address on a B2B record means somebody mistyped something or the data is years old.

In a local market, deleting them removes **a third to a half of the contacts that reach an actual decision maker**. Often the better-performing half, because these are personal inboxes read by the person who signs cheques rather than role inboxes read by whoever is on the desk today.

You do not delete this segment. You build for it.

## ⚔️ The Collision

**The rule:** spend your first 90 days sending only to the easy rung of the ladder while your reputation builds from zero. Section 4.1.

**The reality:** on a local list, a large share of your best contacts sit on consumer providers, which is a harder rung. So the rule tells you to avoid exactly the inboxes your buyers use.

The answer is to build infrastructure that earns trust before it ever sends, and then never pushes itself hard enough to lose it.

## 🅿️ Stage One: Buy the Domains and Park Them

Buy first, send later. Let them sit.

- **30 days minimum.** 90 days is the real target
- A brand new domain is suspicious to every receiving system. An aged domain with a clean history is trusted before you have sent a single email
- Parking costs nothing except patience. It is the cheapest deliverability you will ever buy

This is why the buying decision comes early and separately from everything else. Domains bought today are infrastructure you can use next quarter.

## 🔥 Stage Two: Warm on a Pool That Reaches Personal Inboxes

Standard sequencer warm-up pools are built from business mailboxes, so they generate no signal against consumer inboxes. A warm-up tool that cannot reach a personal inbox cannot build reputation with one.

**A premium warm-up pool that includes real personal inboxes builds genuine engagement history against gmail and [outlook.com](http://outlook.com)**, which is exactly the reputation this segment needs. Warmy is the one I use.

- **3 weeks minimum** on the pool before real sending
- **Up to 90 days** if your TAM is small and you cannot afford to miss the inbox. When the market is only a few thousand contacts, every send has to count, and a longer warm is far cheaper than a second attempt at a market you have already annoyed

Do this properly and you should see a solid reply rate from the segment rather than the degraded one people expect from personal addresses.

## ♻️ Stage Three: Run Two Batches in Rotation

You hold double the infrastructure and use half of it at a time.

1. **Batch 1 sends for two weeks**
2. Batch 1 then **rests and re-warms** while **Batch 2 takes over**
3. Two weeks later they swap back
4. Repeat indefinitely

Each batch spends half its life sending and half recovering. Nothing gets pushed until it breaks, so nothing has to be replaced.

## 📈 Why This Works

- 🏦 **Domains are an asset, not a consumable.** Bought once, aged continuously, reused indefinitely
- 📊 **Reputation compounds.** Every month the domains are older, cleaner and more trusted than the month before
- 😴 **Rest is the mechanism.** A mailbox that sends for two weeks and recovers for two weeks never reaches the point where providers start treating it as a problem
- 💰 **The cost is front-loaded.** The heavy spend is at the start, and the monthly run rate falls as the estate matures

## ⏳ The Timeline

| Stage | Duration |
| --- | --- |
| 🅿️ Park the domains | 30 days minimum, 90 ideal |
| 🔥 Warm on a premium pool | 3 weeks minimum, up to 90 days on a small TAM |
| 🚀 Ramp into full volume | 2 to 3 weeks |
| ♻️ Rotation | Permanent. 2 weeks sending, 2 weeks resting |

Roughly **two months** from purchase to steady state. Buy the domains the day you decide to work this segment, even if nothing else is ready.

## 📐 Sizing It

Each batch carries the **full daily volume** on its own, because only one is live at a time.

Say **500 free-provider contacts a month** on a three-email sequence:

- 📨 500 × 3 = **1,500 sends a month**
- 📅 1,500 ÷ 30 = **50 sends a day**
- 📬 50 ÷ 5 = **10 inboxes per batch**
- 🌐 10 ÷ 3 = **4 domains per batch**
- ✖️ Two batches = **20 inboxes and 8 domains held**

Domains are registered once and renewed annually, so the monthly domain cost is the registration spread across the year rather than a recurring purchase. Inboxes are a monthly subscription, and the premium warm-up pool is a separate line.

Sends per inbox can rise above five once the domains are genuinely aged and properly warmed. Start conservative and let the placement numbers earn you the increase.

<aside>
📊

### Cost This Lane Properly

The **Infra Calc, Free Provider** tab sizes the rotation and prices both batches.

[**👉 The Local Legend Money Model**](https://docs.google.com/spreadsheets/d/1SCPMYKU4_lguC11AGqwnlqoJSqLd-lsJhnt4iEeTpTQ/edit?gid=1669046753#gid=1669046753)

Keep it separate from your main estate estimate. The two lanes do not share numbers.

</aside>

## ✅ How to Handle the Segment

- 🏠 **Separate domains and inboxes**, sized to this segment alone. Never mixed with the main estate
- 🅿️ **Park before you warm.** Age is the one input you cannot buy later
- 🔬 **Verify harder here than anywhere else.** This is the one bucket where a second validation pass earns its cost outright
- 🐌 **Ramp slowly, and let placement set the pace** rather than the calendar
- 🎯 **Judge it on opportunity quality, not on bounce rate.** These addresses reach owners directly. Grade this segment on the same dashboard as the main estate and you will kill your best contacts for looking untidy

## 🤔 When to Skip It

- 📉 **Under about 10% of your list is free-provider.** Not enough volume to justify a second estate yet. Suppress and accumulate
- 🏬 **You sell to tier two or three.** Franchises and enterprise-local are on business domains. This is a tier one problem. Section 0.3
- ⏰ **You need to launch this month.** The parking window makes this a two-month build. Start the main estate now, buy the free-provider domains today, and bring the lane online when it is ready

What you never do is delete the addresses. Keep them suppressed and segmented so the list is waiting when the infrastructure is.

## 🧭 The Summary

> **The advice to delete free-provider addresses is correct everywhere except the market you are selling into.**
> 

Park the domains, warm them on a pool that can actually reach personal inboxes, rotate two batches so neither is ever pushed to breaking point, and judge the segment on meetings rather than on how it looks in a deliverability report.

---

---

<aside>
➡️

**Next:** [4.7 What to Monitor, and Reading Bounces](4%207%20What%20to%20Monitor,%20and%20Reading%20Bounces%207fa61a134ea182168e8b815def5ceca5.md)

The daily rhythm, and what the bounce messages are actually telling you.

</aside>