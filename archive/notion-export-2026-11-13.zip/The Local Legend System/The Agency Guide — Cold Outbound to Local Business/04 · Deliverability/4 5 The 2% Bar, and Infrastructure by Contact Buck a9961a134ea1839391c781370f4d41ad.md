# 4.5 The 2% Bar, and Infrastructure by Contact Bucket

<aside>
🎯

**One number governs this whole guide.**

A well-built local list bounces under 2%. Everything above that is a signal that something upstream is wrong, and the further above, the faster you need to stop.

</aside>

## 📏 The Bands

| Bounce rate | What it means | What you do |
| --- | --- | --- |
| ✅ **Under 2%** | Healthy. This is what a properly built and verified local list does | Nothing. Carry on |
| 👀 **2 to 3%** | Something is drifting. Usually the list rather than the infrastructure | Go and look at the list. Check the source, the age and the verification pass |
| ⏸️ **5%** | You are actively damaging sender reputation with every send | Pause the campaign. Fix the list before restarting |
| 🛑 **10%** | Emergency. Providers are already treating you as a problem | Stop everything. Rebuild the list from scratch and expect to replace domains |

You will see 3% quoted as acceptable in general cold email advice. It is not the bar here, because local data is built rather than bought, so a high bounce rate is almost always something you did and can fix.

## 🐤 Bounce Is the Canary, Not the Disease

Nobody has a bounce problem. They have a list problem that shows up as bounces.

On local, the usual causes are specific:

- 🕷️ **Addresses scraped off a website that were never real mailboxes.** The classic failure of cheap enrichment tools, and a verifier passes them because the domain exists. Section 6.6
- 🪤 **Catch-all domains** that accept everything at the server and bounce it later
- 🚪 **Businesses that closed.** Local churn is high, and a list built three months ago has real decay in it
- 🥶 **Stale data.** Email addresses go off within weeks. Pull them days before launch, not months. Section 6.7
- 📮 **Free-provider addresses** mixed into the main list, which bounce about a third higher than everything else

## 🔍 Telling a List Problem From a Reputation Problem

They need completely different responses, and the pattern tells you which you have.

<aside>
📋

**Looks like a list problem**

Bounces cluster at launch or on a new batch.

They concentrate in records from one source, one category, or one scrape.

Older addresses that worked before still work.

Placement is fine.

</aside>

<aside>
🔥

**Looks like a reputation problem**

Bounces spread evenly across everything.

Addresses that delivered fine last month start failing.

Placement drops **before** bounce rises.

Reply rate falls across all campaigns at once, not just the new one.

</aside>

If it is the list, fix the list. If it is reputation, stop sending and work through 4.7 and 10.4.

<aside>
🔑

### Bounce Is a Data Problem Before It Is Anything Else

Every cause listed above is upstream of your infrastructure. Scraped addresses that were never real mailboxes, catch-alls, closed businesses, stale records. You cannot send your way out of any of them.

LocalPipe is the local business database this guide runs on:

- ✅ **Triple verified**, with **sub 1% bounce** on raw exports, so you start well under the 2% bar
- 👤 **75%** owner name find rate, against poor to none from the cheap scrapers
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- 🗺️ Resolved by cross-referencing real sources, not by scraping every string that looks like an email off a website

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

## ⚠️ The Other Number: Spam Complaints

Bounce gets the attention. Complaints do more damage.

**0.3%** is where your domain starts getting hurt. That is **three reports per thousand sends**, which is a brutally low bar and much easier to hit than people expect.

What drives it on local:

- Sending to a business that has no conceivable use for your offer, which is a targeting failure not a copy failure
- Contacting the same market twice in six months with the same angle
- Anything that feels like it came from a mass mailer, because owner-operators are unusually sensitive to that

The fix is almost never in the copy. It is in the list and the offer.

## 📬 Splitting Infrastructure by Contact Bucket

Section 6.4 sorts every local record into four buckets. Those buckets behave differently once you are sending, so they do not all belong on the same infrastructure.

| Bucket | Where it sends from | Expected bounce | What you watch |
| --- | --- | --- | --- |
| **1. Owner direct** | Primary domains | Low | Reply quality. This is your best segment |
| **2. Generic inbox, owner known** | Primary domains | Low | Reply quality, which lands close to bucket one in several verticals |
| **3. Generic inbox, no name** | Primary domains, monitored separately | Low to moderate | Bounce and complaints. Biggest volume, lowest personalization |
| **4. Personal provider** | **Its own separate estate** | About 1.6% | Everything, aggressively. On a local record this is the owner personally about nine times out of ten. Section 4.6 |

Buckets one to three can share domains. They are all business addresses on business domains, and they behave similarly. You separate them in **reporting** rather than in infrastructure, so you can see which bucket is carrying the campaign.

Bucket four is different. It gets its own domains, its own ramp and its own budget, because it genuinely behaves differently and mixing it in drags your main numbers down.

## 🧮 How Many Estates Does a Local Program Need?

Usually two.

- 🏢 **The main estate.** Business-domain addresses across buckets one, two and three
- 🔑 **The free-provider estate.** Sized to that segment alone, cycled faster, watched harder

A third only appears if you run two genuinely different offers to two different tiers, and even then most people are better off running them sequentially on one estate than splitting infrastructure they do not have the volume to justify.

## ✅ Before You Move On

- One bounce threshold across every campaign: under 2%
- A clear read on whether an elevated number is a list problem or a reputation problem
- Complaints tracked separately, against the 0.3% line
- Reporting split by contact bucket even though they share domains
- The free-provider segment on its own estate, not mixed into the main one

---

<aside>
➡️

**Next:** [4.6 The Free-Provider Lane](4%206%20The%20Free-Provider%20Lane%2097561a134ea182f98d7a01249ce8de38.md)

The most important page in this section, and the one that has no equivalent in corporate outbound.

</aside>