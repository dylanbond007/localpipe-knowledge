# 4.1 What Deliverability Is, and Who Judges Your Mail

<aside>
📫

**Deliverability is the foundation everything else sits on.**

The best ICP in the world, an offer people would crawl over glass for, and copy that could make a marble statue book a meeting. None of it counts if you land in spam, because you are broadcasting into a void.

When did you last open your spam folder to see who emailed you? Neither do your prospects.

</aside>

## 🏗️ Why This Goes First

The five levers are Scale, Copy, Offer, Prospect and Email Deliverability. You learn Scale first so you can see the maths, then you build from the bottom up, and the bottom is deliverability.

Get it right and everything downstream has a chance. Get it wrong and everything downstream is dead on arrival, and worse, you will not know. You will see a low reply rate and go and rewrite the copy.

## 🔍 What Deliverability Actually Is

Between you hitting send and your prospect reading, three things happen in milliseconds.

- 🪪 **Authentication.** Providers check whether your sending domain is legitimate, using three records: SPF, DKIM and DMARC. Missing or wrong and you are flagged before the email is even considered. Section 4.2
- 📊 **Reputation and age.** They check your domain's history. Brand new looks suspicious. Older and clean is trusted. Spam complaints on record and you are finished. Section 4.4
- 📥 **Inbox placement.** Primary, promotions or spam, decided on dozens of signals built from the first two

You never see any of this. You only see the result, which is your reply rate. So when somebody says the campaign is not working, half the time the campaign is fine and the email never arrived.

## 👮 Who Is Judging You: ESPs and SEGs

Two systems, and they behave very differently.

<aside>
📮

**ESP — Email Service Provider**

The system that hosts a mailbox.

Your **sending** ESP is where your mailboxes live: Google Workspace, Microsoft 365, Azure.

The **receiving** ESP is where your prospect's inbox lives: Gmail, Outlook, Yahoo.

</aside>

<aside>
🛡️

**SEG — Secure Email Gateway**

A security layer sitting in front of an inbox, filtering mail before it ever reaches the ESP.

Proofpoint, Mimecast, Barracuda, Cisco. Common at mid-size and enterprise organisations, and built to block exactly what cold email looks like.

</aside>

A gateway can accept your email, return no bounce, and quarantine it somewhere nobody will ever look. You get no signal at all.

## 🪜 The Deliverability Ladder

Same email, same setup, wildly different placement depending on what is receiving it. Win the base before you climb.

| Rung | What it is | Why |
| --- | --- | --- |
| 🔴 **Hardest** — SEG-protected inboxes | Proofpoint, Mimecast, Barracuda, Cisco | Purpose-built to block cold email. Never point fresh infrastructure at these |
| 🟠 **Harder** — Microsoft 365 and Outlook business | Company inboxes on Outlook | Stricter filters, and it weighs sender-reputation age heavily |
| 🟠 **Harder** — Consumer and free providers | [gmail.com](http://gmail.com), [outlook.com](http://outlook.com), [yahoo.com](http://yahoo.com) personal addresses | Roughly as hard as Microsoft 365, for different reasons. Higher bounce, no warm-up signal possible, and infrastructure burns far faster |
| 🟢 **Easiest** — Business domains on Google Workspace | A local business on its own domain, hosted by Google | Most forgiving filters and the best placement. Your bread and butter |

The middle two sit at about the same difficulty. People assume personal Gmail is the easy option because Gmail is forgiving, and it is not. A business domain on Google Workspace is the easy option. A personal Gmail address is a different animal, and 4.6 is entirely about why.

## 📅 The 90-Day Rule, and Why Local Breaks It

**The rule:** for your first 90 days, send only to leads on the easy rung. You are building domain and mailbox reputation from zero, so do not spend it fighting the hardest filters before you have proven the basics.

**The problem on local:** a large share of your best contacts are personal Gmail addresses, because on a local record a gmail address very often *is* the owner rather than bad data. So the rule tells you to avoid exactly the inboxes your buyers are sitting in.

You do not solve that by ignoring the rule or by deleting the segment. You solve it by giving that segment its own domains, its own slower ramp, harder verification and a bigger replacement budget, and judging it on its own numbers. That is 4.6, and it is the most important page in this section.

## 🍕 The Five Things That Drive Deliverability

The whole model in one analogy. You are ordering the best pizza of your life, and five things decide whether it arrives hot, correct and worth reordering.

Bottom of the stack matters most. Get the base right first, because the toppings only matter once the crust holds.

|  | Driver | What it means |
| --- | --- | --- |
| **5** | ✍️ The copy — the presentation | How you plate the offer, plus the technical hygiene that keeps filters from flagging you |
| **4** | 🎁 The offer — the taste | A weak offer means dead campaigns, and dead campaigns quietly rot your sender reputation |
| **3** | 📋 The list — who you deliver to | Send a meat-lover's to a building of vegans and they report you |
| **2** | 🚚 Sequencer and warm-up — the delivery guy | Carries your email to the door. Providers learn to trust or distrust it |
| **1** | 🔥 Inbox and domain setup — the chef and the oven | How the pizza actually gets cooked. **Most important by a mile** |

The link people miss is between three and four. **A weak offer degrades your infrastructure over time.** Nobody replies, engagement falls, reputation drifts down, and six weeks later it presents as a deliverability problem when it started as a message problem.

## 📉 Three Numbers Worth Knowing Now

- ⚠️ **0.3%** is the spam-complaint rate that starts tanking your domain. That is three reports per thousand sends. It is a brutally low bar
- 💀 **5 to 10 times faster** is how quickly your inboxes die if you skip warm-up and send full volume on day one
- ✅ **Under 2%** is what a well-built local list bounces. That is the bar for this entire guide, and 4.5 explains each band and what to do

## 🚧 Three Things You Will Not Be Doing

Stated now to save you deciding them later.

- 🚫 **Never send from your main domain.** If your company runs on [yourcompany.com](http://yourcompany.com), cold outbound does not go out from it. One bad campaign and your team cannot get invoices delivered. Buy lookalikes instead. Section 4.2
- 🚫 **Do not set up DNS yourself.** It is fiddly, it changes, and a managed provider handles it for a few dollars a mailbox. Section 4.2
- 🚫 **Do not point fresh infrastructure at gateways.** Respect the ladder. At tier one local this barely comes up, which is one of the few structural advantages of this market

---

<aside>
➡️

**Next:** [4.2 Domains, Inboxes and DNS](4%202%20Domains,%20Inboxes%20and%20DNS%2053161a134ea1830ea5bf8160ded44c2f.md)

Lookalike domains, registrars, the three records, and why you outsource it.

</aside>