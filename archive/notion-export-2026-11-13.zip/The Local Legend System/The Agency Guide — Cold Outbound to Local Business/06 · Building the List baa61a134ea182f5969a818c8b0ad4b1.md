# 06 · Building the List

<aside>
🗺️

**What this section does.** The longest and most important section, and the one most people came for. Google Maps is a consumer directory being used as a sales database. It holds the business, the category, the address, the phone and usually a website. It does not hold an email address and it does not hold an owner name. Everything hard follows from those two missing fields.

</aside>

**Applies to:** Both motions. The data layer does not care who your client is. **B→L clients differ** only on 6.3, where you go wide across metros rather than deep into one.

<aside>
🏢

**This is the section that differentiates you.** Your client has almost certainly been sold a list pulled from a standard database before. Under 5% of local businesses are in those tools, which is why it underperformed. Being able to explain and demonstrate the difference is the strongest thing you can take into a sales conversation. **A1.1** covers how to position it.

</aside>

<aside>
🤝

**Co-authored with Dylan Bond, founder of LocalPipe.** The find rates and provider comparisons in this section come from a controlled test across four data providers and an analysis of roughly 7.2 million emails sent to local businesses.

</aside>

## Chapters

1. **6.1 Why the Databases You Know Fail on Local.** Coverage and saturation, and what each does to market size
2. **6.2 Sourcing From Google Maps.** What a raw record holds, and the five-stage loop
3. **6.3 Category Matching and Query Depth.** 4,000 categories, and the three techniques that multiply a market
4. **6.4 The Four Contact Buckets.** Owner direct, generic with a name, generic without, and the personal provider address the owner reads themselves
5. **6.5 Generic and Free-Provider Inboxes in Practice.** Why deleting either removes most of a reachable market
6. **6.6 Owner Identification and Enrichment.** The anchor chapter. Cross-referencing, the waterfall, find rates, and where cheap tools break
7. **6.7 Hygiene, Coverage Math and Pre-Send QA.** Filter before you enrich, size in usable sends, and the checks that have each cost somebody a campaign
8. **6.8 Building It.** The LocalPipe interface, the API driven from Claude Code, and porting to Clay

---

[6.1 Why the Databases You Know Fail on Local](06%20%C2%B7%20Building%20the%20List/6%201%20Why%20the%20Databases%20You%20Know%20Fail%20on%20Local%20db261a134ea182f883ee81916f208496.md)

[6.2 Sourcing From Google Maps](06%20%C2%B7%20Building%20the%20List/6%202%20Sourcing%20From%20Google%20Maps%2022961a134ea1837881418147008bffe5.md)

[6.3 Category Matching and Query Depth](06%20%C2%B7%20Building%20the%20List/6%203%20Category%20Matching%20and%20Query%20Depth%2058d61a134ea182d88a26811a48282034.md)

[6.4 The Four Contact Buckets](06%20%C2%B7%20Building%20the%20List/6%204%20The%20Four%20Contact%20Buckets%2039761a134ea182158d2801ccf3dda353.md)

[6.5 Generic and Free-Provider Inboxes in Practice](06%20%C2%B7%20Building%20the%20List/6%205%20Generic%20and%20Free-Provider%20Inboxes%20in%20Practice%2002561a134ea18234a35801a4f275169f.md)

[6.6 Owner Identification and Enrichment](06%20%C2%B7%20Building%20the%20List/6%206%20Owner%20Identification%20and%20Enrichment%204ad61a134ea183d7a0ea0133f0c5df9a.md)

[6.7 Hygiene, Coverage Math and Pre-Send QA](06%20%C2%B7%20Building%20the%20List/6%207%20Hygiene,%20Coverage%20Math%20and%20Pre-Send%20QA%2098561a134ea182d483d301186bb762e9.md)

[6.8 Building It](06%20%C2%B7%20Building%20the%20List/6%208%20Building%20It%2048961a134ea1834bba1681065b7f331d.md)

---

<aside>
➡️

**Next section:** [07 · Offer and Lead Magnet](07%20%C2%B7%20Offer%20and%20Lead%20Magnet%20def61a134ea1826989cb81369073bdbb.md)

Pressure-testing a client's offer, and the magnet you build once and reuse.

</aside>