# A1 · Winning the Client

<aside>
🎯

**What this section does.** Everything before the engagement exists. How to position outbound to a business that has probably been sold it before, how to find out whether their market can support what you are about to promise, and how to scope it so you are not inheriting a problem you cannot fix.

</aside>

**Applies to:** Agencies only. Read it before you take the next local client.

## Chapters

1. **A1.1 Positioning Outbound to a Local-Serving Business.** What they have already been sold, and why it failed
2. **A1.2 Size the Market Before You Sell the Retainer.** The feasibility check, and what to do when the answer is no
3. **A1.3 Scoping So You Do Not Inherit Unfixable Problems.** The qualification questions to ask before you sign

[A1.1 Positioning Outbound to a Local-Serving Business](A1%20%C2%B7%20Winning%20the%20Client/A1%201%20Positioning%20Outbound%20to%20a%20Local-Serving%20Busin%20f2161a134ea182d3a80b0144c0b59049.md)

[A1.2 Size the Market Before You Sell the Retainer](A1%20%C2%B7%20Winning%20the%20Client/A1%202%20Size%20the%20Market%20Before%20You%20Sell%20the%20Retainer%204c061a134ea18262a95a010439fefe48.md)

[A1.3 Scoping So You Do Not Inherit Unfixable Problems](A1%20%C2%B7%20Winning%20the%20Client/A1%203%20Scoping%20So%20You%20Do%20Not%20Inherit%20Unfixable%20Probl%2004b61a134ea183bb9e3181828a12629d.md)

---

<aside>
➡️

**Next section:** [03 · Scale](03%20%C2%B7%20Scale%20fb961a134ea182f5ac4b8136dfa130fa.md)

The money model, and whether a client's market can support their number.

</aside>