# 7.2 The Core Offer Gate and the Value Equation

<aside>
⚖️

**Three pass or fail tests first, then four dials.**

The tests tell you whether you have an offer at all. The dials tell you how to make it hard to refuse. Most people skip straight to the dials and spend months polishing something that failed the tests.

</aside>

## 🚦 The Gate: Three Tests

An offer has to clear all three. Two out of three is a no.

### 1️⃣ Does it solve a top-of-mind pain?

Not a pain. A pain they were already thinking about this month.

Owner-operators have a short list of things that keep them up, and it is usually cash, staff, and work they are losing. An offer that solves something genuinely useful but fifth on the list gets a polite no.

**Test it:** would they have described this problem to a friend in the last thirty days, unprompted?

### 2️⃣ Is it priced right for the value?

Not cheap. Proportionate.

The number has to look small next to what it returns. If you cannot draw that comparison in a sentence, either the price is wrong or the value is not specific enough.

**Test it:** can you say "it costs X and it returns Y" without either number being a guess?

### 3️⃣ Is it specific enough to picture?

The most commonly failed test, and the easiest to fix.

"We help local businesses grow" cannot be pictured. "We fill your Tuesday and Wednesday slots with commercial cleaning contracts within twenty minutes of your yard" can.

**Test it:** read it to somebody outside your industry. Can they repeat it back?

<aside>
🏪

**Owner-operators fail you fastest on the third test.** They are not reading carefully, they are reading between jobs. Vague is indistinguishable from irrelevant, and both get deleted.

</aside>

## 🎛️ The Value Equation: Four Dials

Once you are through the gate, an offer's strength is four things. Two you turn up. Two you turn down.

| Dial | Direction | The question it answers |
| --- | --- | --- |
| 🏆 **Dream outcome** | ⬆️ Up | What do they actually get? |
| 🤔 **Perceived likelihood** | ⬆️ Up | Do they believe it will work **for them**? |
| ⏱️ **Time delay** | ⬇️ Down | How long until they see something? |
| 😓 **Effort and sacrifice** | ⬇️ Down | How much work is this for them? |

## 🎯 Where the Fast Wins Actually Are

Founders obsess over the first dial and leave the other three untouched. That is backwards.

**Dream outcome is the hardest to move** and the one your competitors are also claiming. Everybody promises more customers. Turning that dial takes a genuinely better product.

**The other three are usually wide open**, and on local they are wide open by a mile:

- 🤔 **Belief.** Your buyer has been burned by somebody in your category. A named local reference moves this more than a bigger promise ever will
- ⏱️ **Speed.** Anything that produces a visible result in the first fortnight. Owner-operators think in weeks, not quarters
- 😓 **Effort.** Every step you remove is worth more here than almost anywhere, because the person buying is also the person doing the work

## 🔧 What Each Dial Looks Like on a Local Buyer

| Dial | Weak version | Strong version |
| --- | --- | --- |
| **Dream outcome** | "Grow your business" | "Three commercial contracts on your books by spring, all within your service radius" |
| **Belief** | "Trusted by hundreds" | "We already look after two practices on the same street" |
| **Speed** | "Results in 90 days" | "You will see the first quotes going out in week two" |
| **Effort** | "Simple onboarding" | "One 20 minute call, then we do not need anything else from you" |

The right-hand column is not cleverer writing. It is a different offer, built to be believed by somebody who is busy and sceptical.

<aside>
🏢

**You are pressure-testing their offer, not writing one.**

The client owns this decision and they will defend it, because it is their business. Run the three gate tests with them and score the four dials together, so the weakest dial is something you both found rather than something you told them.

If the offer fails the gate and they will not change it, that is a scoping problem rather than a campaign problem. A1.3.

</aside>

## 🧪 Run Your Offer Through It

Take your current offer and score each dial honestly out of five.

- 🎯 **Any dial at two or below** is where your next improvement is, regardless of what you feel like working on
- 📉 **All four at three** is a mediocre offer that no amount of copy will rescue
- 🥇 **One at five and the rest at four** is a strong offer, and now the copy matters

Do this before you write a word. Section 09 assumes you have an offer worth carrying.

## ✅ Before You Move On

- Your offer through all three gate tests, honestly
- The one-sentence version somebody outside your industry can repeat back
- Each dial scored, and the weakest one identified
- A plan to fix the weakest dial before you write copy

---

---

<aside>
➡️

**Next:** [7.3 Reversing the Risk](7%203%20Reversing%20the%20Risk%2004561a134ea183f583f081ab9eb0e376.md)

The guarantee ladder, and what a local owner will actually believe.

</aside>