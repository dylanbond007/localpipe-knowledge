# A2.2 Whose Domains, Whose Infrastructure

<aside>
🏛️

**Decide who owns the domains before you buy them, not when the engagement ends.**

This is a five minute conversation at onboarding and a genuinely unpleasant one at churn.

</aside>

## 🔑 The Two Models

<aside>
🏢

**You own the infrastructure**

Your account, your domains, your inboxes. The client is renting capacity.

Simpler for you, faster to launch, and everything goes with you when it ends.

</aside>

<aside>
🏪

**They own it**

Bought in their name, on their card, managed by you.

Slower to set up, and they keep a warmed estate if you part ways.

</aside>

**Most agencies run the first.** It is operationally simpler and it lets you launch on already-warmed capacity rather than waiting two weeks.

**The second is worth offering** to clients who ask, or to larger engagements, because it removes a real objection. Somebody who has been burned before hears "you keep nothing if this ends" and reacts to it.

## 📝 What to Agree in Writing

Whichever model, four things:

- 🏷️ **Who pays for and owns the domains**
- 📤 **What transfers at the end**, and what does not
- 📇 **Who owns the list.** This is the one people forget, and it matters more than the domains
- 🔗 **What happens to a warmed estate** if the engagement pauses rather than ends

## 📇 The List Is the Real Asset

Domains are cheap and replaceable. A properly sourced, enriched, verified and suppressed list of an entire local market is not.

If you built it, say who owns it before the question gets asked in anger. Reasonable positions exist on both sides. An unstated position is what causes the problem.

Most workable arrangement: they keep the contact data for the market you worked, and you keep the process, the scoring and the campaign assets.

## 🚧 Never Send From Their Main Domain

Worth stating explicitly with a client, because they will ask why you are buying lookalikes.

If their company domain gets damaged, their invoices stop arriving and their customers cannot reach them. That is not a marketing problem, it is an operations problem, and it lands on you.

Say it once, clearly, at onboarding. It also demonstrates that you know what you are doing.

## 🌐 Lookalikes Should Look Like Them

The domains carry their brand, not yours.

- ✅ `gettheircompany.com`, `theircompanyhq.com`
- ❌ Anything with your agency name in it

A recipient who looks up the sender should find the client, and the sending identity should be somebody at the client's business, not at your agency. You are running the machine, not fronting it.

## ✅ Before You Move On

- An ownership model chosen and written down
- Agreement on what transfers at the end, including the list
- Lookalike domains carrying the client's brand
- The never-send-from-the-main-domain rule explained once, clearly

---

<aside>
➡️

**Next:** [A2.3 Running Several Clients at Once](A2%203%20Running%20Several%20Clients%20at%20Once%201d861a134ea183e1bf8101d1422f8a30.md)

What breaks first, and in what order.

</aside>