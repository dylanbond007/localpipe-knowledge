# A2.3 Running Several Clients at Once

<aside>
🏗️

**Ten clients is not one program ten times.**

It is ten estates, ten lists, ten suppression files and ten reply windows, and the things that break are almost always organisational rather than technical.

</aside>

## 🧱 Separate Everything

The rule that prevents most problems: **nothing is shared between clients except your process.**

- 📧 **Separate sending estates.** One client's bad month never touches another's deliverability
- 📇 **Separate lists**, even where markets overlap
- 🚫 **Separate suppression files.** See A2.4
- 📊 **Separate reporting**, on the same template

Sharing infrastructure across clients looks efficient and creates a single point of failure that takes everybody down at once.

## 📋 Standardise the Process, Not the Campaign

The only thing that scales is doing the same steps in the same order every time.

- 🗂️ **One folder structure**, identical for every client
- 🏷️ **One naming convention.** `client-category-metro-bucket-date`
- ✅ **One QA checklist**, run every time
- 📅 **One operating rhythm**, on the same days

What does not standardise is the offer, the angle or the copy. Those are specific to the client and a templated version is visible from the first line.

## 🕒 The Rhythm Across a Book of Clients

- 🕐 **Daily, thirty minutes total.** Bounce and reply rate across every client. You are looking for anomalies, not reading detail
- 📅 **Weekly, per client.** Placement test, batch rotation, lagging numbers
- 🗓️ **Monthly, per client.** Scale or kill decisions, list refresh, the report

The daily check is one screen across all accounts. If you are opening ten dashboards every morning, you have an instrumentation problem and it will not survive client eleven.

## 🚨 What Breaks First

In the order it usually happens.

**Reply handling.** At three clients you can catch everything yourself. At eight you cannot, and the window slips on the accounts that are quietest, which are usually the ones closest to churning.

**List freshness.** Lists get built once and reused for months, bounce creeps up, and nobody notices because each client is individually only slightly worse.

**Copy drift.** Client four's copy starts looking like client two's, because you wrote it in the same afternoon. Local markets are small enough that two clients in the same metro can end up sounding identical.

**Reporting.** It becomes activity reporting because that is quicker, and then clients start judging you on emails sent.

## 🧪 The Advantage of the Book

The one real benefit of many clients, and the thing a single business cannot do.

**You can pool test learning across clients in the same vertical.** A single local market is too small to run a proper test in. Three clients in the same trade give you a readable sample.

What that lets you do:

- Test an angle across three markets at once and get an answer in a fortnight
- Carry a proven opener into client four on day one instead of month three
- Build a benchmark for what normal looks like in a trade, so you spot an underperforming account early

**Keep the data separate. Pool the learning.** Section 8.3.

## ✅ Before You Move On

- Separate estates, lists and suppression per client
- One folder structure, naming convention and checklist across all of them
- A single daily view across every account
- A deliberate way of carrying learning between clients in the same vertical

---

<aside>
➡️

**Next:** [A2.4 Suppression and Territory](A2%204%20Suppression%20and%20Territory%2033261a134ea183628def01d83ddd2bec.md)

Per client, and why it is never shared.

</aside>