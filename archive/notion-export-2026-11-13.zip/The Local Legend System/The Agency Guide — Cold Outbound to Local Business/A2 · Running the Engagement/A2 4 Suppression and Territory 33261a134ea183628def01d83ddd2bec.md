# A2.4 Suppression and Territory

<aside>
🚫

**Suppression is per client. It is never shared between them.**

One client's customer list, quote pipeline and do-not-contact file belongs to that client alone, and merging them would be both a commercial and a data problem.

</aside>

## 📇 What Goes on a Client's Suppression List

Built at onboarding, and it only ever grows.

- 🤝 **Their existing customers.** The single most damaging miss
- 💬 **Open quotes and live conversations.** Somebody mid-negotiation should not receive a cold email
- ✋ **Anyone who has unsubscribed or asked to stop**, ever, across any campaign you have run for them
- 🕒 **Anyone contacted in the last six months** on their behalf
- 🤝 **Their suppliers, partners and people they know personally**

Load it into every sending domain for that client. Not a note in a spreadsheet.

## 🔒 Why It Stays Separate

Three reasons, and any one of them is sufficient.

- 💼 **It is their data.** A customer list is commercially sensitive and it was given to you for one purpose
- ⚖️ **Merging it creates obligations** you do not want, around what you hold and why
- 🎯 **It would be wrong anyway.** Client A's customer is a perfectly good prospect for client B in a different trade. Suppressing them would cost client B real market

Keep one file per client, in their folder, and never build a master.

## 🗺️ Territory Between Clients in the Same Trade

The harder question, and it is a **commercial** decision rather than a suppression one.

If you run two commercial cleaners in the same metro, they are bidding for the same contracts, and both will find out.

Three workable positions:

- 🚫 **Exclusivity by trade and metro.** One cleaner per city. Simplest, most defensible, and it costs you revenue
- 🗺️ **Split by geography.** Different sides of the city, enforced as a list filter
- 🏷️ **Split by segment.** One does dental and medical, the other does hospitality and retail

**Whichever you pick, tell both clients before you sign the second one.** They will find out, and finding out on their own is much worse than being told.

## ⚠️ What Not to Do

- ❌ **Take two direct competitors in the same trade and metro without telling either.** It ends the relationship and the referral, and local markets talk
- ❌ **Use one client's data to benefit another.** Customer lists, pricing, what worked in their pipeline
- ❌ **Run overlapping campaigns into the same businesses** from two clients in the same fortnight. The recipient notices even if the clients do not

## 🧮 Overlap Is Fine Across Trades

Worth saying plainly, because the caution above can be over-applied.

A dental practice can reasonably hear from your cleaning client and your IT client in the same quarter. They are different offers solving different problems, and the practice is a legitimate prospect for both.

Space them out, keep the campaigns separate, and do not mention one client to the other.

## ✅ Before You Move On

- One suppression file per client, never merged
- All five categories collected at onboarding and refreshed quarterly
- A stated position on competing clients in the same trade and metro
- Both clients told before the second one signs

---

<aside>
➡️

**Next:** [A2.5 Reporting That Credits the Work](A2%205%20Reporting%20That%20Credits%20the%20Work%2022a61a134ea182ce856081c1d8179026.md)

Opportunities rather than replies, and closing the attribution gap.

</aside>