# A2.6 The Handoff Conversation

<aside>
🤝

**This conversation happens at onboarding, or it happens as an argument in month four.**

The most common reason local engagements fail is that nobody on the client side works the replies fast enough, and the client experiences that as poor lead quality.

</aside>

## 🕒 Why It Is Different Here

A software client has a sales team, a watched inbox and a process. Your reply lands in a machine built to catch it.

A local client is an owner under a sink at two in the afternoon. The reply arrives, they see it at seven, they answer next morning, and the window has closed.

**That is structural, not a failure of client quality.** Which means you can predict it, and design around it.

## 🗣️ Have the Conversation Before You Build

Five decisions, agreed at onboarding and written into the engagement.

**1. Who calls.** A name, not a team. A backup for holidays, explicitly a backup.

**2. The window.** Written down. "Inside one hour in working hours, first thing next morning after 6pm."

**3. Where the alert lands.** Somewhere checked within minutes. A text or a push, not another email.

**4. What they say.** You write the opener. Do not assume they know how to handle a reply to a campaign they did not write.

**5. How it is measured.** Time from reply to first attempt, in the monthly report from day one.

## 💬 How to Raise It Without Sounding Like a Get-Out

Framing matters, because raised badly this sounds like pre-blaming them.

> "The single biggest thing that decides whether this works is how fast somebody rings back. Not the emails. I have seen identical campaigns produce completely different results purely on that. So let us agree who that is and what fast means, and I will show you the number every month so we both know."
> 

That is a specialist telling them where the risk actually sits, which is what they are paying for.

## 🧯 When They Cannot Do It

Some clients genuinely cannot. An owner with four crews is not taking calls at 2pm.

Three honest options, in order:

- 👥 **Somebody else makes the first call.** A setter, theirs or yours. The highest-leverage thing you can add to a local engagement
- 📉 **Reduce volume** to what the attention can convert. Twenty replies answered well beats fifty answered badly
- 🛑 **Do not take the work.** Manufacturing intent that dies burns a finite market and the blame lands on you

## 📄 Give Them the Pre-Call Page

One build that removes a large part of the risk.

A pre-call page, running as a short checklist with a video from whoever takes the call, lifts show rate substantially and means a slightly slow callback is less fatal, because the prospect arrives already educated.

It is also a visible deliverable, which makes the value of the engagement obvious in a way a sending dashboard never does. Section 11.3.

## ✅ Before You Move On

- A named person and a written window, agreed before the build
- Alerts landing somewhere they check within minutes
- An opener you wrote, not one they improvise
- Time to first attempt in the report from month one
- A plan for what happens if they cannot meet the window

---

<aside>
➡️

**Next:** [A2.7 When the Market Runs Out Mid-Retainer](A2%207%20When%20the%20Market%20Runs%20Out%20Mid-Retainer%20df461a134ea182e4976d8174fc88dca1.md)

The conversation, and the expansion order.

</aside>