# A2.5 Reporting That Credits the Work

<aside>
📊

**Local deals close on the phone, weeks later, with no digital trail.**

So the default report under-credits your work, and clients cancel programs that were producing. This page is how to report so that what happened is visible.

</aside>

## 🎯 Report Opportunities, Not Activity

Three tiers of number, and only one belongs in a client report.

- 🔧 **Activity.** Emails sent, contacts reached. Useful to you, alarming to them
- 📊 **Leading indicators.** Bounce, reply rate, contacts per positive. How you diagnose
- 💰 **Opportunities.** Qualified conversations with people who could realistically buy. **This is the report**

Agree the definition of an opportunity at onboarding, in one sentence, and never change it mid-engagement without saying so.

## 🧾 The Monthly Report

Five lines and two sentences. Anything longer gets skimmed.

- 📨 Contacts reached
- 💬 Positive replies, and contacts per positive reply
- 📅 Meetings booked and held
- ✅ Opportunities, by the agreed definition
- 💷 Closed business, where their cycle allows

Then one sentence on what changed, and one on what you are changing next.

**Leave out** open rates, emails sent, and anything that sounds like effort rather than outcome.

## 🔗 Solving the Attribution Gap

The trail ends at the reply. Four moves that close it.

**1. Record the source at the moment of reply.** Campaign, bucket, angle. The last moment it is unambiguous.

**2. Pass an identifier through the booking.** A meeting that arrives with no source gets attributed to nothing.

**3. Reconcile monthly.** Take their closed business and walk it back against your reply log.

**4. Get them to ask.** "How did you hear about us?" on their intake, and you see the answer.

## ⏱️ Instrument the Handoff, and Report It

The number that protects you.

**Time from reply to first call attempt**, measured and shown every month.

If the client is slow, this turns a vague complaint about lead quality into a shared fact. If they are fast, it credits them. Either way it stops the month-four argument where they believe the leads were poor and you believe the follow-up was.

Put it in from month one. Introducing it after a dispute looks defensive.

## 📅 Report the Lag Honestly

Revenue arrives on a delay longer than the reporting cycle. Month one is spend, month two brings meetings, month three brings revenue from month two.

Show leading indicators alongside revenue for the first quarter, or somebody will draw a conclusion from a number that cannot yet exist.

## 🗺️ Report Market Depletion Before They Notice

Specific to local, and it protects the relationship.

Every month, show how much of the sourced market has been contacted. When it runs low, that is a planned conversation about expansion rather than a surprise about falling volume.

A client who watches the market deplete on a chart understands the ceiling. One told in month five thinks you have run out of ideas.

## ✅ Before You Move On

- One agreed definition of an opportunity
- A five-line monthly report with no activity metrics
- Source recorded at the moment of reply
- Time to first call attempt reported from month one
- Market depletion shown every month

---

<aside>
➡️

**Next:** [A2.6 The Handoff Conversation](A2%206%20The%20Handoff%20Conversation%2016b61a134ea18388aeef01a5878d99de.md)

The one that decides whether your work looks successful.

</aside>