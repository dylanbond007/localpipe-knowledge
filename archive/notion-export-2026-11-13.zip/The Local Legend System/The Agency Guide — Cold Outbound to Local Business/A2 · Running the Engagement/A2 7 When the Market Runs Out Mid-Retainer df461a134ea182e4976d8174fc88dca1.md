# A2.7 When the Market Runs Out Mid-Retainer

<aside>
🗺️

**Local markets run out.**

This is the conversation you have when it happens, and the work you do in advance so that it is not a surprise.

</aside>

## 📉 What Running Out Looks Like

Gradual, and easy to misread as a campaign problem.

- Volume falls because there are fewer new contacts to add
- Reply rate holds but absolute replies drop
- You are re-contacting people sooner than six months
- The client asks why last month was quieter

**Check the depletion figure before you touch the copy.** At 80% of a sourced market contacted, nothing is broken. The market is nearly worked.

## 🛡️ Prevent the Surprise

**Say it at the sale.** A1.2 puts the months-of-volume number in the proposal, which makes month five a planned event.

**Show it monthly.** A client who has watched the number fall for four months is ready. One seeing it for the first time is not.

## 🔍 The Expansion Order

Cheapest and least disruptive first.

**1. 📬 Contact buckets.** Working generic-with-name and generic-no-name alongside owner-direct roughly doubles usable contacts from records already sourced and paid for. Section 6.4

**2. 🏷️ Adjacent categories.** Who else has the same problem? Usually the biggest unlock, and the sourcing cost is trivial

**3. 🗺️ Geography.** Widen the radius or add the next town. Check it against what they can service, because winning work they cannot deliver is worse than winning nothing. Section 12.3

**4. 🎚️ Loosen qualification.** Smaller businesses, no website, lower review counts. Works, lowers conversion, do it knowingly and tell them

**5. 🕒 Time.** A market worked six months ago is workable again with a new angle. Not next month, but it is not gone

**6. 🛠️ A second channel.** Direct mail and phone reach records email could not, and they do not deplete the same way. Section 12

## 🗣️ How to Have the Conversation

Bring the number and the plan in the same meeting. Never the number alone.

> "We have contacted about 80% of the market we sourced, which is what we projected in month one. Next: buckets two and three add roughly X contacts from records we already own, and adjacent categories add another Y. That gives us about Z more months. Beyond that we are into geography, which is a conversation about what you can service."
> 

That is a specialist managing a known constraint. The same facts without the plan sounds like running out of road.

## 🛑 When There Is Genuinely Nothing Left

Sometimes outbound has done its job in this market. Say so.

Propose the alternatives: a shift to referral and partner work, a different segment, or a pause and return in six months with a new angle.

An agency that says "this channel has given you what it has" keeps the relationship and usually some of the revenue. One that keeps sending into an exhausted market loses both.

## ✅ Before You Move On

- A depletion figure in every monthly report
- The months-of-volume number stated at the sale
- The six-step expansion order ready before you need it
- A conversation that always pairs the number with the plan

---

<aside>
➡️

**Next:** [A2.8 Churn and Scope Creep](A2%208%20Churn%20and%20Scope%20Creep%2091161a134ea182258b1601795aeefe75.md)

The two ways these engagements end badly.

</aside>