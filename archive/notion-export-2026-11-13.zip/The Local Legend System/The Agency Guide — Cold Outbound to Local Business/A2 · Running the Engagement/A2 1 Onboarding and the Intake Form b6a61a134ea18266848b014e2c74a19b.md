# A2.1 Onboarding and the Intake Form

<aside>
📋

**Everything you need before you build anything, collected once.**

Chasing these one at a time over three weeks is how a fifteen day build becomes a six week one.

</aside>

## 📥 What You Need From Them

Send this as a form, not as an email thread. A thread invites partial answers.

**About the business**

- What they sell, in their words, and what a typical contract is worth
- Which categories of customer they serve, and which they will not
- The geography they can actually service, and the edge beyond which a job loses money
- Capacity. How much new work can they absorb in the next quarter

**About their customers**

- Their best five to ten customers, and what those have in common
- Their worst three, and what those had in common
- Why customers choose them over the competitor down the road
- What customers complain about

**Proof**

- Named references you are allowed to use, and in which areas
- Any numbers they can stand behind
- Certifications, accreditations, insurance, anything that answers a trust question

**Operational**

- Who answers replies, by name, and their working hours
- Where that person wants to be alerted
- Their calendar, and how far ahead it is realistically open
- Existing customers, open quotes and anyone not to contact

## 🚫 The Suppression List Is Not Optional

Get it on day one, in a spreadsheet, before you build anything.

Cold emailing a client's existing customer is the fastest way to lose the account, and it is entirely avoidable. Ask for customers, open quotes, live conversations, suppliers and anyone they know personally.

Then ask again at every quarterly review, because it grows.

## 📞 The Onboarding Call

The form gets you the facts. The call gets you the things they would never write down.

Forty-five minutes, and you are listening for four things:

- 🗣️ **How they talk about their customers.** Their vocabulary goes straight into the copy
- 😤 **What annoys them about their market.** That is usually where the sharpest angle is
- 🏆 **What they are proud of.** It tells you what they think wins work, which may differ from what actually does
- 😐 **What they are sceptical about.** Surface it now rather than in month two

Record it. You will mine it for copy for months.

## ⚠️ What They Will Be Wrong About

Expect these, and handle them gently.

**Their best customers.** Most owners name their biggest or their favourite rather than their most profitable and least painful. Ask about hassle and payment terms explicitly, or you will build an ICP around clients who are quietly unprofitable.

**Their market size.** Almost always overestimated, sometimes wildly. That is what A1.2 is for.

**Their response time.** Everybody says they answer quickly. Agree a number and measure it from week one rather than trusting the estimate.

**Who decides.** They will describe a decision maker based on the two deals they remember, not the twenty they closed.

## ⏱️ Set Expectations in the Same Conversation

Four things, said out loud during onboarding, prevent most later arguments.

- 📅 **The timeline.** Nothing sends for two weeks. First meetings around week five or six
- 📞 **The reply window.** Named person, agreed time, measured
- 📊 **What gets reported**, and when. Leading indicators at day forty-five, cost per meeting at day ninety
- 🗺️ **The market ceiling** and the expansion path, from A1.2

## ✅ Before You Move On

- A completed intake form, not a half-answered thread
- A suppression list in hand before the build starts
- A recorded onboarding call
- A named person for replies, with a window agreed
- The timeline and the market ceiling stated out loud

---

<aside>
➡️

**Next:** [A2.2 Whose Domains, Whose Infrastructure](A2%202%20Whose%20Domains,%20Whose%20Infrastructure%208da61a134ea182d4bc97816c11e28011.md)

Ownership, and what happens when it ends.

</aside>