# A2.8 Churn and Scope Creep

<aside>
🔄

**Two ways these engagements end badly, and both are visible weeks in advance.**

Churn is usually an expectations problem rather than a results problem. Scope creep is a boundaries problem that started as goodwill.

</aside>

## 🚩 The Churn Signals

In the order they appear.

- 🕒 **Reply response time slipping.** The earliest signal, and it precedes everything else
- 📅 **Meetings not being held.** They are booking and not turning up to their own calls
- 💬 **Questions changing** from "how do we improve this" to "what am I paying for"
- 🔇 **They stop reading the report**
- 🗓️ **A review gets rescheduled twice**

**The first one is the tell.** A client who has stopped calling back within the window has partly disengaged, and results follow within a month.

## 🛠️ What to Do About It

Raise it early, using the number rather than a feeling.

> "Time to first call has gone from forty minutes to most of a day over three weeks. That will show up in booked meetings before long. Has something changed at your end, or is this something we should take off you?"
> 

That names the real cause before results fall, offers a solution rather than a complaint, and opens the door to selling the calling as a service.

## 🧮 The Most Common Root Cause

Almost always a gap between what they expected and what was agreed.

Which is why A1.3 asks for their definition of a good month in numbers, and A1.2 puts the market ceiling in the proposal.

**If you are churning clients at month four consistently, the problem is in your sales conversation rather than your delivery.**

## 🪣 Scope Creep, and How It Starts

Never as a demand. Always as a favour.

- "While you are in there, could you look at our website?"
- "Can you follow up on this one for me?"
- "Could we get a quick report on the LinkedIn side too?"

Each is small, reasonable and twenty minutes. Six of them is a day a month unpaid, and they never get removed.

## 🚪 Holding the Line Without Being Difficult

- 📋 **Define the deliverable precisely** at onboarding. Not "outbound", but what you produce and what you do not
- ✅ **Say yes to the first one**, deliberately and visibly. Goodwill is worth having
- 💬 **Name the pattern on the third.** "Happy to do this one. It is outside what we agreed though, so if it is becoming regular let us talk about what the engagement covers"
- 🧾 **Have somewhere for the extra work to go.** A clear alternative makes the boundary feel like a route rather than a refusal

## 🔄 Reactivating a Lapsed Client

Worth doing, and almost nobody does it.

A client who left after six months has a warmed estate, a built list and a market that has now rested. That is a far cheaper restart than a new client.

> "The market you worked is workable again now, and the infrastructure is still there. Different angle this time. Worth a look?"
> 

Diary it three to six months after any engagement ends, whatever the reason.

## ✅ Before You Move On

- Response time watched as the leading churn signal
- A conversation triggered by the number, not by a feeling
- A precisely defined deliverable at onboarding
- A named place for out-of-scope work to go
- Lapsed clients diaried for reactivation

---

<aside>
➡️

**Next:** [12 · Beyond the Inbox](../12%20%C2%B7%20Beyond%20the%20Inbox%20b9661a134ea182a4953801274a94aed3.md)

Direct mail, the phone, territory and referral loops.

</aside>