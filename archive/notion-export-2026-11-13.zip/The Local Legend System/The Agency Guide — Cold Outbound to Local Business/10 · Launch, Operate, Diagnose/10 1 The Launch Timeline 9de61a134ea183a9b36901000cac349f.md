# 10.1 The Launch Timeline

<aside>
🚀

**Launch is not pressing send.**

It is a sequence that started two weeks earlier when the inboxes went into warm-up. This page is what happens in between, and what happens in the six weeks after.

</aside>

## 🛣️ Two Lanes

Run both from day one. One of them needs warm-up. One of them does not.

<aside>
📧

**The email lane**

Warming in the background for two weeks, then a soft launch, then a ramp.

First meetings around week five or six.

</aside>

<aside>
📞

**The fast lane**

No warm-up required. Live in week two.

On local this is **the phone and direct mail**, not LinkedIn.

</aside>

**Why the fast lane is different here.** The standard advice is to run LinkedIn while email warms. Tier one local owners are mostly not on LinkedIn, so that lane is empty. The phone works from day one, and direct mail needs nothing but an address, which you already have on every record.

Point the fast lane at your **A tier only**. It is a manual channel, so spend it on the records that justify it. Section 5.3.

## 📅 The Six Weeks

| When | Email lane | Fast lane |
| --- | --- | --- |
| **Week 1** | Domains bought, inboxes into warm-up. Nothing sends | Nothing yet. You are building |
| **Week 2** | Still warming. Build the list, write the copy | 📞 Start calling your A tier. First conversations happen here |
| **Week 3** | Soft launch at 10 to 20% of target volume | Calls continue. First direct mail drops |
| **Week 4** | Ramp if healthy. 30 to 50% increases | Follow up on mail that has been scanned or opened |
| **Weeks 5 to 6** | Full volume. First email meetings landing | Steady state, feeding the same calendar |

## 🐣 Soft Launch

**Start at 10 to 20% of your target volume.** Watch two things daily: bounce rate against the 2% bar, and inbox placement using a real seed test rather than a dashboard number.

**Change nothing during soft launch.** The temptation to tweak the copy after forty sends is strong and always wrong. You do not have enough data to learn from, and changing variables mid-test means the soft launch taught you nothing.

What you are checking is mechanical, not creative: does it deliver, does it land in the primary inbox, do the merge fields render, does the reply routing work.

## 📈 Ramping

If bounce is under 2% and placement is holding, climb in **30 to 50% increases**, a few days apart.

- 🚦 **Ramp the volume, not the number of campaigns.** Get one to full volume before you add the second
- 🛑 **Stop climbing the moment bounce moves.** Hold, investigate, then resume
- 📦 **Launch in weekly batches** rather than one continuous stream, so a bad week is visible instead of averaged away
- ⏳ **Full volume by week five or six.** Faster than that and you are gambling with the infrastructure you just spent two weeks preparing

## 📞 Have the Reply Plan Ready Before the First Reply

Replies will arrive during soft launch, at low volume, which is exactly when people are least prepared for them.

Before the first send:

- 👤 Name the person who calls back
- ⏱️ Agree the window. On local it is inside the hour
- 🔔 Put the alert where that person actually looks
- 📝 Have the first-call opener written

Section 11 covers all of it. Do not launch without it, because the first ten replies are the most expensive ones you will ever manufacture and the easiest to waste.

## ✅ Before You Move On

- Both lanes planned, with the phone live in week two
- A soft launch volume set at 10 to 20%
- A rule that nothing changes during soft launch
- Weekly batches rather than a continuous stream
- A named person and a response window agreed before send one

---

<aside>
➡️

**Next:** [10.2 Pre-Launch and Copy QA](10%202%20Pre-Launch%20and%20Copy%20QA%20a7961a134ea1824280c80177c6a8de1b.md)

One merged checklist, run before the first message leaves.

</aside>