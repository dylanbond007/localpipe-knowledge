# 10.4 The Four-Pillar Diagnostic

<aside>
🩺

**Work bottom-up. The break is almost always lower than you think.**

The instinct when replies are bad is to rewrite the copy. On local that is the right answer about one time in ten.

</aside>

<aside>
🏢

**There is a fifth pillar on a client engagement, and it sits above all four: did anybody call them back?**

Before you diagnose anything, check time from reply to first attempt. A campaign that looks broken is very often a campaign whose replies sat for two days. Check that first, because it is the fastest thing to confirm and the most common cause. A2.5 and A2.6.

</aside>

## 🪜 The Four Pillars, In Order

You check them in this order and you do not move up until the one below checks out.

| Pillar | The question | How often it is the cause on local |
| --- | --- | --- |
| 1️⃣ **Deliverability** | Is it reaching the inbox at all? | Common, and invisible unless you test |
| 2️⃣ **Prospect** | Are these the right people, and is this the whole market? | **Most common by a distance** |
| 3️⃣ **Offer and copy** | Is the pitch right, and is it written well? | Sometimes, and usually the offer rather than the copy |
| 4️⃣ **Scale** | Are you sending enough to know anything? | Frequently, and almost never diagnosed |

## 1️⃣ Deliverability

**Check first, because nothing else can be measured if this is broken.**

- 🔬 Run a real placement test to seed inboxes. Do not trust a dashboard
- 💥 Check bounce against the 2% bar
- 📖 Read the actual bounce messages. Spam and blocklist means reputation. Mailbox does not exist means list
- 📊 Check whether the reply rate fell across **all** campaigns at once, which points to infrastructure rather than to any single campaign

**If this is the problem:** stop sending, do not rewrite anything, and work through 4.7.

## 2️⃣ Prospect

Two questions here, and the first one is specific to local.

### 🗺️ Did you source the whole market?

This is the question nobody asks, and on local it is often the answer.

If you queried once per city, skipped pagination, used keyword search instead of category matching, or worked only owner-direct addresses, you are running a campaign against a fraction of the market and treating the result as representative.

- Did you paginate past page one?
- Did you stack query phrasings?
- Did you decompose the geography?
- Are you working all four contact buckets?

Sections 6.3 and 6.4. A campaign against 15% of a market produces numbers that tell you nothing about the market.

### 🎯 Are these the right people?

- Is the category right, or adjacent to right?
- Is the tier right? Tier one and tier two behave completely differently
- Are you scoring, and are the A tier records performing better than the C tier? If they are not, the rubric is wrong
- Are the qualified conversations coming from one segment and the noise from another?

**If this is the problem:** go back to 5.1 and 6.3 before you touch anything else.

## 3️⃣ Offer and Copy

Only reachable once one and two check out.

**Test the offer first**, because it is the bigger lever and the harder thing to admit.

- Does it pass the three gate tests in 7.2?
- Which of the four dials is weakest?
- Does the reply pattern say "not interested" or "not relevant"? Not interested is an offer problem. Not relevant is a pillar two problem
- Are negative replies clustering on price, timing, or already-have-someone?

**Then the copy**, and specifically:

- Run the could-be-anyone test on every version
- Check the merge fields actually rendered on live sends, not on your test record
- Confirm the bucket copy went to the right buckets
- Read the sent version aloud, not the draft

## 4️⃣ Scale

The pillar people skip, and it invalidates conclusions drawn from the other three.

> **Have at least 500 contacts been through this campaign?**
> 

If not, you do not have a result. You have a sample, and reacting to it is how people rewrite working copy and kill working campaigns.

At one positive reply per 50 to 100, three hundred contacts might produce three replies. Three is noise. Section 8.3.

## 🧭 The Decision Tree

| Symptom | Look here first |
| --- | --- |
| Bounce above 2% | List quality, then reputation. Pillar 1 |
| Reply rate fell across every campaign at once | Infrastructure. Pillar 1 |
| Replies come but mostly "not relevant" | Targeting. Pillar 2 |
| Replies come but mostly "not interested" | Offer. Pillar 3 |
| Almost no replies at all, deliverability fine | Market coverage first, then offer. Pillar 2, then 3 |
| Good replies, few meetings booked | Response speed, not copy. Section 11.1 |
| Meetings booked, nobody qualified | Targeting. Pillar 2 |
| Everything looks flat and volume is low | Pillar 4. You do not have a result yet |

## 🔧 Fix One Thing

Whatever the diagnosis, change **one variable** and rerun.

Changing four things at once and seeing improvement tells you nothing about which one worked, which means you cannot repeat it. On a finite market, where you only get a handful of test rounds, that is an expensive way to be right by accident.

## ✅ Before You Move On

- A habit of checking deliverability before touching copy
- The market-coverage question asked as part of pillar two
- A minimum of 500 contacts before drawing any conclusion
- One variable changed per round

---

---

<aside>
➡️

**Next:** [11 · Replies to Booked Meetings](../11%20%C2%B7%20Replies%20to%20Booked%20Meetings%20d2261a134ea182fc9a6801299e1fe472.md)

Why on local the reply is a cue to pick up the phone.

</aside>