# 10.3 The Numbers to Watch

<aside>
📊

**Four numbers tell you what to fix today. Four tell you whether the system is healthy.**

Most people watch the wrong four and react to noise.

</aside>

## ⚡ The Four Leading Numbers

Checked daily, in about five minutes per client. You are looking for anomalies rather than reading detail.

| Number | Healthy | What it means when it moves |
| --- | --- | --- |
| 💥 **Bounce rate** | Under 2% | List problem, or reputation problem. Read the bounce messages to tell which. Section 4.7 |
| 📬 **Reply rate** | Against your own baseline | A drop with nothing else changed usually means placement, not copy |
| 👍 **Positive reply share** | Rising or steady | This is message-market fit. Falling means the offer or the targeting drifted |
| 🎯 **Contacts per positive reply** | 1 in 50 to 100 | The single most useful number you have. Everything upstream lands here |

## 🐢 The Four Lagging Numbers

Checked weekly or monthly. These tell you whether the machine is actually producing.

- 📞 **Reply to booked meeting.** Below half and the problem is usually response speed, not wording
- 🤝 **Show rate.** Below 70% and your confirmation layer is thin
- ✅ **Qualification rate.** Low means you are booking the wrong businesses. A targeting problem
- 💰 **Opportunities per month**, using your own definition of an opportunity. The number that actually matters

<aside>
🏢

**Only one of these eight belongs in a client report.**

The leading numbers are how you diagnose. The lagging numbers, and opportunities in particular, are what you report. Send a client a bounce rate and a send count and you have invited them to judge you on activity. A2.5 covers the five-line report.

</aside>

## ⏱️ The Rhythm

- 🕔 **Daily, five minutes.** The four leading numbers. Nothing else
- 📅 **Weekly, thirty minutes.** Lagging numbers, a real placement test, a sample of bounce messages, batch rotation
- 🗓️ **Monthly, one to two hours.** Full review. Scale, optimise or kill decisions. Rerun the money model against actual figures

Five minutes a day is genuinely enough when nothing is wrong. The weekly half hour is where problems get caught early, and it is the one people skip.

## 🚦 Scale, Optimise or Kill

Three states. One right move each, and the commonest mistake is doing the opposite.

<aside>
📈

**Hitting the benchmark → Scale**

Do not get clever. Send more of exactly the same thing.

Expand buckets first, then adjacent categories, then geography. Section 3.3.

**The mistake:** optimising a winner and breaking it.

</aside>

<aside>
🔧

**Close but under → Optimise**

Work down the stack, one variable at a time.

Deliverability, list, offer, copy. In that order. Section 10.4.

**The mistake:** changing four things at once and learning nothing.

</aside>

<aside>
🛑

**Well under, after a full test → Kill**

Stop sending. A campaign that is badly underperforming is not just failing to produce, it is consuming a finite market and generating complaints.

**The mistake:** adding a fourth email to a campaign that three could not carry.

</aside>

## 💬 Negative Replies Are Data

The instinct is to delete them. They are the cheapest market research available.

- 🚫 **"We already have someone"** → the market is served, so your angle needs to be about switching rather than solving
- 💸 **"Too expensive"** at volume → a positioning problem, not a pricing one
- 🤷 **"Not relevant"** repeatedly → a targeting problem. Go back to 5.1
- 😠 **Genuinely annoyed** → check your suppression and how recently you contacted that market

Log the reason on every negative reply. After fifty you will have a clearer picture of your market than any research would give you.

## 🏪 One Local-Specific Warning

Your market is finite, which changes what a bad month costs.

In a large market, a poorly performing campaign wastes budget. Here it also **consumes contacts you cannot get back for months**. That makes killing a bad campaign more urgent than it would be elsewhere, and it makes the daily five minutes worth more than it looks.

## ✅ Before You Move On

- The four leading numbers visible daily
- A reply-rate baseline recorded so you can spot a drop
- A weekly slot booked, with a real placement test in it
- A decision rule for scale, optimise or kill, written down in advance
- Negative reply reasons being logged

---

<aside>
➡️

**Next:** [10.4 The Four-Pillar Diagnostic](10%204%20The%20Four-Pillar%20Diagnostic%2048061a134ea183d5a56001da9e4c3034.md)

Finding the real break, bottom-up.

</aside>