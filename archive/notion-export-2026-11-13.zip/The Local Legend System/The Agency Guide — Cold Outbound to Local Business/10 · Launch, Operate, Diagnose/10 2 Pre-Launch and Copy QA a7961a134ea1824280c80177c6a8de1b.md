# 10.2 Pre-Launch and Copy QA

<aside>
✅

**Most of this takes minutes. Every item on it has cost somebody a campaign.**

Run the whole thing before the first message of a campaign leaves. Not after the first problem.

</aside>

## 🏗️ Infrastructure

- ⏳ Warm-up complete on every mailbox, minimum two weeks
- 🪪 Authentication verified on every sending domain
- 🔌 Inboxes connected to the sequencer and warm-up confirmed still running
- 📮 Bucket four routed to its own estate, not the main one
- 📊 Daily sending limits set per inbox, not per campaign

## 📋 List

- ✅ Verified, with anything you resolved yourself re-checked
- 🌐 Domain-level deduplication run after enrichment
- 🚫 Suppression loaded across every sending domain. Customers, open deals, unsubscribes, anyone contacted in the last six months
- 🎚️ Scoring applied and the D tier removed
- 🪣 No record in more than one bucket
- 📅 Pulled fresh, two or three days before launch

<aside>
🔍

**The two checks that catch the most, by a wide margin.**

**1. Sample twenty to thirty owner names by hand** against the live source. Record the error rate. Anything above 5% and you have a resolution problem, not a copy problem.

**2. Bounce test a holdout slice** of two to three hundred records before committing the whole list. It costs one day and it protects the estate.

If you only do two things on this page, do these.

</aside>

## ✍️ Copy, Pass One: Mechanical

- 🔤 Every merge field checked for null, empty and malformed values
- 🛟 Fallback copy tested by deliberately blanking each field
- 🔁 Spintax renders correctly and does not produce nonsense combinations
- 🚩 Spam trigger words removed. The cut list from 9.6
- ✉️ Signature is a name, not a block
- 🔗 Every link works, and there are almost none
- 📵 Open tracking off

## 👁️ Copy, Pass Two: Human

Read every email aloud, in full, for each bucket.

- 🗣️ Does it sound like a person?
- 🎯 Could this have been sent to any other business? Section 9.4
- 🪣 Is it written for the bucket it is going to?
- ❓ Is there exactly one ask?
- 📱 Does it read well on a phone, in short paragraphs?

The second pass catches what the first cannot. A campaign can be mechanically perfect and still read like a template.

## 📡 Tracking and Routing

- 📥 Reply detection working, tested with a real reply
- 💥 Bounce and unsubscribe tracking on
- 🔔 Reply alerts going to the person who calls back, in the place they actually look
- 📆 Booking link works on mobile, and the calendar is genuinely open
- 📝 Replies logging wherever you track them

## 🧪 The Live Test

Last step. Send the full sequence to yourself and to one colleague, on different providers.

- 📩 Gmail and Outlook at minimum
- 👀 Check where it lands. Primary, promotions or spam
- 📱 Open it on a phone
- ↩️ Reply to it, and confirm the alert fires

Five minutes. It catches the things every other check misses, because it is the only one that tests the whole chain at once.

## 🚦 Launch Gate

Do not send if any of these are true:

- ❌ Warm-up incomplete on any mailbox in the campaign
- ❌ The name sample error rate is above 5%
- ❌ The holdout bounce test came back above 2%
- ❌ Suppression is not loaded
- ❌ Nobody is named to work the replies

Any one of those is a reason to delay by a day. All of them are cheaper to fix now than after two thousand sends.

---

<aside>
🔑

### Half of This Checklist Is About the Data

Verification, deduplication, bucket assignment, the name sample and the bounce test all exist because most local data arrives unreliable. Starting from a verified source removes several of these steps entirely.

LocalPipe is the local business database this guide runs on:

- ✅ **Triple verified**, with **sub 1% bounce** on raw exports, so no second verification pass
- 👤 **75%** owner name find rate, which is what the manual name sample is checking
- 🪣 Owner email, business email and owner phone returned separately, so the buckets exist from the start

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

---

<aside>
➡️

**Next:** [10.3 The Numbers to Watch](10%203%20The%20Numbers%20to%20Watch%20f1f61a134ea183518a7101ed48d9e6a7.md)

Four leading, four lagging, and what to do with each.

</aside>