# 05 · ICP and Signals

<aside>
🎯

**What this section does.** Decides who you email, which is the highest-leverage decision in the whole system. Four layers of definition, a score, and — rebuilt from scratch for local — the list of public signals that actually exist on a business with eleven employees and no filings.

</aside>

**Applies to:** Both motions for the framework. **B→L clients differ** on geography and tier mix, and the differences are noted in place.

<aside>
🏢

**Do this with the client, not for them.** The ICP exercise in 5.2 is a much better onboarding conversation than a form, and the signal bench in 5.4 is built once per trade and reused across every client in it. That reuse is the closest thing to leverage an agency has in this market.

</aside>

## Chapters

1. **5.1 The Four Layers of a Local ICP.** Firmographics, tools, live signals, what they value
2. **5.2 Build Your ICP in 30 Minutes.** From their best and worst customers, plus the anti-ICP
3. **5.3 Score and Tier Your Market.** The 0 to 100 rubric, A to D, and what each tier earns
4. **5.4 The Local Signal Bench.** Permits, second vans, review velocity, local job boards, live ads, licences, seasonality, weather
5. **5.5 Ocean State and Pain Research.** How saturated the category is, and the six questions to answer before writing anything

---

[5.1 The Four Layers of a Local ICP](05%20%C2%B7%20ICP%20and%20Signals/5%201%20The%20Four%20Layers%20of%20a%20Local%20ICP%2080a61a134ea182f2a7a001727e6e0d37.md)

[5.2 Build Your ICP in 30 Minutes](05%20%C2%B7%20ICP%20and%20Signals/5%202%20Build%20Your%20ICP%20in%2030%20Minutes%20e8d61a134ea1832f97c901f71c03fdfc.md)

[5.3 Score and Tier Your Market](05%20%C2%B7%20ICP%20and%20Signals/5%203%20Score%20and%20Tier%20Your%20Market%20a5561a134ea1834f89b38163269f57fb.md)

[5.4 The Local Signal Bench](05%20%C2%B7%20ICP%20and%20Signals/5%204%20The%20Local%20Signal%20Bench%2005861a134ea183d6aded818bfccf0084.md)

[5.5 Ocean State and Pain Research](05%20%C2%B7%20ICP%20and%20Signals/5%205%20Ocean%20State%20and%20Pain%20Research%20e8161a134ea1828b980f81f4c36a69df.md)

---

<aside>
➡️

**Next section:** [06 · Building the List](06%20%C2%B7%20Building%20the%20List%20baa61a134ea182f5969a818c8b0ad4b1.md)

The longest section, and the one that differentiates you.

</aside>