# 11.1 The Reply Is a Cue to Dial

<aside>
📞

**On local, a positive reply is not a booked meeting. It is a cue to pick up the phone.**

This is the biggest practical difference between local and corporate outbound, and it wrecks more programs than any deliverability problem.

</aside>

## 💸 What a Reply Actually Costs You

Work backwards through what it took to produce one.

Domains bought and warmed for two weeks. A market sourced properly, enriched and verified. An offer built and tested. Three emails written per bucket. Weeks of sending.

All of that exists to make **one person type back**.

Then it arrives, sits in an inbox for two days, and gets a polite reply on Thursday. The most expensive thing your system produces, wasted by the cheapest possible failure.

## ⏳ The Intent Window

Somebody replies to a cold email because for about ninety seconds they were curious. That curiosity is not durable.

- ⚡ **Inside the hour:** they remember writing to you. The conversation continues naturally
- 🕐 **Same day:** still warm, but you are now interrupting rather than continuing
- 📅 **Next day:** they have to reconstruct why they replied
- 🗓️ **Two days plus:** you are effectively cold again, with a slightly warmer opener

Nothing about this is specific to your offer. It is how attention works when somebody is running a business and dealing with fifty other things.

## 🏪 Why It Hits Harder Here

In corporate outbound there is a machine behind the reply. A shared inbox, a CRM, an SDR whose job is to respond, and a process that catches it.

On local, the person receiving the lead is the owner. They are on a job at two in the afternoon, they see it at seven, and they answer the next morning by which point the moment has gone.

**That is not a lead quality problem.** But it is experienced as one, and if you are running this for somebody else, that is an argument you cannot win after the fact. Section 11.4.

## 📱 Why the Phone, Not Another Email

Replying by email continues the exchange. Calling converts it.

- 🗣️ **A local owner would rather talk than type.** They are not at a desk
- 🔁 **Email adds a round trip.** Your reply, their reply, your suggestion of times, their confirmation. That is four exchanges and three chances to go cold
- ☎️ **You already have the number.** It is on every Maps record, and on the smallest businesses it is often a personal mobile.
- 🎯 **A call turns a maybe into a decision** in one conversation

**The move:** reply by email *and* call, within the hour. The email is the receipt. The call is the conversion.

## 🔔 Making the Hour Actually Happen

The window only works if the alert reaches somebody who can act.

- 📲 **Alert to a phone**, not an inbox. Text or push, not another email in the same inbox that just got a reply
- 👤 **One named person.** "Whoever sees it first" means nobody
- 📞 **The number ready in the alert**, so there is no lookup step
- 🗒️ **A written opener** so there is no thinking step. Section 11.5
- ⏱️ **Measure time from reply to first call attempt.** If you do not measure it, it drifts to a day within a month

## 📊 What Good Looks Like

- ⏱️ **Time to first attempt:** under one hour in working hours - ideally within 3-5 minutes
- 📞 **Attempts per positive reply:** two or three, across different times of day
- 📅 **Positive reply to booked meeting:** around half

If that last number is well under half, the problem is almost never your wording. It is the gap between the reply arriving and somebody calling.

## ✅ Before You Move On

- A named person who calls
- Alerts arriving on a phone within minutes
- A rule that every positive reply gets an email and a call
- Time to first attempt being measured

---

<aside>
🔑

### You Cannot Call a Number You Do Not Have

This whole page assumes you can pick up the phone within the hour. That depends on the record carrying a number in the first place.

LocalPipe is the local business database this guide runs on:

- 📞 Owner phone returned alongside the email, not as a separate purchase
- 👤 **75%** owner name find rate, so you know who you are asking for
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- ✅ **Triple verified**, with **sub 1% bounce** on raw exports

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

---

<aside>
➡️

**Next:** [11.2 The Seven Reply Types](11%202%20The%20Seven%20Reply%20Types%2040761a134ea18285a6d801fe19b57a09.md)

One right move for each, including the one most people classify as a loss.

</aside>