# 11.3 Getting Them to Show

<aside>
📅

**The booking is not the win. The held meeting is.**

Between yes and the call, you are the least important thing on their day. A van breaks down, a job overruns, a customer shouts, and your meeting is the easiest thing to drop.

</aside>

## ⏱️ Keep the Window Short

The single biggest driver of show rate is how far out the meeting is booked.

- 🥇 **24 to 48 hours** is the target
- ⚠️ **Four days is the outer limit.** Past that, show rate falls off a cliff
- 📅 **Never "sometime next month".** That is a polite no with a date attached

If your calendar is genuinely full for a week, offer a fifteen-minute call sooner rather than a thirty-minute one later.

## 🛠️ The Five-Step Show-Up Engine

Run all five on every booking. Together they lift show rate substantially, and none of them takes long.

### 1️⃣ Redirect straight to a pre-call page

The booking confirmation should not dead-end on a generic "thanks, it's in the calendar" screen. That is the moment they are most engaged with you and it is almost always wasted.

Send them to a real page. The next section is what goes on it.

### 2️⃣ Confirm in the thread and in the calendar

Reply in the same email thread confirming the time in words, and send the calendar invite separately. Two records, two places they might look. The invite needs the phone number in it and a line about what you will cover.

### 3️⃣ A human touch from whoever runs the call

Not automated. A short message from the actual person, the same day.

*"Looking forward to Thursday. I'll have pulled up your listing before we speak so we can get straight into it."*

Automation confirms. A human convinces.

### 4️⃣ A reminder by text, not email

**This is the local-specific one.** An owner-operator in the field checks texts and ignores email. A reminder sent by email to somebody who booked from a phone in a van will not be seen.

Morning of, short, no links.

*"Hi Dan, we're on for 2pm today. Calling this number unless you'd rather I use another one."*

### 5️⃣ A short pre-call question

One question, answered in a sentence, sent the day before.

*"Quick one before Thursday, roughly how many quotes are you sending a week at the moment?"*

It gets them invested, it gives you a better call, and an answer confirms they are still coming.

---

## 📄 The Pre-Call Page

The most underused asset in this entire section, and the one that separates a 50% show rate from a 70%+ one.

Most people treat the thank-you page as a receipt. It is actually the only window where somebody has chosen to pay attention to you and has nothing else to do. Use it properly and they arrive at the call already understanding what you do, already past their objections, and ready to talk logistics rather than concept.

### 🧭 Build it as a checklist, not a page

The single most important structural decision. Not a wall of information, a **numbered set of steps with a progress tracker and a done button on each one.**

People complete checklists. They abandon pages.

Open with what it is and how long it takes:

> **You're booked. Here's exactly what to do next.**
> 

> Five steps, about 30 minutes total. Do them before our call and you'll get far more out of it. Most people who work through this page show up understanding exactly how the system will hit their revenue goals, and the call is used for discussing logistics.
> 

That last sentence is doing real work. It tells them the call is not a pitch, and it sets the expectation that they arrive informed.

### 📋 The Five Steps

| Step | What it is | Why it is there |
| --- | --- | --- |
| **01. Start here** | A short video, around five minutes, introducing the page and why each step matters | Turns a calendar entry into a person, and frames the other four so they get done |
| **02. Confirm your call** | Click the confirmation link in the email. Ten seconds | The single biggest mechanical thing that holds the slot. Include a fallback: check spam, then email me directly |
| **03. The methodology breakdown** | The long one. Twenty minutes plus, chaptered with timestamps | **If they only do one step, this is it.** They arrive understanding the system rather than hearing it for the first time on the call |
| **04. Proof** | Named results and short testimonials. Same system, different industries, different timelines | Belief. Specific numbers with a name attached beat any claim you make live |
| **05. Every question answered on video** | Short videos, grouped by theme. Two to five minutes each | Objections handled before the call, in their own time, with no pressure to push back |

### 🎬 Chapter the long video

The methodology video is the piece that does the most work, and a twenty-minute video with no structure gets closed after ninety seconds.

List the chapters with timestamps underneath it, so they can see the shape of it and jump to what they care about. Something like: the questions worth asking about any channel, why the alternatives break down, what the system actually is, why a competitor cannot copy it, what happens week by week, and who it works for.

### ❓ Group the FAQ videos by what they are really asking

Not a flat list. Three groups, because the underlying worry is different in each:

- 🎯 **"Does this work for me?"** Have you done this in my niche. I tried cold email and it did not work. My show rate is terrible. I don't like cold emails, won't my customers feel the same. How fast can I see results
- 🤝 **"Can I trust you?"** How consistent is this. My last agency burned me, how are you different. Do you offer a guarantee. Are you going to hard sell me on the call
- 💷 **"Money and alternatives"** What is your price. Why is it so expensive. Do you do pay per lead. Why an agency rather than building it in house. Can't I just hire a freelancer

**Answer the price question.** Most people leave it off for exactly the wrong reason. Somebody who reads your pricing and still turns up has already half decided, and somebody who would have dropped out over price was never going to buy.

**Answer the hard ones honestly**, especially "my last agency burned me" and "why is it so expensive". Those are the two every local buyer is carrying, and answering them on video, unprompted, does more for trust than anything you say live.

### 📱 Give them a direct line

A WhatsApp link and an email address, with a realistic response time. *"Anything I haven't covered, message me and I'll answer it before we speak. I usually reply within a couple of hours."*

Very few people use it. The ones who do are your best prospects, and the presence of it changes how the whole page reads.

### 🪞 Close with the point of it

If what you sell is marketing or lead generation, the page is a demonstration. Say so:

> *By the way, the page you just went through is the same pre-education funnel we build for our clients. It's why their prospects show up at a 70%+ show rate already trusting them. You've just experienced the product.*
> 

### 🏗️ Building Rules

- 📄 **One page, no navigation, no other links.** They are not browsing your website
- 📱 **Mobile first.** They booked from a phone and will read it on one
- ✅ **A done button on every step.** Completion is the mechanic that makes it work
- 🔄 **Update the FAQ after every call.** Any question you answer twice becomes a video
- 🎥 **Video over text throughout.** It is faster to make, it builds more trust, and this buyer would rather watch than read

<aside>
👀

**A working example.** Legacy GTM's own version of this page is live at [legacygtm.com/thank-you](https://legacygtm.com/thank-you). Book a call and you will go through it yourself, which is a more useful way to understand the pattern than any description.

</aside>

---

## 👻 No-Show Recovery

You recover 20 to 30% of no-shows if you have a process and almost none if you do not.

| When | What you do |
| --- | --- |
| **Within the hour** | Call, then a short text. No reproach. "Guessing something came up, happy to grab another slot" |
| **Day two** | One email, two new times, nothing about the missed one |
| **Day four** | Final. Offer to leave it and come back later. Often this one gets the reply |
| **After that** | Move them to a not-now date, three months out. Do not keep chasing |

**Never make them feel bad about it.** They did not miss your meeting because they do not respect you. A job ran over. Treat it as normal, because it is.

## 🧯 Reducing No-Shows Before They Happen

- 🕐 **Book around their day.** Early morning or late afternoon, not mid-job. Ask which suits
- 📞 **Phone beats video** for this buyer. A video link is an extra step and a small barrier
- ⏲️ **Keep it to fifteen or twenty minutes** and say so. Thirty minutes sounds like a sales call
- 🔁 **Same person throughout.** Whoever emailed should call. A handover between booking and call costs you shows

## 📊 What Good Looks Like

- 🤝 **Show rate:** 70 to 80%
- ♻️ **No-show recovery:** 20 to 30%
- 📅 **Booking window:** under 48 hours on most bookings

Below 70% on shows, look at the booking window first, then at whether the pre-call page exists at all.

## ✅ Before You Move On

- A booking window under 48 hours
- A pre-call page built as a five-step checklist, not a receipt
- The price question answered on it
- A text reminder, not an email one
- A written no-show sequence with real dates
- Show rate being tracked

---

<aside>
➡️

**Next:** [11.4 Who Works the Replies](11%204%20Who%20Works%20the%20Replies%20c3861a134ea182ffb4fd81cd86b32b97.md)

The question that decides whether any of this produces revenue.

</aside>