# 11.4 Who Works the Replies

<aside>
🙋

**Name the person who calls back. Not the team. The person.**

This single decision separates programs that produce revenue from programs that produce a report showing replies. It is not a resourcing detail, it is the design of the system.

</aside>

<aside>
🏢

**For agencies, this is a contract conversation, not an internal one.**

Everything below is what good looks like. Getting a client to actually do it is a separate skill, and it belongs in onboarding rather than in month four. **A2.6** has the wording for raising it without sounding like you are pre-blaming them, and what to do when the honest answer is that they cannot.

</aside>

## 🕳️ The Failure Mode

It goes like this, every time.

The campaign works. Replies come in. Everybody is pleased. The replies land in an inbox that three people can see, which means nobody owns it. The first one gets answered in four hours, the next the following day, and within a fortnight replies are being worked whenever somebody has a gap.

Six weeks later the verdict is that the leads were poor.

**The leads were fine.** The window closed. Section 11.1.

## 👤 Why "Whoever Sees It First" Fails

Shared responsibility is no responsibility, and it fails in a specific way rather than a vague one.

- 🤷 **Everybody assumes somebody else has it.** Especially the replies that arrive at awkward times, which is most of them
- ⏰ **Nobody is measured on it**, so it loses to whatever is actually on their list
- 🔁 **Nobody builds the habit.** Answering replies well is a skill, and three people each doing it occasionally never get good at it
- 🚫 **There is no escalation.** When it slips, nobody notices, because nobody was responsible

One name fixes all four.

## 🧩 Designing the Handoff

Five decisions, made before the first send rather than after the first complaint.

### 1️⃣ Who calls

One name. A second name as backup for holidays, and the backup is explicitly a backup rather than a co-owner.

If nobody in the business can realistically do it, that is a real finding. Go to 11.5.

### 2️⃣ The window

Write it down. "Inside one hour during working hours, and first thing the next morning for anything after 6pm."

A written window is something you can measure against. An intention is not.

### 3️⃣ Where the alert lands

Somewhere that person actually looks within minutes. A text, a push notification, a dedicated channel.

**Not another email**, and especially not the same inbox that just received the reply.

### 4️⃣ What they say

A written opener so there is no thinking step. Thirty seconds of preparation removed is the difference between calling now and calling later.

### 5️⃣ How you know it happened

Track time from reply to first call attempt. One number, reviewed weekly.

Without it, response time drifts from twenty minutes to a day over about six weeks, and nobody notices until the results do.

## 🧑‍🔧 When the Client Is the Person

The common case on local, and it deserves a straight answer.

An owner cannot take a call at 2pm when they are on a job. That is not a failure of discipline, it is the nature of the work. So the design has to fit the reality:

- 📞 **Two call windows a day**, not continuous availability. Early morning and end of day, with the alert queuing between them
- 📲 **Text first from the field.** "Saw your reply, can I call you at 5?" takes fifteen seconds between jobs and holds the window open
- 🎚️ **Cap volume to what they can work.** Twenty positive replies a month answered well beats fifty answered badly, and it protects a finite market
- 👥 **Or sell them the calling.** Section 11.5 and A2.6

**Capping volume is a legitimate recommendation**, not a climbdown. Sending more than a client can convert burns their market to produce a number on a dashboard.

## 🚦 When the Honest Answer Is No

If nobody can work replies inside a workable window and nothing about that is going to change, more volume is the wrong answer.

Three options in order of preference:

1. 👥 **Someone else makes the first call.** A setter, a hire, an outsourced team
2. 📉 **Reduce volume** to what the available attention can convert
3. 🛑 **Do not run the program** until one of those is true

The third one is uncomfortable and occasionally correct. Manufacturing expensive intent and letting it go cold is worse than not manufacturing it, because you also burn the contacts.

## ✅ Before You Move On

- One named person, with a backup
- A written response window
- Alerts landing somewhere that person checks within minutes
- A written opener so calling requires no preparation
- Time to first attempt tracked and reviewed weekly
- Volume capped to what can actually be worked

---

<aside>
➡️

**Next:** [11.5 The Setter](11%205%20The%20Setter%20fc861a134ea182f3841781accd5af14b.md)

What the role actually does, and the workflow behind it.

</aside>