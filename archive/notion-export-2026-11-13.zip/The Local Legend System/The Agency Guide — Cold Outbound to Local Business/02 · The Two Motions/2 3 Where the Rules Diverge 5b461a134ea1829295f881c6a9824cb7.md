# 2.3 Where the Rules Diverge

<aside>
🔀

**This is the reference page.**

Every **L→L only** and **B→L differs** marker in the guide points back here. You do not need to read it now. Come back when a marker makes you curious about what you are missing.

</aside>

## 🤝 First, What Is Identical

Worth saying before the differences, because it is most of the guide.

The entire data layer is the same for both motions. Your ICP is local businesses either way, and local businesses are missing from the standard databases either way. So all of this applies to you regardless of which motion you picked:

- 🗺️ **Sourcing from Maps.** What a record holds, what it never holds, the five-stage loop
- 🏷️ **Category matching.** Roughly 4,000 categories, and why keyword search misses
- 👤 **Owner identification and enrichment.** Cross-referencing six sources, the waterfall, the find rates
- 📬 **The four contact buckets.** Owner direct, generic with the owner known, generic with no name, personal provider
- 🧹 **Hygiene, coverage math and pre-send QA.** All of it
- 📮 **Deliverability.** Domains, warm-up, the 2% bar, the free-provider lane
- ✍️ **The copy frameworks.** The four questions, the email-one skeleton, the cut list
- 🎁 **The offer frameworks.** The gate, the value equation, the guarantee ladder

If you only remember one thing from this page: **nobody gets to skip section 06.**

## 📊 Where They Actually Diverge

|  | 🏠 Local → Local | 🌐 Business → Local |
| --- | --- | --- |
| **Geography strategy** | One metro, decomposed to ZIP level. Depth in a small area | Many metros, plus rings around your existing customers. Category depth over geographic depth |
| **Market ceiling** | Hard and near. Six to eight months and you have spoken to everybody | Effectively unbounded. Your limit is fulfilment capacity |
| **Testing** | Not enough volume for parallel tests. One variable at a time | Borrow volume across metros. Real parallel tests, readable in a fortnight |
| **Proof that works** | "We already look after three restaurants on Pearl Street" | "We look after a plumbing company fifteen minutes from you", sourced from your customer map |
| **Awareness level** | Solution-aware. They already buy this from somebody | Often unaware the category exists at all |
| **Offer shape** | Trust, proximity, and a reason to switch | Category education first, then ROI |
| **Who works the reply** | You, or an owner under a sink. Speed is the hard part | Usually a real sales function. Speed is solvable |
| **Suppression risk** | Running the same small market twice. Territory overlap | Duplicate accounts and multi-location groups across metros |
| **Channel mix** | Email, phone, direct mail, drop-bys. LinkedIn barely exists | Email and phone at scale. Direct mail costs more to reach further. LinkedIn works on tier two |
| **When you run short** | Buckets, then adjacent categories, then geography, then loosen qualification | More metros, or a new category. Rarely a real constraint |

## 🎯 The Three That Matter Most

Everything above is true. These three change what you actually do this week.

**1. The ceiling, and whether you have one.**

If you are Local → Local, the market runs out and you need to know roughly when before you commit to a revenue number. That check is 3.3, and it is a real step rather than a formality.

If you are Business → Local, sizing is a sanity check. Your constraint is how much work you can take on, not how many businesses exist.

**2. Testing, and whether you can run things in parallel.**

A single metro gives you a few thousand contactable records. The standard protocol wants around a thousand people contacted per campaign before the numbers mean anything, and three or four variants at once. That math does not work in one city, so Local → Local operators test in sequence and learn slower.

Business → Local runs the same test across fifteen metros and gets a readable answer in a fortnight. Section 8.3 is honest about what that difference is worth.

**3. Who picks up the phone when a reply lands.**

On local, a positive reply is a cue to dial, not a booked meeting, and the window closes within the hour.

If you are the business, that is your problem to solve and it usually means hiring or restructuring. If you have a sales function already, you have an advantage most local operators do not, and you should use it rather than assume it. Section 11.

## 📍 Where You Will See the Markers

The pages where your motion changes the guidance most:

- **3.3** Market Size Is the Ceiling
- **6.3** Category Matching and Query Depth
- **8.3** Testing Inside a Finite Market
- **9.4** Personalization That Works on Local
- **12.3** Territory, Proximity and Density

Everywhere else, assume the rule applies to you unless the page says otherwise.

## 🤔 Still Not Sure Which You Are?

Go back to **0.2 Pick Your Motion** and answer the 500-mile question. If a perfect-fit customer appeared five hundred miles away and you could serve them profitably without changing how you operate, you are Business → Local.

And if you genuinely run both, pick per campaign rather than per company. Two motions means two campaigns, not one hybrid that lands for neither.

---

<aside>
🔑

### The One Thing Both Motions Share

Whatever else differs, your ICP is local businesses, and local businesses are missing from the standard databases either way.

LocalPipe is the local business database this guide runs on:

- 🗺️ Sourced from Maps, so the businesses are there in the first place
- 👤 **75%** owner name find rate
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- ✅ **Triple verified**, with **sub 1% bounce** on raw exports

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

---

<aside>
➡️

**Next:** [2.4 When Local Outbound Is the Wrong Call](2%204%20When%20Local%20Outbound%20Is%20the%20Wrong%20Call%2052d61a134ea1822b8526816047496be3.md)

The disqualifiers, for both motions, before you spend anything.

</aside>