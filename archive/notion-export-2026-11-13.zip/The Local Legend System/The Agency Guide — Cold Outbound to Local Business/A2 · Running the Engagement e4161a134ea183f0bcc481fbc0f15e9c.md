# A2 · Running the Engagement

<aside>
⚙️

**What this section does.** Everything after signature. Onboarding, infrastructure across several clients, the handoff that decides whether your work looks successful, reporting, and what happens when a market runs dry mid-retainer.

</aside>

**Applies to:** Agencies only.

## Chapters

1. **A2.1 Onboarding and the Intake Form.** What you must have before you build anything
2. **A2.2 Whose Domains, Whose Infrastructure.** Ownership, and what happens when it ends
3. **A2.3 Running Several Clients at Once.** The multi-tenant reality
4. **A2.4 Suppression and Territory.** Per client, and why it is never shared
5. **A2.5 Reporting That Credits the Work.** Opportunities rather than replies
6. **A2.6 The Handoff Conversation.** Designed at onboarding, not diagnosed in month two
7. **A2.7 When the Market Runs Out Mid-Retainer.** The conversation, and the expansion order
8. **A2.8 Churn and Scope Creep.** The two ways these engagements end badly

[A2.1 Onboarding and the Intake Form](A2%20%C2%B7%20Running%20the%20Engagement/A2%201%20Onboarding%20and%20the%20Intake%20Form%20b6a61a134ea18266848b014e2c74a19b.md)

[A2.2 Whose Domains, Whose Infrastructure](A2%20%C2%B7%20Running%20the%20Engagement/A2%202%20Whose%20Domains,%20Whose%20Infrastructure%208da61a134ea182d4bc97816c11e28011.md)

[A2.3 Running Several Clients at Once](A2%20%C2%B7%20Running%20the%20Engagement/A2%203%20Running%20Several%20Clients%20at%20Once%201d861a134ea183e1bf8101d1422f8a30.md)

[A2.4 Suppression and Territory](A2%20%C2%B7%20Running%20the%20Engagement/A2%204%20Suppression%20and%20Territory%2033261a134ea183628def01d83ddd2bec.md)

[A2.5 Reporting That Credits the Work](A2%20%C2%B7%20Running%20the%20Engagement/A2%205%20Reporting%20That%20Credits%20the%20Work%2022a61a134ea182ce856081c1d8179026.md)

[A2.6 The Handoff Conversation](A2%20%C2%B7%20Running%20the%20Engagement/A2%206%20The%20Handoff%20Conversation%2016b61a134ea18388aeef01a5878d99de.md)

[A2.7 When the Market Runs Out Mid-Retainer](A2%20%C2%B7%20Running%20the%20Engagement/A2%207%20When%20the%20Market%20Runs%20Out%20Mid-Retainer%20df461a134ea182e4976d8174fc88dca1.md)

[A2.8 Churn and Scope Creep](A2%20%C2%B7%20Running%20the%20Engagement/A2%208%20Churn%20and%20Scope%20Creep%2091161a134ea182258b1601795aeefe75.md)

---

<aside>
➡️

**Next section:** [12 · Beyond the Inbox](12%20%C2%B7%20Beyond%20the%20Inbox%20b9661a134ea182a4953801274a94aed3.md)

The upsells: direct mail, the phone, territory and referral loops.

</aside>