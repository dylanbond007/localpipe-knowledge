# 1.3 What Local Changes, Lever by Lever

<aside>
🔍

**Selling to local businesses does not throw the method out.**

It rewrites one lever completely, bends a second, re-prices a third, and leaves two largely alone. Knowing which is which tells you what you do not have to relearn.

</aside>

## 📊 The Audit

| Lever | What local does to it |
| --- | --- |
| 🎯 **Prospect** | 🔴 **Rewritten completely.** There is no database. The list is something you build, enrichment is cross-referencing rather than lookup, and one business yields several contacts |
| 📬 **Deliverability** | 🟠 **Bends.** The principles hold. A large share of your best contacts sit on personal providers that cannot be warmed the usual way |
| 📈 **Scale** | 🟠 **Same maths, inverted constraint.** Volume is a ceiling the market sets, not a dial you open |
| 🎁 **Offer** | 🟢 **Holds.** The buyer is an owner-operator rather than a functional buyer, which changes the register and the proof, not the frameworks |
| ✍️ **Copy** | 🟢 **Holds.** Same structure, far fewer personalization inputs, and four versions instead of one |

## 🔴 Prospect: The One That Is Genuinely Different

Everything hard about local outbound is here.

**The businesses are not in the databases.** Under 5% of local SMBs appear in the major B2B tools, and 80 to 90% of home service businesses are missing entirely. Pull a list the normal way and you get a fraction of the market that was never representative. Section 6.1 has the full picture, and 0.4 says where every figure in this guide comes from.

**A Maps listing has no email and no owner name.** Those two fields are the entire problem. Everything in section 06 exists to resolve them.

**One business gives you several contacts.** The owner's address, a generic inbox, sometimes a personal Gmail. In corporate outbound the extra addresses are noise. Here they are half your market.

**The market is finite and knowable.** You can build a genuinely complete list of every dental practice in a metro. You will also run out of them.

## 🟠 Deliverability: Bends, Does Not Break

Domains, warm-up, authentication, the 2% bar. All standard, all covered in section 04.

The local-specific part: on a local record a gmail address usually means the owner personally rather than bad data. That segment bounces higher, burns infrastructure faster, and cannot be warmed by a standard pool. So it gets its own estate rather than getting deleted. Section 4.6.

## 🟠 Scale: Same Maths, Opposite Job

The model is identical. Revenue goal, deal value, conversion rates, contacts needed.

What changes is what it tells you. Everywhere else it sets a target. Here it usually reports a **ceiling**, because the market contains a finite number of businesses and you can count them.

That reframes the whole exercise from planning into feasibility testing, and it is why section 03 comes before you buy anything.

## 🟢 Offer and Copy: Mostly Unchanged

Good news if you have done this before.

The frameworks hold. The gate tests, the value equation, the guarantee ladder, the four questions, the email skeleton. All of it works.

What changes is the reader. Somebody who owns the business, does the work, reads their own inbox on a phone between jobs, and has been burned by somebody in your category. That changes register, proof and personalization inputs. It does not change the structure.

## 🎯 What This Should Change About How You Read the Guide

- 🥇 **Spend your time on section 06.** It is the longest section and the only one that is genuinely new to an experienced operator
- ⏭️ **Skim 07 and 09.** Read the local notes, skip the frameworks you already use
- ⚠️ **Do not skip section 04.** It looks standard and there is one page in it, 4.6, with no equivalent anywhere else
- 🧮 **Read 03 and A1.2 together.** Market sizing is the thing you do during the sale rather than after it, and it is the most expensive thing to get wrong on a local client

## 🧠 The One Sentence Version

> **In corporate outbound, copy and offer usually decide the outcome, because everybody has the same data.**
> 

> **On local, the data is the variable.**
> 

That is why this guide spends eight pages on list building, and why the client you are pitching has almost certainly never been shown the difference between a database export and a properly sourced market.

---

<aside>
➡️

**Next:** [02 · The Two Motions](../02%20%C2%B7%20The%20Two%20Motions%20f1f61a134ea1829c8896016efbf2524a.md)

Which version of this guide applies to you.

</aside>