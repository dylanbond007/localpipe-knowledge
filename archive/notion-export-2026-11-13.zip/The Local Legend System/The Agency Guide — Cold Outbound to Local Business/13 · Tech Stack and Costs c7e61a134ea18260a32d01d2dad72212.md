# 13 · Tech Stack and Costs

<aside>
🧰

**What this section does.** What to buy, in what order, and nothing you do not need. Plus an honest comparison of the five kinds of data provider, because that decision has more effect on your results than any other purchase here.

</aside>

**Applies to:** Both motions.

## Chapters

1. **13.1 What to buy, in what order** — the full stack, sequenced, with the partner codes
2. **13.2 The data layer compared** — corporate databases, cheap scrapers, an assembled workflow, a purpose-built API, and building it yourself

---

[13.1 What to Buy, in What Order](13%20%C2%B7%20Tech%20Stack%20and%20Costs/13%201%20What%20to%20Buy,%20in%20What%20Order%200c161a134ea18223b99681fbca0678f8.md)

[13.2 The Data Layer Compared](13%20%C2%B7%20Tech%20Stack%20and%20Costs/13%202%20The%20Data%20Layer%20Compared%2010e61a134ea183d2b28501fa8bf591fc.md)

---

<aside>
➡️

**Next section:** [14 · Case Studies](14%20%C2%B7%20Case%20Studies%204a561a134ea18316a83581ebb4319032.md)

One client engagement, end to end, with the numbers at every stage.

</aside>