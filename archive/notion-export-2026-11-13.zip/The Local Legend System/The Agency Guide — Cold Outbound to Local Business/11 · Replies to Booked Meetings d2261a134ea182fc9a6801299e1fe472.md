# 11 · Replies to Booked Meetings

<aside>
📞

**What this section does.** A reply is the most expensive thing your system produces. This section turns it into a held meeting. The local-specific part is the biggest single point in the guide: on local, email is a signal channel and the conversion happens on the phone, usually within the hour.

</aside>

**Applies to:** Both motions for the playbook. **11.4 and 11.5 are where local engagements are won and lost**, because your client is usually the person who has to make the call.

<aside>
🏢

**This section is the one that decides whether your work looks successful.** You can run a technically excellent campaign and be judged a failure because nobody rang back inside the hour. A2.6 covers the conversation that prevents it, and A2.5 covers reporting the number so it is a shared fact rather than a complaint.

</aside>

## Chapters

1. **11.1 The Reply Is a Cue to Dial.** The intent window, and why a positive reply is not a booked meeting
2. **11.2 The Seven Reply Types.** One right move each, including why referrals are gold
3. **11.3 Getting Them to Show.** The five-step show-up engine, the pre-call page, and no-show recovery
4. **11.4 Who Works the Replies.** The question that decides whether any of this produces revenue
5. **11.5 The Setter.** The role, the workflow and the script, and why it is the highest-margin thing you can add

---

[11.1 The Reply Is a Cue to Dial](11%20%C2%B7%20Replies%20to%20Booked%20Meetings/11%201%20The%20Reply%20Is%20a%20Cue%20to%20Dial%202e361a134ea18392b54e014cffc9f56d.md)

[11.2 The Seven Reply Types](11%20%C2%B7%20Replies%20to%20Booked%20Meetings/11%202%20The%20Seven%20Reply%20Types%2040761a134ea18285a6d801fe19b57a09.md)

[11.3 Getting Them to Show](11%20%C2%B7%20Replies%20to%20Booked%20Meetings/11%203%20Getting%20Them%20to%20Show%20ec361a134ea182f29ef201cf86026dee.md)

[11.4 Who Works the Replies](11%20%C2%B7%20Replies%20to%20Booked%20Meetings/11%204%20Who%20Works%20the%20Replies%20c3861a134ea182ffb4fd81cd86b32b97.md)

[11.5 The Setter](11%20%C2%B7%20Replies%20to%20Booked%20Meetings/11%205%20The%20Setter%20fc861a134ea182f3841781accd5af14b.md)

---

<aside>
➡️

**Next section:** [A2 · Running the Engagement](A2%20%C2%B7%20Running%20the%20Engagement%20e4161a134ea183f0bcc481fbc0f15e9c.md)

Onboarding, infrastructure, suppression, reporting and churn.

</aside>