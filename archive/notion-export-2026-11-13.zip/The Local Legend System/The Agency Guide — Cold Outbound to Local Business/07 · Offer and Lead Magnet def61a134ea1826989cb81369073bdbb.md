# 07 · Offer and Lead Magnet

<aside>
🎁

**What this section does.** Builds the two offers a campaign needs: the thing the client sells, and the free thing that makes a stranger give them thirty minutes. Then makes both harder to refuse.

</aside>

**Applies to:** Both motions for the frameworks. **B→L clients differ** on proof and awareness level, noted in 7.1.

<aside>
🏢

**The offer is theirs and the final call is theirs.** Your job is to pressure-test it, name the weakest dial, and build the magnet. An agency that quietly rewrites a client's offer without agreement ends up defending a promise the client never made.

</aside>

## Chapters

1. **7.1 Two Offers, Not One.** The core offer, the lead magnet, and why most people only build one
2. **7.2 The Core Offer Gate and the Value Equation.** Three pass or fail tests, then the four dials
3. **7.3 Reversing the Risk.** The guarantee ladder, and what an owner-operator will actually believe
4. **7.4 Lead Magnets for Owner-Operators.** The audit wins. Profile audits, review gaps, missed calls, quote response times
5. **7.5 Offer and Magnet by Campaign Type.** Matching the offer to market state and campaign motion

---

[7.1 Two Offers, Not One](07%20%C2%B7%20Offer%20and%20Lead%20Magnet/7%201%20Two%20Offers,%20Not%20One%206d161a134ea18376a01401c0a83e4994.md)

[7.2 The Core Offer Gate and the Value Equation](07%20%C2%B7%20Offer%20and%20Lead%20Magnet/7%202%20The%20Core%20Offer%20Gate%20and%20the%20Value%20Equation%20adf61a134ea1835fa0df013b0d7675e6.md)

[7.3 Reversing the Risk](07%20%C2%B7%20Offer%20and%20Lead%20Magnet/7%203%20Reversing%20the%20Risk%2004561a134ea183f583f081ab9eb0e376.md)

[7.4 Lead Magnets for Owner-Operators](07%20%C2%B7%20Offer%20and%20Lead%20Magnet/7%204%20Lead%20Magnets%20for%20Owner-Operators%20c9f61a134ea18302bb2c8113beae71fe.md)

[7.5 Offer and Magnet by Campaign Type](07%20%C2%B7%20Offer%20and%20Lead%20Magnet/7%205%20Offer%20and%20Magnet%20by%20Campaign%20Type%2033361a134ea18389b1cb81526d1b5185.md)

---

<aside>
➡️

**Next section:** [08 · Campaign Architecture](08%20%C2%B7%20Campaign%20Architecture%2016761a134ea183d5bad00117ab4d1ae5.md)

The portfolio, and where a book of clients becomes an advantage.

</aside>