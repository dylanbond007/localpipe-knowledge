# 9.3 The Four Questions and the Email-1 Skeleton

<aside>
📝

**Every cold email answers four questions, in this order.**

Why me. Why should I care. Why should I believe you. What now.

Each one earns the right to the next. Skip one and the reader stops at that point, whatever comes after it.

</aside>

## ❓ The Four Questions

| Question | What it means | Fails when |
| --- | --- | --- |
| 1️⃣ **Why me?** | Why this business, today, rather than anyone else | The opener could be sent to any business in the category |
| 2️⃣ **Why should I care?** | The problem or outcome, in their terms and their money | It is a feature, or a benefit to you rather than them |
| 3️⃣ **Why believe you?** | Proof they can check | A claim with no evidence, or a number they cannot verify |
| 4️⃣ **What now?** | One small, clear next step | Two asks, or an ask that costs them more than the email earned |

## 💔 The Two Places Almost Every Weak Email Breaks

**Question one.** There is no real reason for reaching out, so the opener is a generic compliment or a statement about the industry. The reader decides it is a blast in the first line and never reaches your offer.

**Question three.** Claims with nothing behind them. "We help businesses like yours grow revenue" is unfalsifiable, which means it is unbelievable. A specific, checkable, smaller claim always outperforms a big vague one.

Fix those two and you have fixed most of what is wrong with most cold email.

## 🧱 The Email One Skeleton

Forty to eighty words. Plain text. One ask. Here is every line and what it is doing.

| Line | Job | Local example |
| --- | --- | --- |
| **Subject** | Earn the open without promising anything | "quick question" / "your Mill Road job" |
| **Opener** | Answer *why me* in one sentence | "Saw you're hiring a second install crew." |
| **Problem or outcome** | Answer *why care*, in their money | "Usually that means quotes are going out slower than they should be." |
| **Proof** | Answer *why believe you*, checkably | "We do this for two other HVAC firms in the county." |
| **Soft CTA** | Answer *what now*, cheaply | "Worth a quick look at yours?" |
| **Sign-off** | Be a person with a name | First name. No job title, no logo, no banner |

**That is the whole email.** If you are writing more than six lines, something is doing a job another line already did.

## 🧩 Merge Fields That Actually Exist

Write the skeleton against fields a sourced and enriched record genuinely carries. Anything else will be empty on launch day.

- ✅ **Always available:** business name, category, city or area, review count
- ✅ **Usually available:** owner first name, website presence, opening hours
- ⚠️ **Sometimes available:** a live signal, a specific review, a named service
- ❌ **Do not build on:** headcount, revenue, tenure in role, tech stack

Design the email so it still reads correctly using only the always-available fields. Everything above that is upside.

## 🛟 Fallback Copy Is Not Optional

On local, a merge field is missing far more often than in corporate outbound, and a broken merge field is the single most visible way to prove you are mass mailing.

For every field, write the version that renders when it is empty:

- 👤 **No first name** → the bucket three opener, which uses the business name instead
- 📡 **No signal** → the evergreen opener
- ⭐ **No specific review** → the category-level version of the same observation

**Then test it.** Deliberately blank each field on a test record and send it to yourself. If any version reads oddly, fix it before launch, not after. Section 10.2.

## ✅ Before You Move On

- Four questions answered in order, in every draft
- An opener that could not have been sent to another business
- Proof that can be checked
- One ask, small
- A fallback version for every merge field, tested blank

---

---

<aside>
➡️

**Next:** [9.4 Personalization That Works on Local](9%204%20Personalization%20That%20Works%20on%20Local%2083061a134ea18263960f8146ae71507e.md)

Two inputs do almost all the work, and both come free with the record.

</aside>