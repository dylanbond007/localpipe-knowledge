# 9.4 Personalization That Works on Local

<aside>
🎯

**Two inputs do almost all the work: where they are, and the owner's name.**

Both come free with the record. Everything you would normally reach for either does not exist here or reads as surveillance.

</aside>

## 🚫 Why the Standard Inventory Does Not Apply

The usual personalization sources are funding news, headcount changes, job moves, tech stack, podcast appearances, LinkedIn posts and published content.

A twelve-person plumbing company has none of them. No funding, no published headcount, no professional profile, no content, no conference talk.

What it does have is a location, an owner, a category, some reviews and a website. That is the whole palette, and it is enough.

## 📍 Location: Free, Universal, and Easy to Waste

Location is on **every single record**, which is exactly why it reads as filler when used lazily.

- ❌ **Filler:** "As a business in Bristol, you probably..." Says nothing. Could be a mail merge and obviously is
- ✅ **Real:** "We look after two practices on Whiteladies Road." Now the location is doing work, because it implies proximity, credibility and relevance at once

**The test:** does the location connect to your pitch, or is it decoration? If you could delete the place name and the sentence still means the same thing, it is decoration.

## 👤 The Owner's Name: The Highest-Value Field You Have

A first name changes the email from a message to a business into a message to a person.

- 🅰️ **In bucket one**, address them directly. "Hi Dan"
- 🅱️ **In bucket two**, use it in the third person. "I was hoping to reach Dan" or "if Dan is the right person"
- ⚠️ **Never guess it.** A wrong name is worse than no name and it kills the record permanently. Section 6.6

That is why the find rate in section 06 matters so much to this page. Seventy-five percent owner names is not a data statistic. It is the difference between writing to a person and writing to a building.

## 🧐 The Could-Be-Anyone Test

The most useful test in this whole guide, and it takes five seconds.

> **Cover the business name and the location. Could this email go to any other business in the category unchanged?**
> 

If yes, it is not personalized. It is a template with holes in it, and the reader will spot that faster than you think.

Run it on every draft. Most fail the first time.

## ✅ What Else Works, When It Exists

Beyond the two, a short list of things that genuinely land:

- 🔧 **A problem you can see and name**, without telling them their baby is ugly. "Noticed the booking link on your site 404s" is helpful. "Your website is out of date" is an insult
- 📡 **A live signal.** Hiring, ads running, a new location. Section 5.4
- 🗣️ **Something they said publicly**, in their own words. A review reply, an About page line. They wrote it to be read
- 🏘️ **A shared local reference.** A customer, a street, a business park

## 📏 Keep It to One Sentence

Personalization lives in the opener and nowhere else.

A twenty-word personalized line inside a sixty-word email throws the whole thing off balance. The reader gets a paragraph about themselves and then a rushed pitch, which feels like a setup.

One sentence. Then move to the problem.

## 🌐 If Your Client Sells to Local Businesses From Anywhere

Location still works, just anchored differently. Your client cannot say they are nearby. They can say their customer is.

"We look after a plumbing company fifteen minutes from you" is available to you the moment you build lists as rings around their existing accounts. Section 6.3.

Where their customer map is thin, fall back to peer proof: the category and the number, rather than the place.

## ✅ Before You Move On

- Location used as an argument, not as decoration
- Owner name used correctly per bucket, and never guessed
- Every draft through the could-be-anyone test
- Personalization confined to one sentence in the opener
- Nothing in the copy you would feel odd saying on a phone call

---

<aside>
🔑

### The Two Inputs Both Come From the Data Layer

Location is on every record. The owner's name is on about three quarters of them, and only if your source actually resolves owners rather than scraping addresses off a website.

LocalPipe is the local business database this guide runs on:

- 👤 **75%** owner name find rate, which is what makes a first name possible at all
- ✉️ **60%** combined email coverage, against roughly 10% from a standard B2B database
- ✅ **Triple verified**, with **sub 1% bounce** on raw exports

**30% off lifetime monthly for readers of this guide.**

# [👉 Get Verified Local Business Owner Contacts](https://localpipe.io)

Code **LOCALLEGEND**

</aside>

---

<aside>
➡️

**Next:** [9.5 Copy Per Contact Bucket](9%205%20Copy%20Per%20Contact%20Bucket%20e3761a134ea18252b56881ee93e811ef.md)

Four buckets, four openers, four asks.

</aside>