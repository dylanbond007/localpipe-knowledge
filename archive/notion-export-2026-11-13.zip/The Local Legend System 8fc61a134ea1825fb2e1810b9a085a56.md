# The Local Legend System

<aside>
📍

**The most in-depth guide to getting more leads and qualified meetings with local businesses.**

Plumbers, dentists, landscapers, restaurants, cleaners, clinics, contractors, salons, gyms, garages. Businesses with a physical location, an owner who answers their own phone, and almost no presence in the databases everyone else is buying from.

Sourcing, enrichment, deliverability, offer, copy, launch, and turning replies into held meetings. All of it specific to local.

</aside>

## Who's Behind This

### Harvey Le

**Founder, Legacy GTM**

![Harvey Linkedin NEW PROFILE PIC W SUIT Square.jpeg](The%20Local%20Legend%20System/Harvey_Linkedin_NEW_PROFILE_PIC_W_SUIT_Square.jpeg)

Five years running cold outbound, and **20M+ cold emails sent**.

**$5M+** in revenue generated for clients.

**2,143** meetings booked with local business owners.

### Dylan Bond

**Founder, LocalPipe**

![image.png](The%20Local%20Legend%20System/image.png)

The best local business database available. Verified emails for direct business owners, not the addresses scraped off a website.

**34,700,000** emails sent on LocalPipe data.

<aside>
✅

All of this comes from running these campaigns in the field. Where a figure comes from someone else's research rather than our own runs, the page says so.

</aside>

---

<aside>
📅

### Want to Skip the Reading and Just Get the Meetings?

For business owners who want booked meetings with local businesses on their calendar, on the best data available, without building any of this themselves.

Book a call with Harvey and the Legacy GTM team will:

- 🎯 **Build you a free campaign**, not a pitch deck
- 🗺️ Map a roadmap to **15 to 30 qualified booked meetings a month** inside 90 days
- 🛠️ Run the whole system so you never touch the software

**You keep the strategy either way, whether you end up working with Legacy GTM or not.**

# [👉 Book Your Call With Harvey](https://calendly.com/harvey-legacygtm/legacy-gtm-strategy)

</aside>

---

# Step One: Who's Reading This?

There are two versions of this guide. They share the same data layer, the same deliverability work and the same copy frameworks, because none of that changes.

What changes is everything around it: who owns the domains, who works the replies, how it gets priced, and who you answer to. Pick the one that describes you, and everything after it is written for you specifically.

<aside>
🏢

### I Run an Agency

**I do this for clients.**

You already run outbound and you know your craft. You want better results in local markets specifically: better coverage, data nobody else has, and campaigns that survive a client who can't work their own replies.

</aside>

<aside>
🏪

### I Run a Business

**I want more meetings for myself.**

You want a predictable flow of qualified meetings with local business owners, built in-house, running on data your competitors don't have.

</aside>

## What's Inside Either Version

[The Agency Guide — Cold Outbound to Local Business ICPs](The%20Local%20Legend%20System/The%20Agency%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20Business%2001161a134ea18287835b81bff12e64d2.md)

[The Business Owner Guide — Cold Outbound to Local Business ICPs](The%20Local%20Legend%20System/The%20Business%20Owner%20Guide%20%E2%80%94%20Cold%20Outbound%20to%20Local%20%20f2961a134ea18308bfbe014b0ee3475c.md)

<aside>
⚡

**Not sure which one?** If somebody pays you to generate their pipeline, take the Agency Guide. If the meetings land on your own calendar, take the Business Owner Guide.

</aside>

---

| Part | What you get out of it |
| --- | --- |
| **Why local is a different problem** | Under 5% of local businesses sit in the databases everyone else uses, and the few that do have heard from everybody |
| **Deliverability** | Domains, warm-up, the 2% bounce bar, and the personal-inbox problem unique to local lists |
| **Who to target** | Scoring a local market, and the public signals that actually exist on a business with eleven employees |
| **Building the list** | The longest section. Sourcing from Maps, category matching, owner identification, enrichment, and the four contact buckets |
| **Offer and copy** | What to pitch someone who owns the business, does the work, and reads their own inbox between jobs |
| **Launch and diagnose** | Going live without burning domains, and finding the real break when the numbers slip |
| **Replies to held meetings** | Why on local the reply is a cue to pick up the phone, and what happens when nobody does |
| **Beyond email** | Direct mail with QR tracking, the phone, territory, and referral loops |